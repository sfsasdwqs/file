package com.common.szair.model.city;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class segmentTipsConditionVO extends baseDTOVO implements SOAPObject {
    public List<segmentTipsInfoVo> _SEGMENT_TIPS_LIST = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/common";
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        List<segmentTipsInfoVo> list = this._SEGMENT_TIPS_LIST;
        if (list == null || list.size() <= 0) {
            return;
        }
        int size = this._SEGMENT_TIPS_LIST.size();
        for (int i = 0; i < size; i++) {
            xml.startTag(null, "SEGMENT_TIPS_LIST");
            this._SEGMENT_TIPS_LIST.get(i).addElementsToNode(xml);
            xml.endTag(null, "SEGMENT_TIPS_LIST");
        }
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("SEGMENT_TIPS_LIST".equals(parser.getName())) {
                        if (this._SEGMENT_TIPS_LIST == null) {
                            this._SEGMENT_TIPS_LIST = new ArrayList();
                        }
                        segmentTipsInfoVo segmenttipsinfovo = new segmentTipsInfoVo();
                        segmenttipsinfovo.parse(binding, parser);
                        this._SEGMENT_TIPS_LIST.add(segmenttipsinfovo);
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}