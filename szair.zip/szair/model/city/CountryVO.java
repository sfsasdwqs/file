package com.common.szair.model.city;

import com.common.network.convert.Mapping;
import java.io.Serializable;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class CountryVO implements Serializable {

    @Mapping(name = "chineseName")
    public String chineseName;

    @Mapping(name = "englishName")
    public String englishName;

    @Mapping(name = "shortName")
    public String shortName;

    @Mapping(name = "shortNameId")
    public String shortNameId;
}