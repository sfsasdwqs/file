package com.common.szair.model.city;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class CityListWebServiceServiceSoapBinding extends SOAPBinding {
    public CityListWebServiceServiceSoapBinding(String endpoint) {
        super(CityListWebServiceServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns0", "http://com/shenzhenair/mobilewebservice/common");
        hashMap.put("ns2", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        hashMap.put("ns1", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns4", "http://impl.webservice.common.shenzhenair.com/");
        hashMap.put("ns3", "http://schemas.xmlsoap.org/soap/http");
        return hashMap;
    }

    public queryCityListResponse queryCityList(queryCityList parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryCityList", parameters);
        }
        queryCityListResponse querycitylistresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryCityListResponse)) {
                    querycitylistresponse = (queryCityListResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querycitylistresponse = new queryCityListResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querycitylistresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querycitylistresponse != null) {
                return querycitylistresponse;
            }
            queryCityListResponse querycitylistresponse2 = new queryCityListResponse();
            querycitylistresponse2.setexception(new NullPointerException());
            return querycitylistresponse2;
        } catch (Exception e) {
            queryCityListResponse querycitylistresponse3 = new queryCityListResponse();
            querycitylistresponse3.setexception(e);
            return querycitylistresponse3;
        }
    }

    public queryCheckInMessageResponse queryCheckInMessage(queryCheckInMessage parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryCheckInMessage", parameters);
        }
        queryCheckInMessageResponse querycheckinmessageresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryCheckInMessageResponse)) {
                    querycheckinmessageresponse = (queryCheckInMessageResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querycheckinmessageresponse = new queryCheckInMessageResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querycheckinmessageresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querycheckinmessageresponse != null) {
                return querycheckinmessageresponse;
            }
            queryCheckInMessageResponse querycheckinmessageresponse2 = new queryCheckInMessageResponse();
            querycheckinmessageresponse2.setexception(new NullPointerException());
            return querycheckinmessageresponse2;
        } catch (Exception e) {
            queryCheckInMessageResponse querycheckinmessageresponse3 = new queryCheckInMessageResponse();
            querycheckinmessageresponse3.setexception(e);
            return querycheckinmessageresponse3;
        }
    }

    public queryCityListByPlatResponse queryCityListByPlat(queryCityListByPlat parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryCityListByPlat", parameters);
        }
        queryCityListByPlatResponse querycitylistbyplatresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryCityListByPlatResponse)) {
                    querycitylistbyplatresponse = (queryCityListByPlatResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querycitylistbyplatresponse = new queryCityListByPlatResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querycitylistbyplatresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querycitylistbyplatresponse != null) {
                return querycitylistbyplatresponse;
            }
            queryCityListByPlatResponse querycitylistbyplatresponse2 = new queryCityListByPlatResponse();
            querycitylistbyplatresponse2.setexception(new NullPointerException());
            return querycitylistbyplatresponse2;
        } catch (Exception e) {
            queryCityListByPlatResponse querycitylistbyplatresponse3 = new queryCityListByPlatResponse();
            querycitylistbyplatresponse3.setexception(e);
            return querycitylistbyplatresponse3;
        }
    }

    public queryHotelCityListResponse queryHotelCityList(queryHotelCityList parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryHotelCityList", parameters);
        }
        queryHotelCityListResponse queryhotelcitylistresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryHotelCityListResponse)) {
                    queryhotelcitylistresponse = (queryHotelCityListResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    queryhotelcitylistresponse = new queryHotelCityListResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    queryhotelcitylistresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (queryhotelcitylistresponse != null) {
                return queryhotelcitylistresponse;
            }
            queryHotelCityListResponse queryhotelcitylistresponse2 = new queryHotelCityListResponse();
            queryhotelcitylistresponse2.setexception(new NullPointerException());
            return queryhotelcitylistresponse2;
        } catch (Exception e) {
            queryHotelCityListResponse queryhotelcitylistresponse3 = new queryHotelCityListResponse();
            queryhotelcitylistresponse3.setexception(e);
            return queryhotelcitylistresponse3;
        }
    }

    public querySegmentTipsResponse querySegmentTips(querySegmentTips parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("querySegmentTips", parameters);
        }
        querySegmentTipsResponse querysegmenttipsresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof querySegmentTipsResponse)) {
                    querysegmenttipsresponse = (querySegmentTipsResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querysegmenttipsresponse = new querySegmentTipsResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querysegmenttipsresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querysegmenttipsresponse != null) {
                return querysegmenttipsresponse;
            }
            querySegmentTipsResponse querysegmenttipsresponse2 = new querySegmentTipsResponse();
            querysegmenttipsresponse2.setexception(new NullPointerException());
            return querysegmenttipsresponse2;
        } catch (Exception e) {
            querySegmentTipsResponse querysegmenttipsresponse3 = new querySegmentTipsResponse();
            querysegmenttipsresponse3.setexception(e);
            return querysegmenttipsresponse3;
        }
    }

    public querySegTipsResponse querySegTips(querySegTips parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("querySegTips", parameters);
        }
        querySegTipsResponse querysegtipsresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof querySegTipsResponse)) {
                    querysegtipsresponse = (querySegTipsResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querysegtipsresponse = new querySegTipsResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querysegtipsresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querysegtipsresponse != null) {
                return querysegtipsresponse;
            }
            querySegTipsResponse querysegtipsresponse2 = new querySegTipsResponse();
            querysegtipsresponse2.setexception(new NullPointerException());
            return querysegtipsresponse2;
        } catch (Exception e) {
            querySegTipsResponse querysegtipsresponse3 = new querySegTipsResponse();
            querysegtipsresponse3.setexception(e);
            return querysegtipsresponse3;
        }
    }
}