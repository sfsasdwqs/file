package com.common.szair.model.city;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class segTipsInfoVO extends baseDTOVO implements SOAPObject, Serializable {
    public String _IF_RED = null;
    public String _SEG_TIPS = null;
    public String _ALL_TIPS = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/common";
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._IF_RED != null) {
            xml.startTag(null, "IF_RED");
            xml.text(this._IF_RED);
            xml.endTag(null, "IF_RED");
        }
        if (this._SEG_TIPS != null) {
            xml.startTag(null, "SEG_TIPS");
            xml.text(this._SEG_TIPS);
            xml.endTag(null, "SEG_TIPS");
        }
        if (this._ALL_TIPS != null) {
            xml.startTag(null, "SEGMENT_TIPS");
            xml.text(this._ALL_TIPS);
            xml.endTag(null, "SEGMENT_TIPS");
        }
    }

    @Override // com.common.szair.model.city.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("IF_RED".equals(parser.getName())) {
                        this._IF_RED = parser.nextText();
                    } else if ("SEG_TIPS".equals(parser.getName())) {
                        this._SEG_TIPS = parser.nextText();
                    } else if ("SEGMENT_TIPS".equals(parser.getName())) {
                        this._ALL_TIPS = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}