package com.common.szair.model.city;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class cityWeatherInfo {
    public String _FULL_NAME = null;
    public String _PY_NAME = null;
    public String _SHORT_NAME = null;
    public String _CITY_TYPE = null;
    public String WEATHER_CITY_CODE = null;
}