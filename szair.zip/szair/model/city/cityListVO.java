package com.common.szair.model.city;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class cityListVO implements SOAPObject {
    public String _AIRPORT = null;
    public String _FC_NAME = null;
    public String _FULL_NAME = null;
    public String _IS_CKI = null;
    public String _PY_NAME = null;
    public String _SHORT_NAME = null;
    public String _SORT_NO = null;
    public String _CITY_TYPE = null;
    public String _AIRPORT_EN = null;
    public String _AIRPORT_TDN = null;
    public String _FULLNAME_EN = null;
    public String _FULLNAME_TDN = null;
    public String _IS_HOT = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/common";
    }

    public String toString() {
        return "cityListVO [_AIRPORT=" + this._AIRPORT + ", _FC_NAME=" + this._FC_NAME + ", _FULL_NAME=" + this._FULL_NAME + ", _IS_CKI=" + this._IS_CKI + ", _PY_NAME=" + this._PY_NAME + ", _SHORT_NAME=" + this._SHORT_NAME + ", _AIRPORT_EN=" + this._AIRPORT_EN + ", _AIRPORT_TDN=" + this._AIRPORT_TDN + ", _FULLNAME_EN=" + this._FULLNAME_EN + ", _FULLNAME_TDN=" + this._FULLNAME_TDN + ", _SORT_NO=" + this._SORT_NO + "]";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._AIRPORT != null) {
            xml.startTag(null, "AIRPORT");
            xml.text(this._AIRPORT);
            xml.endTag(null, "AIRPORT");
        }
        if (this._FC_NAME != null) {
            xml.startTag(null, "FC_NAME");
            xml.text(this._FC_NAME);
            xml.endTag(null, "FC_NAME");
        }
        if (this._FULL_NAME != null) {
            xml.startTag(null, "FULL_NAME");
            xml.text(this._FULL_NAME);
            xml.endTag(null, "FULL_NAME");
        }
        if (this._IS_CKI != null) {
            xml.startTag(null, "IS_CKI");
            xml.text(this._IS_CKI);
            xml.endTag(null, "IS_CKI");
        }
        if (this._PY_NAME != null) {
            xml.startTag(null, "PY_NAME");
            xml.text(this._PY_NAME);
            xml.endTag(null, "PY_NAME");
        }
        if (this._SHORT_NAME != null) {
            xml.startTag(null, "SHORT_NAME");
            xml.text(this._SHORT_NAME);
            xml.endTag(null, "SHORT_NAME");
        }
        if (this._CITY_TYPE != null) {
            xml.startTag(null, "CITY_TYPE");
            xml.text(this._CITY_TYPE);
            xml.endTag(null, "CITY_TYPE");
        }
        if (this._AIRPORT_EN != null) {
            xml.startTag(null, "AIRPORT_EN");
            xml.text(this._AIRPORT_EN);
            xml.endTag(null, "AIRPORT_EN");
        }
        if (this._AIRPORT_TDN != null) {
            xml.startTag(null, "AIRPORT_TDN");
            xml.text(this._AIRPORT_TDN);
            xml.endTag(null, "AIRPORT_TDN");
        }
        if (this._FULLNAME_EN != null) {
            xml.startTag(null, "FULLNAME_EN");
            xml.text(this._FULLNAME_EN);
            xml.endTag(null, "FULLNAME_EN");
        }
        if (this._FULLNAME_TDN != null) {
            xml.startTag(null, "FULLNAME_TDN");
            xml.text(this._FULLNAME_TDN);
            xml.endTag(null, "FULLNAME_TDN");
        }
        if (this._IS_HOT != null) {
            xml.startTag(null, "IS_HOT");
            xml.text(this._IS_HOT);
            xml.endTag(null, "IS_HOT");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("AIRPORT".equals(parser.getName())) {
                        this._AIRPORT = parser.nextText();
                    } else if ("FC_NAME".equals(parser.getName())) {
                        this._FC_NAME = parser.nextText();
                    } else if ("FULL_NAME".equals(parser.getName())) {
                        this._FULL_NAME = parser.nextText();
                    } else if ("IS_CKI".equals(parser.getName())) {
                        this._IS_CKI = parser.nextText();
                    } else if ("PY_NAME".equals(parser.getName())) {
                        this._PY_NAME = parser.nextText();
                    } else if ("SHORT_NAME".equals(parser.getName())) {
                        this._SHORT_NAME = parser.nextText();
                    } else if ("CITY_TYPE".equals(parser.getName())) {
                        this._CITY_TYPE = parser.nextText();
                    } else if ("AIRPORT_EN".equals(parser.getName())) {
                        this._AIRPORT_EN = parser.nextText();
                    } else if ("AIRPORT_TDN".equals(parser.getName())) {
                        this._AIRPORT_TDN = parser.nextText();
                    } else if ("FULLNAME_EN".equals(parser.getName())) {
                        this._FULLNAME_EN = parser.nextText();
                    } else if ("FULLNAME_TDN".equals(parser.getName())) {
                        this._FULLNAME_TDN = parser.nextText();
                    } else if ("IS_HOT".equals(parser.getName())) {
                        this._IS_HOT = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}