package com.common.szair.model.bank;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class bankListVO implements SOAPObject {
    public String _BANK_ID = null;
    public String _BANK_NAME = null;
    public String _INTERFACE_TYPE = null;
    public String _SORT_NO = null;
    public String _PREPAY = null;
    public String _ABLEFLG = null;
    public String _BANKNAME_EN = null;
    public String _BANKNAME_TDN = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/booking";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._BANK_ID != null) {
            xml.startTag(null, "BANK_ID");
            xml.text(this._BANK_ID);
            xml.endTag(null, "BANK_ID");
        }
        if (this._BANK_NAME != null) {
            xml.startTag(null, "BANK_NAME");
            xml.text(this._BANK_NAME);
            xml.endTag(null, "BANK_NAME");
        }
        if (this._INTERFACE_TYPE != null) {
            xml.startTag(null, "INTERFACE_TYPE");
            xml.text(this._INTERFACE_TYPE);
            xml.endTag(null, "INTERFACE_TYPE");
        }
        if (this._PREPAY != null) {
            xml.startTag(null, "PREPAY");
            xml.text(this._PREPAY);
            xml.endTag(null, "PREPAY");
        }
        if (this._ABLEFLG != null) {
            xml.startTag(null, "ABLEFLG");
            xml.text(this._ABLEFLG);
            xml.endTag(null, "ABLEFLG");
        }
        if (this._BANKNAME_EN != null) {
            xml.startTag(null, "BANKNAME_EN");
            xml.text(this._BANKNAME_EN);
            xml.endTag(null, "BANKNAME_EN");
        }
        if (this._BANKNAME_TDN != null) {
            xml.startTag(null, "BANKNAME_TDN");
            xml.text(this._BANKNAME_TDN);
            xml.endTag(null, "BANKNAME_TDN");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("BANK_ID".equals(parser.getName())) {
                        this._BANK_ID = parser.nextText();
                    } else if ("BANK_NAME".equals(parser.getName())) {
                        this._BANK_NAME = parser.nextText();
                    } else if ("INTERFACE_TYPE".equals(parser.getName())) {
                        this._INTERFACE_TYPE = parser.nextText();
                    } else if ("PREPAY".equals(parser.getName())) {
                        this._PREPAY = parser.nextText();
                    } else if ("ABLEFLG".equals(parser.getName())) {
                        this._ABLEFLG = parser.nextText();
                    } else if ("BANKNAME_EN".equals(parser.getName())) {
                        this._BANKNAME_EN = parser.nextText();
                    } else if ("BANKNAME_TDN".equals(parser.getName())) {
                        this._BANKNAME_TDN = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}