package com.common.szair.model.bank;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class BankListWebServiceServiceSoapBinding extends SOAPBinding {
    public BankListWebServiceServiceSoapBinding(String endpoint) {
        super(BankListWebServiceServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns4", "http://impl.webservice.booking.shenzhenair.com/");
        hashMap.put("ns2", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        hashMap.put("ns1", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns3", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns0", "http://com/shenzhenair/mobilewebservice/booking");
        return hashMap;
    }

    public queryBankListResponse queryBankList(queryBankList parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryBankList", parameters);
        }
        queryBankListResponse querybanklistresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryBankListResponse)) {
                    querybanklistresponse = (queryBankListResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querybanklistresponse = new queryBankListResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querybanklistresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querybanklistresponse != null) {
                return querybanklistresponse;
            }
            queryBankListResponse querybanklistresponse2 = new queryBankListResponse();
            querybanklistresponse2.setexception(new NullPointerException());
            return querybanklistresponse2;
        } catch (Exception e) {
            queryBankListResponse querybanklistresponse3 = new queryBankListResponse();
            querybanklistresponse3.setexception(e);
            return querybanklistresponse3;
        }
    }

    public queryPreBankListResponse queryPreBankList(queryPreBankList parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryPreBankList", parameters);
        }
        queryPreBankListResponse queryprebanklistresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryPreBankListResponse)) {
                    queryprebanklistresponse = (queryPreBankListResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    queryprebanklistresponse = new queryPreBankListResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    queryprebanklistresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (queryprebanklistresponse != null) {
                return queryprebanklistresponse;
            }
            queryPreBankListResponse queryprebanklistresponse2 = new queryPreBankListResponse();
            queryprebanklistresponse2.setexception(new NullPointerException());
            return queryprebanklistresponse2;
        } catch (Exception e) {
            queryPreBankListResponse queryprebanklistresponse3 = new queryPreBankListResponse();
            queryprebanklistresponse3.setexception(e);
            return queryprebanklistresponse3;
        }
    }
}