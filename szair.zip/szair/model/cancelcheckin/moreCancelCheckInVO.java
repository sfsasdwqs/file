package com.common.szair.model.cancelcheckin;

import com.air.sz.ui.consts.UIConst;
import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class moreCancelCheckInVO implements SOAPObject {
    public List<cancelcheckIntResultVO> _CANCEL_CHECK_IN_LIST = null;
    public String _MOBILE = null;
    public String _RESCHEDULE_INFO_UUID = null;
    public String _CLICK_COUNT = null;
    public String _MULTI_PEOPLE = null;
    public String _CANCEL_TYPE = null;
    public String _FLIGHT_TYPE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        List<cancelcheckIntResultVO> list = this._CANCEL_CHECK_IN_LIST;
        if (list != null && list.size() > 0) {
            int size = this._CANCEL_CHECK_IN_LIST.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "CANCEL_CHECK_IN_LIST");
                this._CANCEL_CHECK_IN_LIST.get(i).addElementsToNode(xml);
                xml.endTag(null, "CANCEL_CHECK_IN_LIST");
            }
        }
        if (this._MOBILE != null) {
            xml.startTag(null, UIConst.REGIST_WAY);
            xml.text(this._MOBILE);
            xml.endTag(null, UIConst.REGIST_WAY);
        }
        if (this._RESCHEDULE_INFO_UUID != null) {
            xml.startTag(null, "RESCHEDULE_INFO_UUID");
            xml.text(this._RESCHEDULE_INFO_UUID);
            xml.endTag(null, "RESCHEDULE_INFO_UUID");
        }
        if (this._CLICK_COUNT != null) {
            xml.startTag(null, "CLICK_COUNT");
            xml.text(this._CLICK_COUNT);
            xml.endTag(null, "CLICK_COUNT");
        }
        if (this._MULTI_PEOPLE != null) {
            xml.startTag(null, "MULTI_PEOPLE");
            xml.text(this._MULTI_PEOPLE);
            xml.endTag(null, "MULTI_PEOPLE");
        }
        if (this._CANCEL_TYPE != null) {
            xml.startTag(null, "CANCEL_TYPE");
            xml.text(this._CANCEL_TYPE);
            xml.endTag(null, "CANCEL_TYPE");
        }
        if (this._FLIGHT_TYPE != null) {
            xml.startTag(null, "FLIGHT_TYPE");
            xml.text(this._FLIGHT_TYPE);
            xml.endTag(null, "FLIGHT_TYPE");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CANCEL_CHECK_IN_LIST".equals(parser.getName())) {
                        if (this._CANCEL_CHECK_IN_LIST == null) {
                            this._CANCEL_CHECK_IN_LIST = new ArrayList();
                        }
                        cancelcheckIntResultVO cancelcheckintresultvo = new cancelcheckIntResultVO();
                        cancelcheckintresultvo.parse(binding, parser);
                        this._CANCEL_CHECK_IN_LIST.add(cancelcheckintresultvo);
                    } else if (UIConst.REGIST_WAY.equals(parser.getName())) {
                        this._MOBILE = parser.nextText();
                    } else if ("RESCHEDULE_INFO_UUID".equals(parser.getName())) {
                        this._RESCHEDULE_INFO_UUID = parser.nextText();
                    } else if ("CLICK_COUNT".equals(parser.getName())) {
                        this._CLICK_COUNT = parser.nextText();
                    } else if ("MULTI_PEOPLE".equals(parser.getName())) {
                        this._MULTI_PEOPLE = parser.nextText();
                    } else if ("CANCEL_TYPE".equals(parser.getName())) {
                        this._CANCEL_TYPE = parser.nextText();
                    } else if ("FLIGHT_TYPE".equals(parser.getName())) {
                        this._FLIGHT_TYPE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}