package com.common.szair.model.cancelcheckin;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class cancelcheckIntPassengerListVO implements SOAPObject {
    public String _CLASS_CODE = null;
    public String _DISCOUNT = null;
    public String _SPOLCODE = null;
    public String _HANDLING = null;
    public String _PARTNER_UUID = null;
    public String _PRODUCT_VALUE = null;
    public String _PRICE = null;
    public String _UPGRADE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CLASS_CODE != null) {
            xml.startTag(null, "CLASS_CODE");
            xml.text(this._CLASS_CODE);
            xml.endTag(null, "CLASS_CODE");
        }
        if (this._DISCOUNT != null) {
            xml.startTag(null, "DISCOUNT");
            xml.text(this._DISCOUNT);
            xml.endTag(null, "DISCOUNT");
        }
        if (this._SPOLCODE != null) {
            xml.startTag(null, "SPOLCODE");
            xml.text(this._SPOLCODE);
            xml.endTag(null, "SPOLCODE");
        }
        if (this._HANDLING != null) {
            xml.startTag(null, "HANDLING");
            xml.text(this._HANDLING);
            xml.endTag(null, "HANDLING");
        }
        if (this._PARTNER_UUID != null) {
            xml.startTag(null, "PARTNER_UUID");
            xml.text(this._PARTNER_UUID);
            xml.endTag(null, "PARTNER_UUID");
        }
        if (this._PRODUCT_VALUE != null) {
            xml.startTag(null, "PRODUCT_VALUE");
            xml.text(this._PRODUCT_VALUE);
            xml.endTag(null, "PRODUCT_VALUE");
        }
        if (this._PRICE != null) {
            xml.startTag(null, "PRICE");
            xml.text(this._PRICE);
            xml.endTag(null, "PRICE");
        }
        if (this._UPGRADE != null) {
            xml.startTag(null, "UPGRADE");
            xml.text(this._UPGRADE);
            xml.endTag(null, "UPGRADE");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CLASS_CODE".equals(parser.getName())) {
                        this._CLASS_CODE = parser.nextText();
                    } else if ("DISCOUNT".equals(parser.getName())) {
                        this._DISCOUNT = parser.nextText();
                    } else if ("SPOLCODE".equals(parser.getName())) {
                        this._SPOLCODE = parser.nextText();
                    } else if ("HANDLING".equals(parser.getName())) {
                        this._HANDLING = parser.nextText();
                    } else if ("PARTNER_UUID".equals(parser.getName())) {
                        this._PARTNER_UUID = parser.nextText();
                    } else if ("PRODUCT_VALUE".equals(parser.getName())) {
                        this._PRODUCT_VALUE = parser.nextText();
                    } else if ("PRICE".equals(parser.getName())) {
                        this._PRICE = parser.nextText();
                    } else if ("UPGRADE".equals(parser.getName())) {
                        this._UPGRADE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}