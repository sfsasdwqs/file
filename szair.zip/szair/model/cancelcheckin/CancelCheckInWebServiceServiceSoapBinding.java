package com.common.szair.model.cancelcheckin;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class CancelCheckInWebServiceServiceSoapBinding extends SOAPBinding {
    public CancelCheckInWebServiceServiceSoapBinding(String endpoint) {
        super(CancelCheckInWebServiceServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns3", "http://impl.webservice.checkin.shenzhenair.com/");
        hashMap.put("ns4", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns2", "http://com/shenzhenair/mobilewebservice/checkin");
        hashMap.put("ns1", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns0", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        return hashMap;
    }

    public delPsrCheckinResponse delPsrCheckin(delPsrCheckin parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("delPsrCheckin", parameters);
        }
        delPsrCheckinResponse delpsrcheckinresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof delPsrCheckinResponse)) {
                    delpsrcheckinresponse = (delPsrCheckinResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    delpsrcheckinresponse = new delPsrCheckinResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    delpsrcheckinresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (delpsrcheckinresponse != null) {
                return delpsrcheckinresponse;
            }
            delPsrCheckinResponse delpsrcheckinresponse2 = new delPsrCheckinResponse();
            delpsrcheckinresponse2.setexception(new NullPointerException());
            return delpsrcheckinresponse2;
        } catch (Exception e) {
            delPsrCheckinResponse delpsrcheckinresponse3 = new delPsrCheckinResponse();
            delpsrcheckinresponse3.setexception(e);
            return delpsrcheckinresponse3;
        }
    }

    public delMorePsrCheckinResponse delMorePsrCheckin(delMorePsrCheckin parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("delMorePsrCheckin", parameters);
        }
        delMorePsrCheckinResponse delmorepsrcheckinresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof delMorePsrCheckinResponse)) {
                    delmorepsrcheckinresponse = (delMorePsrCheckinResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    delmorepsrcheckinresponse = new delMorePsrCheckinResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    delmorepsrcheckinresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (delmorepsrcheckinresponse != null) {
                return delmorepsrcheckinresponse;
            }
            delMorePsrCheckinResponse delmorepsrcheckinresponse2 = new delMorePsrCheckinResponse();
            delmorepsrcheckinresponse2.setexception(new NullPointerException());
            return delmorepsrcheckinresponse2;
        } catch (Exception e) {
            delMorePsrCheckinResponse delmorepsrcheckinresponse3 = new delMorePsrCheckinResponse();
            delmorepsrcheckinresponse3.setexception(e);
            return delmorepsrcheckinresponse3;
        }
    }

    public delEmdMorePsrCheckinResponse delEmdMorePsrCheckin(delEmdMorePsrCheckin parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("delEmdMorePsrCheckin", parameters);
        }
        delEmdMorePsrCheckinResponse delemdmorepsrcheckinresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof delEmdMorePsrCheckinResponse)) {
                    delemdmorepsrcheckinresponse = (delEmdMorePsrCheckinResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    delemdmorepsrcheckinresponse = new delEmdMorePsrCheckinResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    delemdmorepsrcheckinresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (delemdmorepsrcheckinresponse != null) {
                return delemdmorepsrcheckinresponse;
            }
            delEmdMorePsrCheckinResponse delemdmorepsrcheckinresponse2 = new delEmdMorePsrCheckinResponse();
            delemdmorepsrcheckinresponse2.setexception(new NullPointerException());
            return delemdmorepsrcheckinresponse2;
        } catch (Exception e) {
            delEmdMorePsrCheckinResponse delemdmorepsrcheckinresponse3 = new delEmdMorePsrCheckinResponse();
            delemdmorepsrcheckinresponse3.setexception(e);
            return delemdmorepsrcheckinresponse3;
        }
    }
}