package com.common.szair.model.cancelcheckin;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class cancelMoreCheckInVO implements SOAPObject {
    public List<checkInTicketVO> _TICKETS = null;
    public String _CODE = null;
    public String _PHONE = null;
    public String _ORDER_NO = null;
    public String _QUERY_TYPE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        List<checkInTicketVO> list = this._TICKETS;
        if (list != null && list.size() > 0) {
            int size = this._TICKETS.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "TICKETS");
                this._TICKETS.get(i).addElementsToNode(xml);
                xml.endTag(null, "TICKETS");
            }
        }
        if (this._CODE != null) {
            xml.startTag(null, "CODE");
            xml.text(this._CODE);
            xml.endTag(null, "CODE");
        }
        if (this._PHONE != null) {
            xml.startTag(null, "PHONE");
            xml.text(this._PHONE);
            xml.endTag(null, "PHONE");
        }
        if (this._ORDER_NO != null) {
            xml.startTag(null, "ORDER_NO");
            xml.text(this._ORDER_NO);
            xml.endTag(null, "ORDER_NO");
        }
        if (this._QUERY_TYPE != null) {
            xml.startTag(null, "QUERY_TYPE");
            xml.text(this._QUERY_TYPE);
            xml.endTag(null, "QUERY_TYPE");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("TICKETS".equals(parser.getName())) {
                        if (this._TICKETS == null) {
                            this._TICKETS = new ArrayList();
                        }
                        checkInTicketVO checkinticketvo = new checkInTicketVO();
                        checkinticketvo.parse(binding, parser);
                        this._TICKETS.add(checkinticketvo);
                    } else if ("CODE".equals(parser.getName())) {
                        this._CODE = parser.nextText();
                    } else if ("PHONE".equals(parser.getName())) {
                        this._PHONE = parser.nextText();
                    } else if ("ORDER_NO".equals(parser.getName())) {
                        this._ORDER_NO = parser.nextText();
                    } else if ("QUERY_TYPE".equals(parser.getName())) {
                        this._QUERY_TYPE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}