package com.common.szair.model.cancelcheckin;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class emdCheckInTicketResultVO extends baseDTOVO implements SOAPObject, Serializable {
    public String _FLIGHT_DATE = null;
    public String _FLIGHT_NO = null;
    public String _FROM_CITY = null;
    public String _REFUND_ORDER_NO = null;
    public String _RETURN_CODE = null;
    public String _RETURN_COUPON_ID = null;
    public String _RETURN_MILEAGE = null;
    public String _RETURN_MSG = null;
    public String _SEAT_NO = null;
    public String _TICKET_NO = null;
    public String _TO_CITY = null;
    public String _PSGR_NAME = null;
    public String _IS_INIT = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.cancelcheckin.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.cancelcheckin.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.cancelcheckin.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.cancelcheckin.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.cancelcheckin.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.cancelcheckin.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._FLIGHT_DATE != null) {
            xml.startTag(null, "FLIGHT_DATE");
            xml.text(this._FLIGHT_DATE);
            xml.endTag(null, "FLIGHT_DATE");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._FROM_CITY != null) {
            xml.startTag(null, "FROM_CITY");
            xml.text(this._FROM_CITY);
            xml.endTag(null, "FROM_CITY");
        }
        if (this._REFUND_ORDER_NO != null) {
            xml.startTag(null, "REFUND_ORDER_NO");
            xml.text(this._REFUND_ORDER_NO);
            xml.endTag(null, "REFUND_ORDER_NO");
        }
        if (this._RETURN_CODE != null) {
            xml.startTag(null, "RETURN_CODE");
            xml.text(this._RETURN_CODE);
            xml.endTag(null, "RETURN_CODE");
        }
        if (this._RETURN_COUPON_ID != null) {
            xml.startTag(null, "RETURN_COUPON_ID");
            xml.text(this._RETURN_COUPON_ID);
            xml.endTag(null, "RETURN_COUPON_ID");
        }
        if (this._RETURN_MILEAGE != null) {
            xml.startTag(null, "RETURN_MILEAGE");
            xml.text(this._RETURN_MILEAGE);
            xml.endTag(null, "RETURN_MILEAGE");
        }
        if (this._RETURN_MSG != null) {
            xml.startTag(null, "RETURN_MSG");
            xml.text(this._RETURN_MSG);
            xml.endTag(null, "RETURN_MSG");
        }
        if (this._SEAT_NO != null) {
            xml.startTag(null, "SEAT_NO");
            xml.text(this._SEAT_NO);
            xml.endTag(null, "SEAT_NO");
        }
        if (this._TICKET_NO != null) {
            xml.startTag(null, "TICKET_NO");
            xml.text(this._TICKET_NO);
            xml.endTag(null, "TICKET_NO");
        }
        if (this._TO_CITY != null) {
            xml.startTag(null, "TO_CITY");
            xml.text(this._TO_CITY);
            xml.endTag(null, "TO_CITY");
        }
        if (this._PSGR_NAME != null) {
            xml.startTag(null, "PSGR_NAME");
            xml.text(this._PSGR_NAME);
            xml.endTag(null, "PSGR_NAME");
        }
        if (this._IS_INIT != null) {
            xml.startTag(null, "IS_INIT");
            xml.text(this._IS_INIT);
            xml.endTag(null, "IS_INIT");
        }
    }

    @Override // com.common.szair.model.cancelcheckin.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("FLIGHT_DATE".equals(parser.getName())) {
                        this._FLIGHT_DATE = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("FROM_CITY".equals(parser.getName())) {
                        this._FROM_CITY = parser.nextText();
                    } else if ("REFUND_ORDER_NO".equals(parser.getName())) {
                        this._REFUND_ORDER_NO = parser.nextText();
                    } else if ("RETURN_CODE".equals(parser.getName())) {
                        this._RETURN_CODE = parser.nextText();
                    } else if ("RETURN_COUPON_ID".equals(parser.getName())) {
                        this._RETURN_COUPON_ID = parser.nextText();
                    } else if ("RETURN_MILEAGE".equals(parser.getName())) {
                        this._RETURN_MILEAGE = parser.nextText();
                    } else if ("RETURN_MSG".equals(parser.getName())) {
                        this._RETURN_MSG = parser.nextText();
                    } else if ("SEAT_NO".equals(parser.getName())) {
                        this._SEAT_NO = parser.nextText();
                    } else if ("TICKET_NO".equals(parser.getName())) {
                        this._TICKET_NO = parser.nextText();
                    } else if ("TO_CITY".equals(parser.getName())) {
                        this._TO_CITY = parser.nextText();
                    } else if ("PSGR_NAME".equals(parser.getName())) {
                        this._PSGR_NAME = parser.nextText();
                    } else if ("IS_INIT".equals(parser.getName())) {
                        this._IS_INIT = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}