package com.common.szair.model.clientversion;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class clientVersionResultVO extends bookingResponseBaseVO implements SOAPObject {
    public String _DATA_KEY = null;
    public String _DATA_VALUE1 = null;
    public String _DATA_VALUE2 = null;
    public String _DATA_VALUE3 = null;
    public String _DATA_FLAG = null;
    public String _DATA_MESSAGE = null;
    public String _OP_RESULT = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.clientversion.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.clientversion.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/mobilemaster";
    }

    @Override // com.common.szair.model.clientversion.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.clientversion.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.clientversion.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.clientversion.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._DATA_KEY != null) {
            xml.startTag(null, "DATA_KEY");
            xml.text(this._DATA_KEY);
            xml.endTag(null, "DATA_KEY");
        }
        if (this._DATA_VALUE1 != null) {
            xml.startTag(null, "DATA_VALUE1");
            xml.text(this._DATA_VALUE1);
            xml.endTag(null, "DATA_VALUE1");
        }
        if (this._DATA_VALUE2 != null) {
            xml.startTag(null, "DATA_VALUE2");
            xml.text(this._DATA_VALUE2);
            xml.endTag(null, "DATA_VALUE2");
        }
        if (this._DATA_VALUE3 != null) {
            xml.startTag(null, "DATA_VALUE3");
            xml.text(this._DATA_VALUE3);
            xml.endTag(null, "DATA_VALUE3");
        }
        if (this._DATA_FLAG != null) {
            xml.startTag(null, "DATA_FLAG");
            xml.text(this._DATA_FLAG);
            xml.endTag(null, "DATA_FLAG");
        }
        if (this._DATA_MESSAGE != null) {
            xml.startTag(null, "DATA_MESSAGE");
            xml.text(this._DATA_MESSAGE);
            xml.endTag(null, "DATA_MESSAGE");
        }
        if (this._OP_RESULT != null) {
            xml.startTag(null, "OP_RESULT");
            xml.text(this._OP_RESULT);
            xml.endTag(null, "OP_RESULT");
        }
    }

    @Override // com.common.szair.model.clientversion.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("DATA_KEY".equals(parser.getName())) {
                        this._DATA_KEY = parser.nextText();
                    } else if ("DATA_VALUE1".equals(parser.getName())) {
                        this._DATA_VALUE1 = parser.nextText();
                    } else if ("DATA_VALUE2".equals(parser.getName())) {
                        this._DATA_VALUE2 = parser.nextText();
                    } else if ("DATA_VALUE3".equals(parser.getName())) {
                        this._DATA_VALUE3 = parser.nextText();
                    } else if ("DATA_FLAG".equals(parser.getName())) {
                        this._DATA_FLAG = parser.nextText();
                    } else if ("DATA_MESSAGE".equals(parser.getName())) {
                        this._DATA_MESSAGE = parser.nextText();
                    } else if ("OP_RESULT".equals(parser.getName())) {
                        this._OP_RESULT = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}