package com.common.szair.model.clientversion;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class MobileMasterClientVersionWebServiceServiceSoapBinding extends SOAPBinding {
    public MobileMasterClientVersionWebServiceServiceSoapBinding(String endpoint) {
        super(MobileMasterClientVersionWebServiceServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns2", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        hashMap.put("ns1", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns0", "http://com/shenzhenair/mobilewebservice/mobilemaster");
        hashMap.put("ns4", "http://impl.webservice.common.shenzhenair.com/");
        hashMap.put("ns3", "http://schemas.xmlsoap.org/soap/http");
        return hashMap;
    }

    public queryClientVersionResponse queryClientVersion(queryClientVersion parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryClientVersion", parameters);
        }
        queryClientVersionResponse queryclientversionresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryClientVersionResponse)) {
                    queryclientversionresponse = (queryClientVersionResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    queryclientversionresponse = new queryClientVersionResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    queryclientversionresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (queryclientversionresponse != null) {
                return queryclientversionresponse;
            }
            queryClientVersionResponse queryclientversionresponse2 = new queryClientVersionResponse();
            queryclientversionresponse2.setexception(new NullPointerException());
            return queryclientversionresponse2;
        } catch (Exception e) {
            queryClientVersionResponse queryclientversionresponse3 = new queryClientVersionResponse();
            queryclientversionresponse3.setexception(e);
            return queryclientversionresponse3;
        }
    }
}