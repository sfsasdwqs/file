package com.common.szair.model.appcomment;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class feedbackResultVO implements SOAPObject {
    public List<feedbackInfoVO> _FEEDBACK_LIST = null;
    public String _INFO = null;
    public String _ORDER_NO = null;
    public String _RSP_CODE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/common";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        List<feedbackInfoVO> list = this._FEEDBACK_LIST;
        if (list != null && list.size() > 0) {
            int size = this._FEEDBACK_LIST.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "FEEDBACK_LIST");
                this._FEEDBACK_LIST.get(i).addElementsToNode(xml);
                xml.endTag(null, "FEEDBACK_LIST");
            }
        }
        if (this._INFO != null) {
            xml.startTag(null, "INFO");
            xml.text(this._INFO);
            xml.endTag(null, "INFO");
        }
        if (this._ORDER_NO != null) {
            xml.startTag(null, "ORDER_NO");
            xml.text(this._ORDER_NO);
            xml.endTag(null, "ORDER_NO");
        }
        if (this._RSP_CODE != null) {
            xml.startTag(null, "RSP_CODE");
            xml.text(this._RSP_CODE);
            xml.endTag(null, "RSP_CODE");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("FEEDBACK_LIST".equals(parser.getName())) {
                        if (this._FEEDBACK_LIST == null) {
                            this._FEEDBACK_LIST = new ArrayList();
                        }
                        feedbackInfoVO feedbackinfovo = new feedbackInfoVO();
                        feedbackinfovo.parse(binding, parser);
                        this._FEEDBACK_LIST.add(feedbackinfovo);
                    } else if ("INFO".equals(parser.getName())) {
                        this._INFO = parser.nextText();
                    } else if ("ORDER_NO".equals(parser.getName())) {
                        this._ORDER_NO = parser.nextText();
                    } else if ("RSP_CODE".equals(parser.getName())) {
                        this._RSP_CODE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}