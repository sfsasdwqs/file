package com.common.szair.model.appcomment;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class feedbackConditionVO implements SOAPObject {
    public String _CERT_NO = null;
    public String _ORDER_NO = null;
    public String _PAGE_INDEX = null;
    public String _PASSENGER_NAME = null;
    public String _PER_PAGE = null;
    public String _TELE_PHONE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/common";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CERT_NO != null) {
            xml.startTag(null, "CERT_NO");
            xml.text(this._CERT_NO);
            xml.endTag(null, "CERT_NO");
        }
        if (this._ORDER_NO != null) {
            xml.startTag(null, "ORDER_NO");
            xml.text(this._ORDER_NO);
            xml.endTag(null, "ORDER_NO");
        }
        if (this._PAGE_INDEX != null) {
            xml.startTag(null, "PAGE_INDEX");
            xml.text(this._PAGE_INDEX);
            xml.endTag(null, "PAGE_INDEX");
        }
        if (this._PASSENGER_NAME != null) {
            xml.startTag(null, "PASSENGER_NAME");
            xml.text(this._PASSENGER_NAME);
            xml.endTag(null, "PASSENGER_NAME");
        }
        if (this._PER_PAGE != null) {
            xml.startTag(null, "PER_PAGE");
            xml.text(this._PER_PAGE);
            xml.endTag(null, "PER_PAGE");
        }
        if (this._TELE_PHONE != null) {
            xml.startTag(null, "TELE_PHONE");
            xml.text(this._TELE_PHONE);
            xml.endTag(null, "TELE_PHONE");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CERT_NO".equals(parser.getName())) {
                        this._CERT_NO = parser.nextText();
                    } else if ("ORDER_NO".equals(parser.getName())) {
                        this._ORDER_NO = parser.nextText();
                    } else if ("PAGE_INDEX".equals(parser.getName())) {
                        this._PAGE_INDEX = parser.nextText();
                    } else if ("PASSENGER_NAME".equals(parser.getName())) {
                        this._PASSENGER_NAME = parser.nextText();
                    } else if ("PER_PAGE".equals(parser.getName())) {
                        this._PER_PAGE = parser.nextText();
                    } else if ("TELE_PHONE".equals(parser.getName())) {
                        this._TELE_PHONE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}