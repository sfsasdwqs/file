package com.common.szair.model.appcomment;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class MobileAppCommentWebServiceServiceSoapBinding extends SOAPBinding {
    public MobileAppCommentWebServiceServiceSoapBinding(String endpoint) {
        super(MobileAppCommentWebServiceServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns0", "http://com/shenzhenair/mobilewebservice/common");
        hashMap.put("ns2", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        hashMap.put("ns1", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns4", "http://impl.webservice.common.shenzhenair.com/");
        hashMap.put("ns3", "http://schemas.xmlsoap.org/soap/http");
        return hashMap;
    }

    public searchFeedbackResponse searchFeedback(searchFeedback parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("searchFeedback", parameters);
        }
        searchFeedbackResponse searchfeedbackresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof searchFeedbackResponse)) {
                    searchfeedbackresponse = (searchFeedbackResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    searchfeedbackresponse = new searchFeedbackResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    searchfeedbackresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (searchfeedbackresponse != null) {
                return searchfeedbackresponse;
            }
            searchFeedbackResponse searchfeedbackresponse2 = new searchFeedbackResponse();
            searchfeedbackresponse2.setexception(new NullPointerException());
            return searchfeedbackresponse2;
        } catch (Exception e) {
            searchFeedbackResponse searchfeedbackresponse3 = new searchFeedbackResponse();
            searchfeedbackresponse3.setexception(e);
            return searchfeedbackresponse3;
        }
    }

    public submitFeedbackResponse submitFeedback(submitFeedback parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("submitFeedback", parameters);
        }
        submitFeedbackResponse submitfeedbackresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof submitFeedbackResponse)) {
                    submitfeedbackresponse = (submitFeedbackResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    submitfeedbackresponse = new submitFeedbackResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    submitfeedbackresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (submitfeedbackresponse != null) {
                return submitfeedbackresponse;
            }
            submitFeedbackResponse submitfeedbackresponse2 = new submitFeedbackResponse();
            submitfeedbackresponse2.setexception(new NullPointerException());
            return submitfeedbackresponse2;
        } catch (Exception e) {
            submitFeedbackResponse submitfeedbackresponse3 = new submitFeedbackResponse();
            submitfeedbackresponse3.setexception(e);
            return submitfeedbackresponse3;
        }
    }

    public saveMobileAppCommentResponse saveMobileAppComment(saveMobileAppComment parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("saveMobileAppComment", parameters);
        }
        saveMobileAppCommentResponse savemobileappcommentresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof saveMobileAppCommentResponse)) {
                    savemobileappcommentresponse = (saveMobileAppCommentResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    savemobileappcommentresponse = new saveMobileAppCommentResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    savemobileappcommentresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (savemobileappcommentresponse != null) {
                return savemobileappcommentresponse;
            }
            saveMobileAppCommentResponse savemobileappcommentresponse2 = new saveMobileAppCommentResponse();
            savemobileappcommentresponse2.setexception(new NullPointerException());
            return savemobileappcommentresponse2;
        } catch (Exception e) {
            saveMobileAppCommentResponse savemobileappcommentresponse3 = new saveMobileAppCommentResponse();
            savemobileappcommentresponse3.setexception(e);
            return savemobileappcommentresponse3;
        }
    }
}