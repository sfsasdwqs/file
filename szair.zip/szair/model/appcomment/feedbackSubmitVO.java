package com.common.szair.model.appcomment;

import com.air.sz.ui.consts.UIConst;
import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class feedbackSubmitVO implements SOAPObject {
    public String _CERT_NO = null;
    public String _CERT_TYPE = null;
    public String _DST_CITY = null;
    public String _EMAIL = null;
    public String _FEEDBACK_CONTENT = null;
    public String _FEEDBACK_TYPE = null;
    public String _FLIGHT_DATE = null;
    public String _FLIGHT_NO = null;
    public String _MEMBER_MES = null;
    public String _ORG_CITY = null;
    public String _PASSENGER_NAME = null;
    public List<feedbackPictureVO> _PICTURE_LIST = null;
    public String _REPLY_MODEL = null;
    public String _TELE_PHONE = null;
    public String _TICKET_NO = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/common";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CERT_NO != null) {
            xml.startTag(null, "CERT_NO");
            xml.text(this._CERT_NO);
            xml.endTag(null, "CERT_NO");
        }
        if (this._CERT_TYPE != null) {
            xml.startTag(null, "CERT_TYPE");
            xml.text(this._CERT_TYPE);
            xml.endTag(null, "CERT_TYPE");
        }
        if (this._DST_CITY != null) {
            xml.startTag(null, "DST_CITY");
            xml.text(this._DST_CITY);
            xml.endTag(null, "DST_CITY");
        }
        if (this._EMAIL != null) {
            xml.startTag(null, UIConst.REGTST_WAY_E);
            xml.text(this._EMAIL);
            xml.endTag(null, UIConst.REGTST_WAY_E);
        }
        if (this._FEEDBACK_CONTENT != null) {
            xml.startTag(null, "FEEDBACK_CONTENT");
            xml.text(this._FEEDBACK_CONTENT);
            xml.endTag(null, "FEEDBACK_CONTENT");
        }
        if (this._FEEDBACK_TYPE != null) {
            xml.startTag(null, "FEEDBACK_TYPE");
            xml.text(this._FEEDBACK_TYPE);
            xml.endTag(null, "FEEDBACK_TYPE");
        }
        if (this._FLIGHT_DATE != null) {
            xml.startTag(null, "FLIGHT_DATE");
            xml.text(this._FLIGHT_DATE);
            xml.endTag(null, "FLIGHT_DATE");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._MEMBER_MES != null) {
            xml.startTag(null, "MEMBER_MES");
            xml.text(this._MEMBER_MES);
            xml.endTag(null, "MEMBER_MES");
        }
        if (this._ORG_CITY != null) {
            xml.startTag(null, "ORG_CITY");
            xml.text(this._ORG_CITY);
            xml.endTag(null, "ORG_CITY");
        }
        if (this._PASSENGER_NAME != null) {
            xml.startTag(null, "PASSENGER_NAME");
            xml.text(this._PASSENGER_NAME);
            xml.endTag(null, "PASSENGER_NAME");
        }
        List<feedbackPictureVO> list = this._PICTURE_LIST;
        if (list != null && list.size() > 0) {
            int size = this._PICTURE_LIST.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "PICTURE_LIST");
                this._PICTURE_LIST.get(i).addElementsToNode(xml);
                xml.endTag(null, "PICTURE_LIST");
            }
        }
        if (this._REPLY_MODEL != null) {
            xml.startTag(null, "REPLY_MODEL");
            xml.text(this._REPLY_MODEL);
            xml.endTag(null, "REPLY_MODEL");
        }
        if (this._TELE_PHONE != null) {
            xml.startTag(null, "TELE_PHONE");
            xml.text(this._TELE_PHONE);
            xml.endTag(null, "TELE_PHONE");
        }
        if (this._TICKET_NO != null) {
            xml.startTag(null, "TICKET_NO");
            xml.text(this._TICKET_NO);
            xml.endTag(null, "TICKET_NO");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CERT_NO".equals(parser.getName())) {
                        this._CERT_NO = parser.nextText();
                    } else if ("CERT_TYPE".equals(parser.getName())) {
                        this._CERT_TYPE = parser.nextText();
                    } else if ("DST_CITY".equals(parser.getName())) {
                        this._DST_CITY = parser.nextText();
                    } else if (UIConst.REGTST_WAY_E.equals(parser.getName())) {
                        this._EMAIL = parser.nextText();
                    } else if ("FEEDBACK_CONTENT".equals(parser.getName())) {
                        this._FEEDBACK_CONTENT = parser.nextText();
                    } else if ("FEEDBACK_TYPE".equals(parser.getName())) {
                        this._FEEDBACK_TYPE = parser.nextText();
                    } else if ("FLIGHT_DATE".equals(parser.getName())) {
                        this._FLIGHT_DATE = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("MEMBER_MES".equals(parser.getName())) {
                        this._MEMBER_MES = parser.nextText();
                    } else if ("ORG_CITY".equals(parser.getName())) {
                        this._ORG_CITY = parser.nextText();
                    } else if ("PASSENGER_NAME".equals(parser.getName())) {
                        this._PASSENGER_NAME = parser.nextText();
                    } else if ("PICTURE_LIST".equals(parser.getName())) {
                        if (this._PICTURE_LIST == null) {
                            this._PICTURE_LIST = new ArrayList();
                        }
                        feedbackPictureVO feedbackpicturevo = new feedbackPictureVO();
                        feedbackpicturevo.parse(binding, parser);
                        this._PICTURE_LIST.add(feedbackpicturevo);
                    } else if ("REPLY_MODEL".equals(parser.getName())) {
                        this._REPLY_MODEL = parser.nextText();
                    } else if ("TELE_PHONE".equals(parser.getName())) {
                        this._TELE_PHONE = parser.nextText();
                    } else if ("TICKET_NO".equals(parser.getName())) {
                        this._TICKET_NO = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}