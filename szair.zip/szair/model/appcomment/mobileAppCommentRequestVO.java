package com.common.szair.model.appcomment;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class mobileAppCommentRequestVO implements SOAPObject {
    public String _CONTACT_CALLPHONE = null;
    public String _CONTACT_EMAIL = null;
    public String _CONTACT_MOBILEPHONE = null;
    public String _CONTACT_NAME = null;
    public String _CONTACT_QQID = null;
    public String _CONTENT = null;
    public String _LEVEL = null;
    public String _PLAT_ID = null;
    public String _USER_ID = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/common";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CONTACT_CALLPHONE != null) {
            xml.startTag(null, "CONTACT_CALLPHONE");
            xml.text(this._CONTACT_CALLPHONE);
            xml.endTag(null, "CONTACT_CALLPHONE");
        }
        if (this._CONTACT_EMAIL != null) {
            xml.startTag(null, "CONTACT_EMAIL");
            xml.text(this._CONTACT_EMAIL);
            xml.endTag(null, "CONTACT_EMAIL");
        }
        if (this._CONTACT_MOBILEPHONE != null) {
            xml.startTag(null, "CONTACT_MOBILEPHONE");
            xml.text(this._CONTACT_MOBILEPHONE);
            xml.endTag(null, "CONTACT_MOBILEPHONE");
        }
        if (this._CONTACT_NAME != null) {
            xml.startTag(null, "CONTACT_NAME");
            xml.text(this._CONTACT_NAME);
            xml.endTag(null, "CONTACT_NAME");
        }
        if (this._CONTACT_QQID != null) {
            xml.startTag(null, "CONTACT_QQID");
            xml.text(this._CONTACT_QQID);
            xml.endTag(null, "CONTACT_QQID");
        }
        if (this._CONTENT != null) {
            xml.startTag(null, "CONTENT");
            xml.text(this._CONTENT);
            xml.endTag(null, "CONTENT");
        }
        if (this._LEVEL != null) {
            xml.startTag(null, "LEVEL");
            xml.text(this._LEVEL);
            xml.endTag(null, "LEVEL");
        }
        if (this._PLAT_ID != null) {
            xml.startTag(null, "PLAT_ID");
            xml.text(this._PLAT_ID);
            xml.endTag(null, "PLAT_ID");
        }
        if (this._USER_ID != null) {
            xml.startTag(null, "USER_ID");
            xml.text(this._USER_ID);
            xml.endTag(null, "USER_ID");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CONTACT_CALLPHONE".equals(parser.getName())) {
                        this._CONTACT_CALLPHONE = parser.nextText();
                    } else if ("CONTACT_EMAIL".equals(parser.getName())) {
                        this._CONTACT_EMAIL = parser.nextText();
                    } else if ("CONTACT_MOBILEPHONE".equals(parser.getName())) {
                        this._CONTACT_MOBILEPHONE = parser.nextText();
                    } else if ("CONTACT_NAME".equals(parser.getName())) {
                        this._CONTACT_NAME = parser.nextText();
                    } else if ("CONTACT_QQID".equals(parser.getName())) {
                        this._CONTACT_QQID = parser.nextText();
                    } else if ("CONTENT".equals(parser.getName())) {
                        this._CONTENT = parser.nextText();
                    } else if ("LEVEL".equals(parser.getName())) {
                        this._LEVEL = parser.nextText();
                    } else if ("PLAT_ID".equals(parser.getName())) {
                        this._PLAT_ID = parser.nextText();
                    } else if ("USER_ID".equals(parser.getName())) {
                        this._USER_ID = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}