package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class returnCheckInVO extends bookingResponseBaseVO implements SOAPObject, Serializable {
    public String passCertNo;
    public String _BOARDING_GATENUMBER = null;
    public String _ET_CODE = null;
    public String _FLIGHT_NO = null;
    public String _FLIGHT_TIME = null;
    public String _ORG_CITY = null;
    public String _KDDC_MSG = null;
    public String _QR_BAR_CODE_PROMPT = null;
    public String _QR_CODE = null;
    public String _RETURN_CODE = null;
    public String _RETURN_MSG = null;
    public String _SEAT_NO = null;
    public String _SEND_STATE = null;
    public String _DST_CITY = null;
    public String _EXPECTED_ARR_TIME = null;
    public String _OP_RESULT = null;
    public String _PASSNAME = null;
    public String _STAR_LEVEL = null;
    public String _CARD_LEVEL = null;
    public String _GATE_NUMBER = null;
    public String _BAGGAGE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._BOARDING_GATENUMBER != null) {
            xml.startTag(null, "BOARDING_GATENUMBER");
            xml.text(this._BOARDING_GATENUMBER);
            xml.endTag(null, "BOARDING_GATENUMBER");
        }
        if (this._ET_CODE != null) {
            xml.startTag(null, "ET_CODE");
            xml.text(this._ET_CODE);
            xml.endTag(null, "ET_CODE");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._FLIGHT_TIME != null) {
            xml.startTag(null, "FLIGHT_TIME");
            xml.text(this._FLIGHT_TIME);
            xml.endTag(null, "FLIGHT_TIME");
        }
        if (this._ORG_CITY != null) {
            xml.startTag(null, "ORG_CITY");
            xml.text(this._ORG_CITY);
            xml.endTag(null, "ORG_CITY");
        }
        if (this._KDDC_MSG != null) {
            xml.startTag(null, "KDDC_MSG");
            xml.text(this._KDDC_MSG);
            xml.endTag(null, "KDDC_MSG");
        }
        if (this._QR_BAR_CODE_PROMPT != null) {
            xml.startTag(null, "QR_BAR_CODE_PROMPT");
            xml.text(this._QR_BAR_CODE_PROMPT);
            xml.endTag(null, "QR_BAR_CODE_PROMPT");
        }
        if (this._QR_CODE != null) {
            xml.startTag(null, "QR_CODE");
            xml.text(this._QR_CODE);
            xml.endTag(null, "QR_CODE");
        }
        if (this._RETURN_CODE != null) {
            xml.startTag(null, "RETURN_CODE");
            xml.text(this._RETURN_CODE);
            xml.endTag(null, "RETURN_CODE");
        }
        if (this._RETURN_MSG != null) {
            xml.startTag(null, "RETURN_MSG");
            xml.text(this._RETURN_MSG);
            xml.endTag(null, "RETURN_MSG");
        }
        if (this._SEAT_NO != null) {
            xml.startTag(null, "SEAT_NO");
            xml.text(this._SEAT_NO);
            xml.endTag(null, "SEAT_NO");
        }
        if (this._SEND_STATE != null) {
            xml.startTag(null, "SEND_STATE");
            xml.text(this._SEND_STATE);
            xml.endTag(null, "SEND_STATE");
        }
        if (this._DST_CITY != null) {
            xml.startTag(null, "DST_CITY");
            xml.text(this._DST_CITY);
            xml.endTag(null, "DST_CITY");
        }
        if (this._EXPECTED_ARR_TIME != null) {
            xml.startTag(null, "EXPECTED_ARR_TIME");
            xml.text(this._EXPECTED_ARR_TIME);
            xml.endTag(null, "EXPECTED_ARR_TIME");
        }
        if (this._OP_RESULT != null) {
            xml.startTag(null, "OP_RESULT");
            xml.text(this._OP_RESULT);
            xml.endTag(null, "OP_RESULT");
        }
        if (this._PASSNAME != null) {
            xml.startTag(null, "PASSNAME");
            xml.text(this._PASSNAME);
            xml.endTag(null, "PASSNAME");
        }
        if (this._GATE_NUMBER != null) {
            xml.startTag(null, "GATE_NUMBER");
            xml.text(this._GATE_NUMBER);
            xml.endTag(null, "GATE_NUMBER");
        }
        if (this._BAGGAGE != null) {
            xml.startTag(null, "BAGGAGE");
            xml.text(this._BAGGAGE);
            xml.endTag(null, "BAGGAGE");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("BOARDING_GATENUMBER".equals(parser.getName())) {
                        this._BOARDING_GATENUMBER = parser.nextText();
                    } else if ("ET_CODE".equals(parser.getName())) {
                        this._ET_CODE = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("FLIGHT_TIME".equals(parser.getName())) {
                        this._FLIGHT_TIME = parser.nextText();
                    } else if ("ORG_CITY".equals(parser.getName())) {
                        this._ORG_CITY = parser.nextText();
                    } else if ("KDDC_MSG".equals(parser.getName())) {
                        this._KDDC_MSG = parser.nextText();
                    } else if ("QR_BAR_CODE_PROMPT".equals(parser.getName())) {
                        this._QR_BAR_CODE_PROMPT = parser.nextText();
                    } else if ("QR_CODE".equals(parser.getName())) {
                        this._QR_CODE = parser.nextText();
                    } else if ("RETURN_CODE".equals(parser.getName())) {
                        this._RETURN_CODE = parser.nextText();
                    } else if ("RETURN_MSG".equals(parser.getName())) {
                        this._RETURN_MSG = parser.nextText();
                    } else if ("SEAT_NO".equals(parser.getName())) {
                        this._SEAT_NO = parser.nextText();
                    } else if ("SEND_STATE".equals(parser.getName())) {
                        this._SEND_STATE = parser.nextText();
                    } else if ("DST_CITY".equals(parser.getName())) {
                        this._DST_CITY = parser.nextText();
                    } else if ("EXPECTED_ARR_TIME".equals(parser.getName())) {
                        this._EXPECTED_ARR_TIME = parser.nextText();
                    } else if ("OP_RESULT".equals(parser.getName())) {
                        this._OP_RESULT = parser.nextText();
                    } else if ("PASSNAME".equals(parser.getName())) {
                        this._PASSNAME = parser.nextText();
                    } else if ("STAR_LEVEL".equals(parser.getName())) {
                        this._STAR_LEVEL = parser.nextText();
                    } else if ("CARD_LEVEL".equals(parser.getName())) {
                        this._CARD_LEVEL = parser.nextText();
                    } else if ("GATE_NUMBER".equals(parser.getName())) {
                        this._GATE_NUMBER = parser.nextText();
                    } else if ("BAGGAGE".equals(parser.getName())) {
                        this._BAGGAGE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}