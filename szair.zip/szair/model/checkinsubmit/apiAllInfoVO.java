package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class apiAllInfoVO extends baseDTOVO implements SOAPObject {
    public String _AIRLINE_CODE = null;
    public apiInfoVO _API_INFO_VO = null;
    public String _ARRIVAL_AIRPPORT = null;
    public String _DENIED_BOARDING_VOLUNTEER_IND = null;
    public String _DEPARTURE_AIRPORT = null;
    public String _DEPARTURE_DATE = null;
    public String _FLIGHT_NUMBER = null;
    public String _HOST_NUMBER = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._AIRLINE_CODE != null) {
            xml.startTag(null, "AIRLINE_CODE");
            xml.text(this._AIRLINE_CODE);
            xml.endTag(null, "AIRLINE_CODE");
        }
        if (this._API_INFO_VO != null) {
            xml.startTag(null, "API_INFO_VO");
            this._API_INFO_VO.addElementsToNode(xml);
            xml.endTag(null, "API_INFO_VO");
        }
        if (this._ARRIVAL_AIRPPORT != null) {
            xml.startTag(null, "ARRIVAL_AIRPPORT");
            xml.text(this._ARRIVAL_AIRPPORT);
            xml.endTag(null, "ARRIVAL_AIRPPORT");
        }
        if (this._DENIED_BOARDING_VOLUNTEER_IND != null) {
            xml.startTag(null, "DENIED_BOARDING_VOLUNTEER_IND");
            xml.text(this._DENIED_BOARDING_VOLUNTEER_IND);
            xml.endTag(null, "DENIED_BOARDING_VOLUNTEER_IND");
        }
        if (this._DEPARTURE_AIRPORT != null) {
            xml.startTag(null, "DEPARTURE_AIRPORT");
            xml.text(this._DEPARTURE_AIRPORT);
            xml.endTag(null, "DEPARTURE_AIRPORT");
        }
        if (this._DEPARTURE_DATE != null) {
            xml.startTag(null, "DEPARTURE_DATE");
            xml.text(this._DEPARTURE_DATE);
            xml.endTag(null, "DEPARTURE_DATE");
        }
        if (this._FLIGHT_NUMBER != null) {
            xml.startTag(null, "FLIGHT_NUMBER");
            xml.text(this._FLIGHT_NUMBER);
            xml.endTag(null, "FLIGHT_NUMBER");
        }
        if (this._HOST_NUMBER != null) {
            xml.startTag(null, "HOST_NUMBER");
            xml.text(this._HOST_NUMBER);
            xml.endTag(null, "HOST_NUMBER");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("AIRLINE_CODE".equals(parser.getName())) {
                        this._AIRLINE_CODE = parser.nextText();
                    } else if ("API_INFO_VO".equals(parser.getName())) {
                        apiInfoVO apiinfovo = new apiInfoVO();
                        apiinfovo.parse(binding, parser);
                        this._API_INFO_VO = apiinfovo;
                    } else if ("ARRIVAL_AIRPPORT".equals(parser.getName())) {
                        this._ARRIVAL_AIRPPORT = parser.nextText();
                    } else if ("DENIED_BOARDING_VOLUNTEER_IND".equals(parser.getName())) {
                        this._DENIED_BOARDING_VOLUNTEER_IND = parser.nextText();
                    } else if ("DEPARTURE_AIRPORT".equals(parser.getName())) {
                        this._DEPARTURE_AIRPORT = parser.nextText();
                    } else if ("DEPARTURE_DATE".equals(parser.getName())) {
                        this._DEPARTURE_DATE = parser.nextText();
                    } else if ("FLIGHT_NUMBER".equals(parser.getName())) {
                        this._FLIGHT_NUMBER = parser.nextText();
                    } else if ("HOST_NUMBER".equals(parser.getName())) {
                        this._HOST_NUMBER = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}