package com.common.szair.model.checkinsubmit;

import com.air.sz.ui.consts.UIConst;
import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class apiInfoVO extends baseDTOVO implements SOAPObject {
    public String _BIRTHDATE = null;
    public String _BIRTH_LOCATION = null;
    public destAddressVO _DEST_ADDRESS_VO = null;
    public String _DOC_HOLDER_NATIONALITY = null;
    public String _DOC_ID = null;
    public String _DOC_ISSUE_COUNTRY = null;
    public String _DOC_TYPE = null;
    public String _EFFECTIVE_DATE = null;
    public String _EMAIL = null;
    public String _EXPIRE_DATE = null;
    public String _GENDER = null;
    public String _GIVEN_NAME = null;
    public homeAddressVO _HOME_ADDRESS_VO = null;
    public String _MIDDLE_NAME = null;
    public String _MOBILE_PHONE = null;
    public otherDocInfoVO _OTHER_DOCINFO_VO = null;
    public String _PRIMARY_HOLDER_IND = null;
    public String _RESIDENCE_COUNTRY = null;
    public String _SURNAME = null;
    public String _TRANSFER_IND = null;
    public visaInfoVO _VISAINFO_VO = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._BIRTHDATE != null) {
            xml.startTag(null, "BIRTHDATE");
            xml.text(this._BIRTHDATE);
            xml.endTag(null, "BIRTHDATE");
        }
        if (this._BIRTH_LOCATION != null) {
            xml.startTag(null, "BIRTH_LOCATION");
            xml.text(this._BIRTH_LOCATION);
            xml.endTag(null, "BIRTH_LOCATION");
        }
        if (this._DEST_ADDRESS_VO != null) {
            xml.startTag(null, "DEST_ADDRESS_VO");
            this._DEST_ADDRESS_VO.addElementsToNode(xml);
            xml.endTag(null, "DEST_ADDRESS_VO");
        }
        if (this._DOC_HOLDER_NATIONALITY != null) {
            xml.startTag(null, "DOC_HOLDER_NATIONALITY");
            xml.text(this._DOC_HOLDER_NATIONALITY);
            xml.endTag(null, "DOC_HOLDER_NATIONALITY");
        }
        if (this._DOC_ID != null) {
            xml.startTag(null, "DOC_ID");
            xml.text(this._DOC_ID);
            xml.endTag(null, "DOC_ID");
        }
        if (this._DOC_ISSUE_COUNTRY != null) {
            xml.startTag(null, "DOC_ISSUE_COUNTRY");
            xml.text(this._DOC_ISSUE_COUNTRY);
            xml.endTag(null, "DOC_ISSUE_COUNTRY");
        }
        if (this._DOC_TYPE != null) {
            xml.startTag(null, "DOC_TYPE");
            xml.text(this._DOC_TYPE);
            xml.endTag(null, "DOC_TYPE");
        }
        if (this._EFFECTIVE_DATE != null) {
            xml.startTag(null, "EFFECTIVE_DATE");
            xml.text(this._EFFECTIVE_DATE);
            xml.endTag(null, "EFFECTIVE_DATE");
        }
        if (this._EMAIL != null) {
            xml.startTag(null, UIConst.REGTST_WAY_E);
            xml.text(this._EMAIL);
            xml.endTag(null, UIConst.REGTST_WAY_E);
        }
        if (this._EXPIRE_DATE != null) {
            xml.startTag(null, "EXPIRE_DATE");
            xml.text(this._EXPIRE_DATE);
            xml.endTag(null, "EXPIRE_DATE");
        }
        if (this._GENDER != null) {
            xml.startTag(null, "GENDER");
            xml.text(this._GENDER);
            xml.endTag(null, "GENDER");
        }
        if (this._GIVEN_NAME != null) {
            xml.startTag(null, "GIVEN_NAME");
            xml.text(this._GIVEN_NAME);
            xml.endTag(null, "GIVEN_NAME");
        }
        if (this._HOME_ADDRESS_VO != null) {
            xml.startTag(null, "HOME_ADDRESS_VO");
            this._HOME_ADDRESS_VO.addElementsToNode(xml);
            xml.endTag(null, "HOME_ADDRESS_VO");
        }
        if (this._MIDDLE_NAME != null) {
            xml.startTag(null, "MIDDLE_NAME");
            xml.text(this._MIDDLE_NAME);
            xml.endTag(null, "MIDDLE_NAME");
        }
        if (this._MOBILE_PHONE != null) {
            xml.startTag(null, "MOBILE_PHONE");
            xml.text(this._MOBILE_PHONE);
            xml.endTag(null, "MOBILE_PHONE");
        }
        if (this._OTHER_DOCINFO_VO != null) {
            xml.startTag(null, "OTHER_DOCINFO_VO");
            this._OTHER_DOCINFO_VO.addElementsToNode(xml);
            xml.endTag(null, "OTHER_DOCINFO_VO");
        }
        if (this._PRIMARY_HOLDER_IND != null) {
            xml.startTag(null, "PRIMARY_HOLDER_IND");
            xml.text(this._PRIMARY_HOLDER_IND);
            xml.endTag(null, "PRIMARY_HOLDER_IND");
        }
        if (this._RESIDENCE_COUNTRY != null) {
            xml.startTag(null, "RESIDENCE_COUNTRY");
            xml.text(this._RESIDENCE_COUNTRY);
            xml.endTag(null, "RESIDENCE_COUNTRY");
        }
        if (this._SURNAME != null) {
            xml.startTag(null, "SURNAME");
            xml.text(this._SURNAME);
            xml.endTag(null, "SURNAME");
        }
        if (this._TRANSFER_IND != null) {
            xml.startTag(null, "TRANSFER_IND");
            xml.text(this._TRANSFER_IND);
            xml.endTag(null, "TRANSFER_IND");
        }
        if (this._VISAINFO_VO != null) {
            xml.startTag(null, "VISAINFO_VO");
            this._VISAINFO_VO.addElementsToNode(xml);
            xml.endTag(null, "VISAINFO_VO");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("BIRTHDATE".equals(parser.getName())) {
                        this._BIRTHDATE = parser.nextText();
                    } else if ("BIRTH_LOCATION".equals(parser.getName())) {
                        this._BIRTH_LOCATION = parser.nextText();
                    } else if ("DEST_ADDRESS_VO".equals(parser.getName())) {
                        destAddressVO destaddressvo = new destAddressVO();
                        destaddressvo.parse(binding, parser);
                        this._DEST_ADDRESS_VO = destaddressvo;
                    } else if ("DOC_HOLDER_NATIONALITY".equals(parser.getName())) {
                        this._DOC_HOLDER_NATIONALITY = parser.nextText();
                    } else if ("DOC_ID".equals(parser.getName())) {
                        this._DOC_ID = parser.nextText();
                    } else if ("DOC_ISSUE_COUNTRY".equals(parser.getName())) {
                        this._DOC_ISSUE_COUNTRY = parser.nextText();
                    } else if ("DOC_TYPE".equals(parser.getName())) {
                        this._DOC_TYPE = parser.nextText();
                    } else if ("EFFECTIVE_DATE".equals(parser.getName())) {
                        this._EFFECTIVE_DATE = parser.nextText();
                    } else if (UIConst.REGTST_WAY_E.equals(parser.getName())) {
                        this._EMAIL = parser.nextText();
                    } else if ("EXPIRE_DATE".equals(parser.getName())) {
                        this._EXPIRE_DATE = parser.nextText();
                    } else if ("GENDER".equals(parser.getName())) {
                        this._GENDER = parser.nextText();
                    } else if ("GIVEN_NAME".equals(parser.getName())) {
                        this._GIVEN_NAME = parser.nextText();
                    } else if ("HOME_ADDRESS_VO".equals(parser.getName())) {
                        homeAddressVO homeaddressvo = new homeAddressVO();
                        homeaddressvo.parse(binding, parser);
                        this._HOME_ADDRESS_VO = homeaddressvo;
                    } else if ("MIDDLE_NAME".equals(parser.getName())) {
                        this._MIDDLE_NAME = parser.nextText();
                    } else if ("MOBILE_PHONE".equals(parser.getName())) {
                        this._MOBILE_PHONE = parser.nextText();
                    } else if ("OTHER_DOCINFO_VO".equals(parser.getName())) {
                        otherDocInfoVO otherdocinfovo = new otherDocInfoVO();
                        otherdocinfovo.parse(binding, parser);
                        this._OTHER_DOCINFO_VO = otherdocinfovo;
                    } else if ("PRIMARY_HOLDER_IND".equals(parser.getName())) {
                        this._PRIMARY_HOLDER_IND = parser.nextText();
                    } else if ("RESIDENCE_COUNTRY".equals(parser.getName())) {
                        this._RESIDENCE_COUNTRY = parser.nextText();
                    } else if ("SURNAME".equals(parser.getName())) {
                        this._SURNAME = parser.nextText();
                    } else if ("TRANSFER_IND".equals(parser.getName())) {
                        this._TRANSFER_IND = parser.nextText();
                    } else if ("VISAINFO_VO".equals(parser.getName())) {
                        visaInfoVO visainfovo = new visaInfoVO();
                        visainfovo.parse(binding, parser);
                        this._VISAINFO_VO = visainfovo;
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}