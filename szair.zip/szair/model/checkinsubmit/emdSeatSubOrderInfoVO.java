package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class emdSeatSubOrderInfoVO extends baseDTOVO implements SOAPObject {
    public String _COUPON_ID = null;
    public String _DEST = null;
    public String _FLIGHT_DATE = null;
    public String _FLIGHT_NO = null;
    public String _MILEAGE = null;
    public String _ORIG = null;
    public String _TICKET_NO = null;
    public String _SEAT_TYPE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._COUPON_ID != null) {
            xml.startTag(null, "COUPON_ID");
            xml.text(this._COUPON_ID);
            xml.endTag(null, "COUPON_ID");
        }
        if (this._DEST != null) {
            xml.startTag(null, "DEST");
            xml.text(this._DEST);
            xml.endTag(null, "DEST");
        }
        if (this._FLIGHT_DATE != null) {
            xml.startTag(null, "FLIGHT_DATE");
            xml.text(this._FLIGHT_DATE);
            xml.endTag(null, "FLIGHT_DATE");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._MILEAGE != null) {
            xml.startTag(null, "MILEAGE");
            xml.text(this._MILEAGE);
            xml.endTag(null, "MILEAGE");
        }
        if (this._ORIG != null) {
            xml.startTag(null, "ORIG");
            xml.text(this._ORIG);
            xml.endTag(null, "ORIG");
        }
        if (this._TICKET_NO != null) {
            xml.startTag(null, "TICKET_NO");
            xml.text(this._TICKET_NO);
            xml.endTag(null, "TICKET_NO");
        }
        if (this._SEAT_TYPE != null) {
            xml.startTag(null, "SEAT_TYPE");
            xml.text(this._SEAT_TYPE);
            xml.endTag(null, "SEAT_TYPE");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("COUPON_ID".equals(parser.getName())) {
                        this._COUPON_ID = parser.nextText();
                    } else if ("DEST".equals(parser.getName())) {
                        this._DEST = parser.nextText();
                    } else if ("FLIGHT_DATE".equals(parser.getName())) {
                        this._FLIGHT_DATE = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("MILEAGE".equals(parser.getName())) {
                        this._MILEAGE = parser.nextText();
                    } else if ("ORIG".equals(parser.getName())) {
                        this._ORIG = parser.nextText();
                    } else if ("TICKET_NO".equals(parser.getName())) {
                        this._TICKET_NO = parser.nextText();
                    } else if ("SEAT_TYPE".equals(parser.getName())) {
                        this._SEAT_TYPE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}