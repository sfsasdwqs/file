package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class CheckInSubmitWebServiceServiceSoapBinding extends SOAPBinding {
    public CheckInSubmitWebServiceServiceSoapBinding(String endpoint) {
        super(CheckInSubmitWebServiceServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns3", "http://impl.webservice.checkin.shenzhenair.com/");
        hashMap.put("ns4", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns2", "http://com/shenzhenair/mobilewebservice/checkin");
        hashMap.put("ns1", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns0", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        return hashMap;
    }

    public CheckInSubmitResponse CheckInSubmit(CheckInSubmit parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("CheckInSubmit", parameters);
        }
        CheckInSubmitResponse checkInSubmitResponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof CheckInSubmitResponse)) {
                    checkInSubmitResponse = (CheckInSubmitResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    checkInSubmitResponse = new CheckInSubmitResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    checkInSubmitResponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (checkInSubmitResponse != null) {
                return checkInSubmitResponse;
            }
            CheckInSubmitResponse checkInSubmitResponse2 = new CheckInSubmitResponse();
            checkInSubmitResponse2.setexception(new NullPointerException());
            return checkInSubmitResponse2;
        } catch (Exception e) {
            CheckInSubmitResponse checkInSubmitResponse3 = new CheckInSubmitResponse();
            checkInSubmitResponse3.setexception(e);
            return checkInSubmitResponse3;
        }
    }

    public queryEmdOrderInfoResponse queryEmdOrderInfo(queryEmdOrderInfo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryEmdOrderInfo", parameters);
        }
        queryEmdOrderInfoResponse queryemdorderinforesponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryEmdOrderInfoResponse)) {
                    queryemdorderinforesponse = (queryEmdOrderInfoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    queryemdorderinforesponse = new queryEmdOrderInfoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    queryemdorderinforesponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (queryemdorderinforesponse != null) {
                return queryemdorderinforesponse;
            }
            queryEmdOrderInfoResponse queryemdorderinforesponse2 = new queryEmdOrderInfoResponse();
            queryemdorderinforesponse2.setexception(new NullPointerException());
            return queryemdorderinforesponse2;
        } catch (Exception e) {
            queryEmdOrderInfoResponse queryemdorderinforesponse3 = new queryEmdOrderInfoResponse();
            queryemdorderinforesponse3.setexception(e);
            return queryemdorderinforesponse3;
        }
    }

    public moreEmdCheckInResponse moreEmdCheckIn(moreEmdCheckIn parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("moreEmdCheckIn", parameters);
        }
        moreEmdCheckInResponse moreemdcheckinresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof moreEmdCheckInResponse)) {
                    moreemdcheckinresponse = (moreEmdCheckInResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    moreemdcheckinresponse = new moreEmdCheckInResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    moreemdcheckinresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (moreemdcheckinresponse != null) {
                return moreemdcheckinresponse;
            }
            moreEmdCheckInResponse moreemdcheckinresponse2 = new moreEmdCheckInResponse();
            moreemdcheckinresponse2.setexception(new NullPointerException());
            return moreemdcheckinresponse2;
        } catch (Exception e) {
            moreEmdCheckInResponse moreemdcheckinresponse3 = new moreEmdCheckInResponse();
            moreemdcheckinresponse3.setexception(e);
            return moreemdcheckinresponse3;
        }
    }

    public moreEmdSeatIssueResponse moreEmdSeatIssue(moreEmdSeatIssue parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("moreEmdSeatIssue", parameters);
        }
        moreEmdSeatIssueResponse moreemdseatissueresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof moreEmdSeatIssueResponse)) {
                    moreemdseatissueresponse = (moreEmdSeatIssueResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    moreemdseatissueresponse = new moreEmdSeatIssueResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    moreemdseatissueresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (moreemdseatissueresponse != null) {
                return moreemdseatissueresponse;
            }
            moreEmdSeatIssueResponse moreemdseatissueresponse2 = new moreEmdSeatIssueResponse();
            moreemdseatissueresponse2.setexception(new NullPointerException());
            return moreemdseatissueresponse2;
        } catch (Exception e) {
            moreEmdSeatIssueResponse moreemdseatissueresponse3 = new moreEmdSeatIssueResponse();
            moreemdseatissueresponse3.setexception(e);
            return moreemdseatissueresponse3;
        }
    }

    public CheckInTCSubmitResponse CheckInTCSubmit(CheckInTCSubmit parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("CheckInTCSubmit", parameters);
        }
        CheckInTCSubmitResponse checkInTCSubmitResponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof CheckInTCSubmitResponse)) {
                    checkInTCSubmitResponse = (CheckInTCSubmitResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    checkInTCSubmitResponse = new CheckInTCSubmitResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    checkInTCSubmitResponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (checkInTCSubmitResponse != null) {
                return checkInTCSubmitResponse;
            }
            CheckInTCSubmitResponse checkInTCSubmitResponse2 = new CheckInTCSubmitResponse();
            checkInTCSubmitResponse2.setexception(new NullPointerException());
            return checkInTCSubmitResponse2;
        } catch (Exception e) {
            CheckInTCSubmitResponse checkInTCSubmitResponse3 = new CheckInTCSubmitResponse();
            checkInTCSubmitResponse3.setexception(e);
            return checkInTCSubmitResponse3;
        }
    }

    public moreCheckInResponse moreCheckIn(moreCheckIn parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("moreCheckIn", parameters);
        }
        moreCheckInResponse morecheckinresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof moreCheckInResponse)) {
                    morecheckinresponse = (moreCheckInResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    morecheckinresponse = new moreCheckInResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    morecheckinresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (morecheckinresponse != null) {
                return morecheckinresponse;
            }
            moreCheckInResponse morecheckinresponse2 = new moreCheckInResponse();
            morecheckinresponse2.setexception(new NullPointerException());
            return morecheckinresponse2;
        } catch (Exception e) {
            moreCheckInResponse morecheckinresponse3 = new moreCheckInResponse();
            morecheckinresponse3.setexception(e);
            return morecheckinresponse3;
        }
    }
}