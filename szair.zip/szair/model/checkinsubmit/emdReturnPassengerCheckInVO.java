package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class emdReturnPassengerCheckInVO extends bookingResponseBaseVO implements SOAPObject, Serializable {
    public String _APP_SEAT_TYPE = null;
    public String _BAGGAGE = null;
    public String _CARD_LEVEL = null;
    public String _CARD_NO = null;
    public String _CERT_NO = null;
    public String _CERT_TYPE = null;
    public String _CLASS_CODE = null;
    public String _CLASS_TYPE = null;
    public String _COUPON_COUNT = null;
    public String _ET_CODE = null;
    public String _MILEAGE = null;
    public String _PASSNAME = null;
    public String _PNR = null;
    public String _QR_BAR_CODE_PROMPT = null;
    public String _QR_BAR_CODE_STR = null;
    public String _QR_CODE = null;
    public String _RETURN_CODE = null;
    public String _RETURN_MSG = null;
    public String _SEAT_NO = null;
    public String _EMD_SEAT_TYPE = null;
    public String _SEND_STATE = null;
    public String _STAR_LEVEL = null;
    public String _IS_CHILD = null;
    public String _OP_RESULT = null;
    public String _SEAT_PRICE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._APP_SEAT_TYPE != null) {
            xml.startTag(null, "APP_SEAT_TYPE");
            xml.text(this._APP_SEAT_TYPE);
            xml.endTag(null, "APP_SEAT_TYPE");
        }
        if (this._BAGGAGE != null) {
            xml.startTag(null, "BAGGAGE");
            xml.text(this._BAGGAGE);
            xml.endTag(null, "BAGGAGE");
        }
        if (this._CARD_LEVEL != null) {
            xml.startTag(null, "CARD_LEVEL");
            xml.text(this._CARD_LEVEL);
            xml.endTag(null, "CARD_LEVEL");
        }
        if (this._CARD_NO != null) {
            xml.startTag(null, "CARD_NO");
            xml.text(this._CARD_NO);
            xml.endTag(null, "CARD_NO");
        }
        if (this._CERT_NO != null) {
            xml.startTag(null, "CERT_NO");
            xml.text(this._CERT_NO);
            xml.endTag(null, "CERT_NO");
        }
        if (this._CERT_TYPE != null) {
            xml.startTag(null, "CERT_TYPE");
            xml.text(this._CERT_TYPE);
            xml.endTag(null, "CERT_TYPE");
        }
        if (this._CLASS_CODE != null) {
            xml.startTag(null, "CLASS_CODE");
            xml.text(this._CLASS_CODE);
            xml.endTag(null, "CLASS_CODE");
        }
        if (this._CLASS_TYPE != null) {
            xml.startTag(null, "CLASS_TYPE");
            xml.text(this._CLASS_TYPE);
            xml.endTag(null, "CLASS_TYPE");
        }
        if (this._COUPON_COUNT != null) {
            xml.startTag(null, "COUPON_COUNT");
            xml.text(this._COUPON_COUNT);
            xml.endTag(null, "COUPON_COUNT");
        }
        if (this._ET_CODE != null) {
            xml.startTag(null, "ET_CODE");
            xml.text(this._ET_CODE);
            xml.endTag(null, "ET_CODE");
        }
        if (this._MILEAGE != null) {
            xml.startTag(null, "MILEAGE");
            xml.text(this._MILEAGE);
            xml.endTag(null, "MILEAGE");
        }
        if (this._PASSNAME != null) {
            xml.startTag(null, "PASSNAME");
            xml.text(this._PASSNAME);
            xml.endTag(null, "PASSNAME");
        }
        if (this._PNR != null) {
            xml.startTag(null, "PNR");
            xml.text(this._PNR);
            xml.endTag(null, "PNR");
        }
        if (this._QR_BAR_CODE_PROMPT != null) {
            xml.startTag(null, "QR_BAR_CODE_PROMPT");
            xml.text(this._QR_BAR_CODE_PROMPT);
            xml.endTag(null, "QR_BAR_CODE_PROMPT");
        }
        if (this._QR_BAR_CODE_STR != null) {
            xml.startTag(null, "QR_BAR_CODE_STR");
            xml.text(this._QR_BAR_CODE_STR);
            xml.endTag(null, "QR_BAR_CODE_STR");
        }
        if (this._QR_CODE != null) {
            xml.startTag(null, "QR_CODE");
            xml.text(this._QR_CODE);
            xml.endTag(null, "QR_CODE");
        }
        if (this._RETURN_CODE != null) {
            xml.startTag(null, "RETURN_CODE");
            xml.text(this._RETURN_CODE);
            xml.endTag(null, "RETURN_CODE");
        }
        if (this._RETURN_MSG != null) {
            xml.startTag(null, "RETURN_MSG");
            xml.text(this._RETURN_MSG);
            xml.endTag(null, "RETURN_MSG");
        }
        if (this._SEAT_NO != null) {
            xml.startTag(null, "SEAT_NO");
            xml.text(this._SEAT_NO);
            xml.endTag(null, "SEAT_NO");
        }
        if (this._EMD_SEAT_TYPE != null) {
            xml.startTag(null, "EMD_SEAT_TYPE");
            xml.text(this._EMD_SEAT_TYPE);
            xml.endTag(null, "EMD_SEAT_TYPE");
        }
        if (this._SEND_STATE != null) {
            xml.startTag(null, "SEND_STATE");
            xml.text(this._SEND_STATE);
            xml.endTag(null, "SEND_STATE");
        }
        if (this._STAR_LEVEL != null) {
            xml.startTag(null, "STAR_LEVEL");
            xml.text(this._STAR_LEVEL);
            xml.endTag(null, "STAR_LEVEL");
        }
        if (this._IS_CHILD != null) {
            xml.startTag(null, "IS_CHILD");
            xml.text(this._IS_CHILD);
            xml.endTag(null, "IS_CHILD");
        }
        if (this._OP_RESULT != null) {
            xml.startTag(null, "OP_RESULT");
            xml.text(this._OP_RESULT);
            xml.endTag(null, "OP_RESULT");
        }
        if (this._SEAT_PRICE != null) {
            xml.startTag(null, "SEAT_PRICE");
            xml.text(this._SEAT_PRICE);
            xml.endTag(null, "SEAT_PRICE");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("APP_SEAT_TYPE".equals(parser.getName())) {
                        this._APP_SEAT_TYPE = parser.nextText();
                    } else if ("BAGGAGE".equals(parser.getName())) {
                        this._BAGGAGE = parser.nextText();
                    } else if ("CARD_LEVEL".equals(parser.getName())) {
                        this._CARD_LEVEL = parser.nextText();
                    } else if ("CARD_NO".equals(parser.getName())) {
                        this._CARD_NO = parser.nextText();
                    } else if ("CERT_NO".equals(parser.getName())) {
                        this._CERT_NO = parser.nextText();
                    } else if ("CERT_TYPE".equals(parser.getName())) {
                        this._CERT_TYPE = parser.nextText();
                    } else if ("CLASS_CODE".equals(parser.getName())) {
                        this._CLASS_CODE = parser.nextText();
                    } else if ("CLASS_TYPE".equals(parser.getName())) {
                        this._CLASS_TYPE = parser.nextText();
                    } else if ("COUPON_COUNT".equals(parser.getName())) {
                        this._COUPON_COUNT = parser.nextText();
                    } else if ("ET_CODE".equals(parser.getName())) {
                        this._ET_CODE = parser.nextText();
                    } else if ("MILEAGE".equals(parser.getName())) {
                        this._MILEAGE = parser.nextText();
                    } else if ("PASSNAME".equals(parser.getName())) {
                        this._PASSNAME = parser.nextText();
                    } else if ("PNR".equals(parser.getName())) {
                        this._PNR = parser.nextText();
                    } else if ("QR_BAR_CODE_PROMPT".equals(parser.getName())) {
                        this._QR_BAR_CODE_PROMPT = parser.nextText();
                    } else if ("QR_BAR_CODE_STR".equals(parser.getName())) {
                        this._QR_BAR_CODE_STR = parser.nextText();
                    } else if ("QR_CODE".equals(parser.getName())) {
                        this._QR_CODE = parser.nextText();
                    } else if ("RETURN_CODE".equals(parser.getName())) {
                        this._RETURN_CODE = parser.nextText();
                    } else if ("RETURN_MSG".equals(parser.getName())) {
                        this._RETURN_MSG = parser.nextText();
                    } else if ("SEAT_NO".equals(parser.getName())) {
                        this._SEAT_NO = parser.nextText();
                    } else if ("EMD_SEAT_TYPE".equals(parser.getName())) {
                        this._EMD_SEAT_TYPE = parser.nextText();
                    } else if ("SEND_STATE".equals(parser.getName())) {
                        this._SEND_STATE = parser.nextText();
                    } else if ("STAR_LEVEL".equals(parser.getName())) {
                        this._STAR_LEVEL = parser.nextText();
                    } else if ("IS_CHILD".equals(parser.getName())) {
                        this._IS_CHILD = parser.nextText();
                    } else if ("OP_RESULT".equals(parser.getName())) {
                        this._OP_RESULT = parser.nextText();
                    } else if ("SEAT_PRICE".equals(parser.getName())) {
                        this._SEAT_PRICE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}