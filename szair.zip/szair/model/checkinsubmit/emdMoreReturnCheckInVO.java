package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class emdMoreReturnCheckInVO extends baseDTOVO implements SOAPObject, Serializable {
    public String _RETURN_IS_EXIST_COUPON = null;
    public String _RETURN_IS_EXIST_MILEAGE = null;
    public String _IS_NEED_PAY = null;
    public String _IS_TIME_OUT = null;
    public List<emdReturnSegmentCheckInVO> _RETURN_CHECKIN_RRESULT_LIST = null;
    public String _ORDER_NO = null;
    public String _ORDER_TIME = null;
    public String _RESULT_MSG = null;
    public String _RESULT_STATUS = null;
    public String _ORDER_PRICE = null;
    public String _SP_FLAG = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._RETURN_IS_EXIST_COUPON != null) {
            xml.startTag(null, "RETURN_IS_EXIST_COUPON");
            xml.text(this._RETURN_IS_EXIST_COUPON);
            xml.endTag(null, "RETURN_IS_EXIST_COUPON");
        }
        if (this._RETURN_IS_EXIST_MILEAGE != null) {
            xml.startTag(null, "RETURN_IS_EXIST_MILEAGE");
            xml.text(this._RETURN_IS_EXIST_MILEAGE);
            xml.endTag(null, "RETURN_IS_EXIST_MILEAGE");
        }
        if (this._IS_NEED_PAY != null) {
            xml.startTag(null, "IS_NEED_PAY");
            xml.text(this._IS_NEED_PAY);
            xml.endTag(null, "IS_NEED_PAY");
        }
        if (this._IS_TIME_OUT != null) {
            xml.startTag(null, "IS_TIME_OUT");
            xml.text(this._IS_TIME_OUT);
            xml.endTag(null, "IS_TIME_OUT");
        }
        List<emdReturnSegmentCheckInVO> list = this._RETURN_CHECKIN_RRESULT_LIST;
        if (list != null && list.size() > 0) {
            int size = this._RETURN_CHECKIN_RRESULT_LIST.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "RETURN_CHECKIN_RRESULT_LIST");
                this._RETURN_CHECKIN_RRESULT_LIST.get(i).addElementsToNode(xml);
                xml.endTag(null, "RETURN_CHECKIN_RRESULT_LIST");
            }
        }
        if (this._ORDER_NO != null) {
            xml.startTag(null, "ORDER_NO");
            xml.text(this._ORDER_NO);
            xml.endTag(null, "ORDER_NO");
        }
        if (this._ORDER_TIME != null) {
            xml.startTag(null, "ORDER_TIME");
            xml.text(this._ORDER_TIME);
            xml.endTag(null, "ORDER_TIME");
        }
        if (this._RESULT_MSG != null) {
            xml.startTag(null, "RESULT_MSG");
            xml.text(this._RESULT_MSG);
            xml.endTag(null, "RESULT_MSG");
        }
        if (this._RESULT_STATUS != null) {
            xml.startTag(null, "RESULT_STATUS");
            xml.text(this._RESULT_STATUS);
            xml.endTag(null, "RESULT_STATUS");
        }
        if (this._ORDER_PRICE != null) {
            xml.startTag(null, "ORDER_PRICE");
            xml.text(this._ORDER_PRICE);
            xml.endTag(null, "ORDER_PRICE");
        }
        if (this._SP_FLAG != null) {
            xml.startTag(null, "SP_FLAG");
            xml.text(this._SP_FLAG);
            xml.endTag(null, "SP_FLAG");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("RETURN_IS_EXIST_COUPON".equals(parser.getName())) {
                        this._RETURN_IS_EXIST_COUPON = parser.nextText();
                    } else if ("RETURN_IS_EXIST_MILEAGE".equals(parser.getName())) {
                        this._RETURN_IS_EXIST_MILEAGE = parser.nextText();
                    } else if ("IS_NEED_PAY".equals(parser.getName())) {
                        this._IS_NEED_PAY = parser.nextText();
                    } else if ("IS_TIME_OUT".equals(parser.getName())) {
                        this._IS_TIME_OUT = parser.nextText();
                    } else if ("RETURN_CHECKIN_RRESULT_LIST".equals(parser.getName())) {
                        if (this._RETURN_CHECKIN_RRESULT_LIST == null) {
                            this._RETURN_CHECKIN_RRESULT_LIST = new ArrayList();
                        }
                        emdReturnSegmentCheckInVO emdreturnsegmentcheckinvo = new emdReturnSegmentCheckInVO();
                        emdreturnsegmentcheckinvo.parse(binding, parser);
                        this._RETURN_CHECKIN_RRESULT_LIST.add(emdreturnsegmentcheckinvo);
                    } else if ("ORDER_NO".equals(parser.getName())) {
                        this._ORDER_NO = parser.nextText();
                    } else if ("ORDER_TIME".equals(parser.getName())) {
                        this._ORDER_TIME = parser.nextText();
                    } else if ("RESULT_MSG".equals(parser.getName())) {
                        this._RESULT_MSG = parser.nextText();
                    } else if ("RESULT_STATUS".equals(parser.getName())) {
                        this._RESULT_STATUS = parser.nextText();
                    } else if ("ORDER_PRICE".equals(parser.getName())) {
                        this._ORDER_PRICE = parser.nextText();
                    } else if ("SP_FLAG".equals(parser.getName())) {
                        this._SP_FLAG = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}