package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class homeAddressVO extends baseDTOVO implements SOAPObject {
    public String _CITY_NAME = null;
    public String _COUNTRY_NAME = null;
    public String _POSTAL_CODE = null;
    public String _STATE_CODE = null;
    public String _STREET_NMBR = null;
    public String _TELEPHONE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CITY_NAME != null) {
            xml.startTag(null, "CITY_NAME");
            xml.text(this._CITY_NAME);
            xml.endTag(null, "CITY_NAME");
        }
        if (this._COUNTRY_NAME != null) {
            xml.startTag(null, "COUNTRY_NAME");
            xml.text(this._COUNTRY_NAME);
            xml.endTag(null, "COUNTRY_NAME");
        }
        if (this._POSTAL_CODE != null) {
            xml.startTag(null, "POSTAL_CODE");
            xml.text(this._POSTAL_CODE);
            xml.endTag(null, "POSTAL_CODE");
        }
        if (this._STATE_CODE != null) {
            xml.startTag(null, "STATE_CODE");
            xml.text(this._STATE_CODE);
            xml.endTag(null, "STATE_CODE");
        }
        if (this._STREET_NMBR != null) {
            xml.startTag(null, "STREET_NMBR");
            xml.text(this._STREET_NMBR);
            xml.endTag(null, "STREET_NMBR");
        }
        if (this._TELEPHONE != null) {
            xml.startTag(null, "TELEPHONE");
            xml.text(this._TELEPHONE);
            xml.endTag(null, "TELEPHONE");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CITY_NAME".equals(parser.getName())) {
                        this._CITY_NAME = parser.nextText();
                    } else if ("COUNTRY_NAME".equals(parser.getName())) {
                        this._COUNTRY_NAME = parser.nextText();
                    } else if ("POSTAL_CODE".equals(parser.getName())) {
                        this._POSTAL_CODE = parser.nextText();
                    } else if ("STATE_CODE".equals(parser.getName())) {
                        this._STATE_CODE = parser.nextText();
                    } else if ("STREET_NMBR".equals(parser.getName())) {
                        this._STREET_NMBR = parser.nextText();
                    } else if ("TELEPHONE".equals(parser.getName())) {
                        this._TELEPHONE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}