package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class otherDocInfoVO extends baseDTOVO implements SOAPObject {
    public String _EFFECTIVE_DATE = null;
    public String _EXPIRE_DATE = null;
    public String _OTHER_DOCID = null;
    public String _OTHER_DOCISSUE_PLACE = null;
    public String _OTHER_DOCTYPE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._EFFECTIVE_DATE != null) {
            xml.startTag(null, "EFFECTIVE_DATE");
            xml.text(this._EFFECTIVE_DATE);
            xml.endTag(null, "EFFECTIVE_DATE");
        }
        if (this._EXPIRE_DATE != null) {
            xml.startTag(null, "EXPIRE_DATE");
            xml.text(this._EXPIRE_DATE);
            xml.endTag(null, "EXPIRE_DATE");
        }
        if (this._OTHER_DOCID != null) {
            xml.startTag(null, "OTHER_DOCID");
            xml.text(this._OTHER_DOCID);
            xml.endTag(null, "OTHER_DOCID");
        }
        if (this._OTHER_DOCISSUE_PLACE != null) {
            xml.startTag(null, "OTHER_DOCISSUE_PLACE");
            xml.text(this._OTHER_DOCISSUE_PLACE);
            xml.endTag(null, "OTHER_DOCISSUE_PLACE");
        }
        if (this._OTHER_DOCTYPE != null) {
            xml.startTag(null, "OTHER_DOCTYPE");
            xml.text(this._OTHER_DOCTYPE);
            xml.endTag(null, "OTHER_DOCTYPE");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("EFFECTIVE_DATE".equals(parser.getName())) {
                        this._EFFECTIVE_DATE = parser.nextText();
                    } else if ("EXPIRE_DATE".equals(parser.getName())) {
                        this._EXPIRE_DATE = parser.nextText();
                    } else if ("OTHER_DOCID".equals(parser.getName())) {
                        this._OTHER_DOCID = parser.nextText();
                    } else if ("OTHER_DOCISSUE_PLACE".equals(parser.getName())) {
                        this._OTHER_DOCISSUE_PLACE = parser.nextText();
                    } else if ("OTHER_DOCTYPE".equals(parser.getName())) {
                        this._OTHER_DOCTYPE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}