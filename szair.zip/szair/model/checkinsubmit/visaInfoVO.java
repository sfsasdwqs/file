package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class visaInfoVO extends baseDTOVO implements SOAPObject {
    public String _EFFECTIVE_DATE = null;
    public String _EXPIRE_DATE = null;
    public String _VISA_ID = null;
    public String _VISAISSUE_PLACE = null;
    public String _VISA_TYPE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._EFFECTIVE_DATE != null) {
            xml.startTag(null, "EFFECTIVE_DATE");
            xml.text(this._EFFECTIVE_DATE);
            xml.endTag(null, "EFFECTIVE_DATE");
        }
        if (this._EXPIRE_DATE != null) {
            xml.startTag(null, "EXPIRE_DATE");
            xml.text(this._EXPIRE_DATE);
            xml.endTag(null, "EXPIRE_DATE");
        }
        if (this._VISA_ID != null) {
            xml.startTag(null, "VISA_ID");
            xml.text(this._VISA_ID);
            xml.endTag(null, "VISA_ID");
        }
        if (this._VISAISSUE_PLACE != null) {
            xml.startTag(null, "VISAISSUE_PLACE");
            xml.text(this._VISAISSUE_PLACE);
            xml.endTag(null, "VISAISSUE_PLACE");
        }
        if (this._VISA_TYPE != null) {
            xml.startTag(null, "VISA_TYPE");
            xml.text(this._VISA_TYPE);
            xml.endTag(null, "VISA_TYPE");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("EFFECTIVE_DATE".equals(parser.getName())) {
                        this._EFFECTIVE_DATE = parser.nextText();
                    } else if ("EXPIRE_DATE".equals(parser.getName())) {
                        this._EXPIRE_DATE = parser.nextText();
                    } else if ("VISA_ID".equals(parser.getName())) {
                        this._VISA_ID = parser.nextText();
                    } else if ("VISAISSUE_PLACE".equals(parser.getName())) {
                        this._VISAISSUE_PLACE = parser.nextText();
                    } else if ("VISA_TYPE".equals(parser.getName())) {
                        this._VISA_TYPE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}