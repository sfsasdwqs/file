package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class checkInTCSubmitVO implements SOAPObject {
    public flightInfoVO _EDI_FLIGHT_INFO = null;
    public passengerInfoVO _EDI_PASSENGER_INFO = null;
    public flightInfoVO _FLIGHT_INFO = null;
    public String _INTERENATION_FLAG = null;
    public passengerInfoVO _PASSENGER_INFO = null;
    public String _PHONE = null;
    public String _PLAT_ID = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._EDI_FLIGHT_INFO != null) {
            xml.startTag(null, "EDI_FLIGHT_INFO");
            this._EDI_FLIGHT_INFO.addElementsToNode(xml);
            xml.endTag(null, "EDI_FLIGHT_INFO");
        }
        if (this._EDI_PASSENGER_INFO != null) {
            xml.startTag(null, "EDI_PASSENGER_INFO");
            this._EDI_PASSENGER_INFO.addElementsToNode(xml);
            xml.endTag(null, "EDI_PASSENGER_INFO");
        }
        if (this._FLIGHT_INFO != null) {
            xml.startTag(null, "FLIGHT_INFO");
            this._FLIGHT_INFO.addElementsToNode(xml);
            xml.endTag(null, "FLIGHT_INFO");
        }
        if (this._INTERENATION_FLAG != null) {
            xml.startTag(null, "INTERENATION_FLAG");
            xml.text(this._INTERENATION_FLAG);
            xml.endTag(null, "INTERENATION_FLAG");
        }
        if (this._PASSENGER_INFO != null) {
            xml.startTag(null, "PASSENGER_INFO");
            this._PASSENGER_INFO.addElementsToNode(xml);
            xml.endTag(null, "PASSENGER_INFO");
        }
        if (this._PHONE != null) {
            xml.startTag(null, "PHONE");
            xml.text(this._PHONE);
            xml.endTag(null, "PHONE");
        }
        if (this._PLAT_ID != null) {
            xml.startTag(null, "PLAT_ID");
            xml.text(this._PLAT_ID);
            xml.endTag(null, "PLAT_ID");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("EDI_FLIGHT_INFO".equals(parser.getName())) {
                        flightInfoVO flightinfovo = new flightInfoVO();
                        flightinfovo.parse(binding, parser);
                        this._EDI_FLIGHT_INFO = flightinfovo;
                    } else if ("EDI_PASSENGER_INFO".equals(parser.getName())) {
                        passengerInfoVO passengerinfovo = new passengerInfoVO();
                        passengerinfovo.parse(binding, parser);
                        this._EDI_PASSENGER_INFO = passengerinfovo;
                    } else if ("FLIGHT_INFO".equals(parser.getName())) {
                        flightInfoVO flightinfovo2 = new flightInfoVO();
                        flightinfovo2.parse(binding, parser);
                        this._FLIGHT_INFO = flightinfovo2;
                    } else if ("INTERENATION_FLAG".equals(parser.getName())) {
                        this._INTERENATION_FLAG = parser.nextText();
                    } else if ("PASSENGER_INFO".equals(parser.getName())) {
                        passengerInfoVO passengerinfovo2 = new passengerInfoVO();
                        passengerinfovo2.parse(binding, parser);
                        this._PASSENGER_INFO = passengerinfovo2;
                    } else if ("PHONE".equals(parser.getName())) {
                        this._PHONE = parser.nextText();
                    } else if ("PLAT_ID".equals(parser.getName())) {
                        this._PLAT_ID = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}