package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class emdCheckInSubmitVO extends baseDTOVO implements SOAPObject {
    public String _AES_PHONE_NO = null;
    public String _CABIN = null;
    public String _CARD_NO = null;
    public String _ID_NO = null;
    public String _ID_TYPE = null;
    public checkinIntlInfoVO _CHECKIN_INTL_VO = null;
    public String _DEP_TIME = null;
    public String _FLIGHT_NO = null;
    public String _FLIGHT_TIME = null;
    public String _ORG_CITY = null;
    public String _IS_CHILD = null;
    public String _IS_INIT = null;
    public String _IS_INTER_LINING = null;
    public String _INTERNATIONAL_FLAG = null;
    public String _IS_MAIN = null;
    public String _IS_TC = null;
    public String _MEMBER_NUM = null;
    public String _MEMBER_TYPE = null;
    public String _OPERATOR_ID = null;
    public String _OPERATOR_NAME = null;
    public String _PASSENGER_NAME = null;
    public String _PHONE_NO = null;
    public String _PLAT_ID = null;
    public String _PNR = null;
    public String _SEAT_NO = null;
    public String _SEAT_TYPE = null;
    public String _TK_TICKETNO = null;
    public String _DEP_CITY = null;
    public String _TOUR_INDEX = null;
    public String _ARRIVE_DATE = null;
    public String _ARRIVE_TIME = null;
    public String _OLD_SEAT_NO = null;
    public String _IS_CA_SERIES = null;
    public String _CARR_AIRLINE_CODE = null;
    public String _CARR_FLIGHT_NUMBER = null;
    public String _SEAT_PRICE = null;
    public String _RESERVATION_FLAG = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._AES_PHONE_NO != null) {
            xml.startTag(null, "AES_PHONE_NO");
            xml.text(this._AES_PHONE_NO);
            xml.endTag(null, "AES_PHONE_NO");
        }
        if (this._CABIN != null) {
            xml.startTag(null, "CABIN");
            xml.text(this._CABIN);
            xml.endTag(null, "CABIN");
        }
        if (this._CARD_NO != null) {
            xml.startTag(null, "CARD_NO");
            xml.text(this._CARD_NO);
            xml.endTag(null, "CARD_NO");
        }
        if (this._ID_NO != null) {
            xml.startTag(null, "ID_NO");
            xml.text(this._ID_NO);
            xml.endTag(null, "ID_NO");
        }
        if (this._ID_TYPE != null) {
            xml.startTag(null, "ID_TYPE");
            xml.text(this._ID_TYPE);
            xml.endTag(null, "ID_TYPE");
        }
        if (this._CHECKIN_INTL_VO != null) {
            xml.startTag(null, "CHECKIN_INTL_VO");
            this._CHECKIN_INTL_VO.addElementsToNode(xml);
            xml.endTag(null, "CHECKIN_INTL_VO");
        }
        if (this._DEP_TIME != null) {
            xml.startTag(null, "DEP_TIME");
            xml.text(this._DEP_TIME);
            xml.endTag(null, "DEP_TIME");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._FLIGHT_TIME != null) {
            xml.startTag(null, "FLIGHT_TIME");
            xml.text(this._FLIGHT_TIME);
            xml.endTag(null, "FLIGHT_TIME");
        }
        if (this._ORG_CITY != null) {
            xml.startTag(null, "ORG_CITY");
            xml.text(this._ORG_CITY);
            xml.endTag(null, "ORG_CITY");
        }
        if (this._IS_CHILD != null) {
            xml.startTag(null, "IS_CHILD");
            xml.text(this._IS_CHILD);
            xml.endTag(null, "IS_CHILD");
        }
        if (this._IS_INIT != null) {
            xml.startTag(null, "IS_INIT");
            xml.text(this._IS_INIT);
            xml.endTag(null, "IS_INIT");
        }
        if (this._IS_INTER_LINING != null) {
            xml.startTag(null, "IS_INTER_LINING");
            xml.text(this._IS_INTER_LINING);
            xml.endTag(null, "IS_INTER_LINING");
        }
        if (this._INTERNATIONAL_FLAG != null) {
            xml.startTag(null, "INTERNATIONAL_FLAG");
            xml.text(this._INTERNATIONAL_FLAG);
            xml.endTag(null, "INTERNATIONAL_FLAG");
        }
        if (this._IS_MAIN != null) {
            xml.startTag(null, "IS_MAIN");
            xml.text(this._IS_MAIN);
            xml.endTag(null, "IS_MAIN");
        }
        if (this._IS_TC != null) {
            xml.startTag(null, "IS_TC");
            xml.text(this._IS_TC);
            xml.endTag(null, "IS_TC");
        }
        if (this._MEMBER_NUM != null) {
            xml.startTag(null, "MEMBER_NUM");
            xml.text(this._MEMBER_NUM);
            xml.endTag(null, "MEMBER_NUM");
        }
        if (this._MEMBER_TYPE != null) {
            xml.startTag(null, "MEMBER_TYPE");
            xml.text(this._MEMBER_TYPE);
            xml.endTag(null, "MEMBER_TYPE");
        }
        if (this._OPERATOR_ID != null) {
            xml.startTag(null, "OPERATOR_ID");
            xml.text(this._OPERATOR_ID);
            xml.endTag(null, "OPERATOR_ID");
        }
        if (this._OPERATOR_NAME != null) {
            xml.startTag(null, "OPERATOR_NAME");
            xml.text(this._OPERATOR_NAME);
            xml.endTag(null, "OPERATOR_NAME");
        }
        if (this._PASSENGER_NAME != null) {
            xml.startTag(null, "PASSENGER_NAME");
            xml.text(this._PASSENGER_NAME);
            xml.endTag(null, "PASSENGER_NAME");
        }
        if (this._PHONE_NO != null) {
            xml.startTag(null, "PHONE_NO");
            xml.text(this._PHONE_NO);
            xml.endTag(null, "PHONE_NO");
        }
        if (this._PLAT_ID != null) {
            xml.startTag(null, "PLAT_ID");
            xml.text(this._PLAT_ID);
            xml.endTag(null, "PLAT_ID");
        }
        if (this._PNR != null) {
            xml.startTag(null, "PNR");
            xml.text(this._PNR);
            xml.endTag(null, "PNR");
        }
        if (this._SEAT_NO != null) {
            xml.startTag(null, "SEAT_NO");
            xml.text(this._SEAT_NO);
            xml.endTag(null, "SEAT_NO");
        }
        if (this._SEAT_TYPE != null) {
            xml.startTag(null, "SEAT_TYPE");
            xml.text(this._SEAT_TYPE);
            xml.endTag(null, "SEAT_TYPE");
        }
        if (this._TK_TICKETNO != null) {
            xml.startTag(null, "TK_TICKETNO");
            xml.text(this._TK_TICKETNO);
            xml.endTag(null, "TK_TICKETNO");
        }
        if (this._DEP_CITY != null) {
            xml.startTag(null, "DEP_CITY");
            xml.text(this._DEP_CITY);
            xml.endTag(null, "DEP_CITY");
        }
        if (this._TOUR_INDEX != null) {
            xml.startTag(null, "TOUR_INDEX");
            xml.text(this._TOUR_INDEX);
            xml.endTag(null, "TOUR_INDEX");
        }
        if (this._ARRIVE_DATE != null) {
            xml.startTag(null, "ARRIVE_DATE");
            xml.text(this._ARRIVE_DATE);
            xml.endTag(null, "ARRIVE_DATE");
        }
        if (this._ARRIVE_TIME != null) {
            xml.startTag(null, "ARRIVE_TIME");
            xml.text(this._ARRIVE_TIME);
            xml.endTag(null, "ARRIVE_TIME");
        }
        if (this._OLD_SEAT_NO != null) {
            xml.startTag(null, "OLD_SEAT_NO");
            xml.text(this._OLD_SEAT_NO);
            xml.endTag(null, "OLD_SEAT_NO");
        }
        if (this._IS_CA_SERIES != null) {
            xml.startTag(null, "IS_CA_SERIES");
            xml.text(this._IS_CA_SERIES);
            xml.endTag(null, "IS_CA_SERIES");
        }
        if (this._CARR_AIRLINE_CODE != null) {
            xml.startTag(null, "CARR_AIRLINE_CODE");
            xml.text(this._CARR_AIRLINE_CODE);
            xml.endTag(null, "CARR_AIRLINE_CODE");
        }
        if (this._CARR_FLIGHT_NUMBER != null) {
            xml.startTag(null, "CARR_FLIGHT_NUMBER");
            xml.text(this._CARR_FLIGHT_NUMBER);
            xml.endTag(null, "CARR_FLIGHT_NUMBER");
        }
        if (this._SEAT_PRICE != null) {
            xml.startTag(null, "SEAT_PRICE");
            xml.text(this._SEAT_PRICE);
            xml.endTag(null, "SEAT_PRICE");
        }
        if (this._RESERVATION_FLAG != null) {
            xml.startTag(null, "RESERVATION_FLAG");
            xml.text(this._RESERVATION_FLAG);
            xml.endTag(null, "RESERVATION_FLAG");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("AES_PHONE_NO".equals(parser.getName())) {
                        this._AES_PHONE_NO = parser.nextText();
                    } else if ("CABIN".equals(parser.getName())) {
                        this._CABIN = parser.nextText();
                    } else if ("CARD_NO".equals(parser.getName())) {
                        this._CARD_NO = parser.nextText();
                    } else if ("ID_NO".equals(parser.getName())) {
                        this._ID_NO = parser.nextText();
                    } else if ("ID_TYPE".equals(parser.getName())) {
                        this._ID_TYPE = parser.nextText();
                    } else if ("CHECKIN_INTL_VO".equals(parser.getName())) {
                        checkinIntlInfoVO checkinintlinfovo = new checkinIntlInfoVO();
                        checkinintlinfovo.parse(binding, parser);
                        this._CHECKIN_INTL_VO = checkinintlinfovo;
                    } else if ("DEP_TIME".equals(parser.getName())) {
                        this._DEP_TIME = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("FLIGHT_TIME".equals(parser.getName())) {
                        this._FLIGHT_TIME = parser.nextText();
                    } else if ("ORG_CITY".equals(parser.getName())) {
                        this._ORG_CITY = parser.nextText();
                    } else if ("IS_CHILD".equals(parser.getName())) {
                        this._IS_CHILD = parser.nextText();
                    } else if ("IS_INIT".equals(parser.getName())) {
                        this._IS_INIT = parser.nextText();
                    } else if ("IS_INTER_LINING".equals(parser.getName())) {
                        this._IS_INTER_LINING = parser.nextText();
                    } else if ("INTERNATIONAL_FLAG".equals(parser.getName())) {
                        this._INTERNATIONAL_FLAG = parser.nextText();
                    } else if ("IS_MAIN".equals(parser.getName())) {
                        this._IS_MAIN = parser.nextText();
                    } else if ("IS_TC".equals(parser.getName())) {
                        this._IS_TC = parser.nextText();
                    } else if ("MEMBER_NUM".equals(parser.getName())) {
                        this._MEMBER_NUM = parser.nextText();
                    } else if ("MEMBER_TYPE".equals(parser.getName())) {
                        this._MEMBER_TYPE = parser.nextText();
                    } else if ("OPERATOR_ID".equals(parser.getName())) {
                        this._OPERATOR_ID = parser.nextText();
                    } else if ("OPERATOR_NAME".equals(parser.getName())) {
                        this._OPERATOR_NAME = parser.nextText();
                    } else if ("PASSENGER_NAME".equals(parser.getName())) {
                        this._PASSENGER_NAME = parser.nextText();
                    } else if ("PHONE_NO".equals(parser.getName())) {
                        this._PHONE_NO = parser.nextText();
                    } else if ("PLAT_ID".equals(parser.getName())) {
                        this._PLAT_ID = parser.nextText();
                    } else if ("PNR".equals(parser.getName())) {
                        this._PNR = parser.nextText();
                    } else if ("SEAT_NO".equals(parser.getName())) {
                        this._SEAT_NO = parser.nextText();
                    } else if ("SEAT_TYPE".equals(parser.getName())) {
                        this._SEAT_TYPE = parser.nextText();
                    } else if ("TK_TICKETNO".equals(parser.getName())) {
                        this._TK_TICKETNO = parser.nextText();
                    } else if ("DEP_CITY".equals(parser.getName())) {
                        this._DEP_CITY = parser.nextText();
                    } else if ("TOUR_INDEX".equals(parser.getName())) {
                        this._TOUR_INDEX = parser.nextText();
                    } else if ("ARRIVE_DATE".equals(parser.getName())) {
                        this._ARRIVE_DATE = parser.nextText();
                    } else if ("ARRIVE_TIME".equals(parser.getName())) {
                        this._ARRIVE_TIME = parser.nextText();
                    } else if ("OLD_SEAT_NO".equals(parser.getName())) {
                        this._OLD_SEAT_NO = parser.nextText();
                    } else if ("IS_CA_SERIES".equals(parser.getName())) {
                        this._IS_CA_SERIES = parser.nextText();
                    } else if ("CARR_AIRLINE_CODE".equals(parser.getName())) {
                        this._CARR_AIRLINE_CODE = parser.nextText();
                    } else if ("CARR_FLIGHT_NUMBER".equals(parser.getName())) {
                        this._CARR_FLIGHT_NUMBER = parser.nextText();
                    } else if ("SEAT_PRICE".equals(parser.getName())) {
                        this._SEAT_PRICE = parser.nextText();
                    } else if ("RESERVATION_FLAG".equals(parser.getName())) {
                        this._RESERVATION_FLAG = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}