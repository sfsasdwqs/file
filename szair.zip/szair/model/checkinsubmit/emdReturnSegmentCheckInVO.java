package com.common.szair.model.checkinsubmit;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class emdReturnSegmentCheckInVO extends bookingResponseBaseVO implements SOAPObject, Serializable {
    public String _BOARD_TIME = null;
    public String _BOARDING_GATENUMBER = null;
    public String _FLIGHT_NO = null;
    public String _FLIGHT_TIME = null;
    public String _FLIGHT_DATE = null;
    public String _ORG_CITY = null;
    public String _GATE_NUMBER = null;
    public List<emdReturnPassengerCheckInVO> _PASSENGER_LIST = null;
    public String _DST_CITY = null;
    public String _EXPECTED_ARR_TIME = null;
    public String _EXPECTED_ARR_DATE = null;
    public String _ARRIVE_DATE = null;
    public String _ARRIVE_TIME = null;
    public String _DEP_TERM = null;
    public String _ARRI_TERM = null;
    public String _type = null;
    public String _OP_RESULT = null;
    public String _IS_INIT = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/checkin";
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._BOARD_TIME != null) {
            xml.startTag(null, "BOARD_TIME");
            xml.text(this._BOARD_TIME);
            xml.endTag(null, "BOARD_TIME");
        }
        if (this._BOARDING_GATENUMBER != null) {
            xml.startTag(null, "BOARDING_GATENUMBER");
            xml.text(this._BOARDING_GATENUMBER);
            xml.endTag(null, "BOARDING_GATENUMBER");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._FLIGHT_TIME != null) {
            xml.startTag(null, "FLIGHT_TIME");
            xml.text(this._FLIGHT_TIME);
            xml.endTag(null, "FLIGHT_TIME");
        }
        if (this._FLIGHT_DATE != null) {
            xml.startTag(null, "FLIGHT_DATE");
            xml.text(this._FLIGHT_DATE);
            xml.endTag(null, "FLIGHT_DATE");
        }
        if (this._ORG_CITY != null) {
            xml.startTag(null, "ORG_CITY");
            xml.text(this._ORG_CITY);
            xml.endTag(null, "ORG_CITY");
        }
        if (this._GATE_NUMBER != null) {
            xml.startTag(null, "GATE_NUMBER");
            xml.text(this._GATE_NUMBER);
            xml.endTag(null, "GATE_NUMBER");
        }
        List<emdReturnPassengerCheckInVO> list = this._PASSENGER_LIST;
        if (list != null && list.size() > 0) {
            int size = this._PASSENGER_LIST.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "PASSENGER_LIST");
                this._PASSENGER_LIST.get(i).addElementsToNode(xml);
                xml.endTag(null, "PASSENGER_LIST");
            }
        }
        if (this._DST_CITY != null) {
            xml.startTag(null, "DST_CITY");
            xml.text(this._DST_CITY);
            xml.endTag(null, "DST_CITY");
        }
        if (this._EXPECTED_ARR_TIME != null) {
            xml.startTag(null, "EXPECTED_ARR_TIME");
            xml.text(this._EXPECTED_ARR_TIME);
            xml.endTag(null, "EXPECTED_ARR_TIME");
        }
        if (this._EXPECTED_ARR_DATE != null) {
            xml.startTag(null, "EXPECTED_ARR_DATE");
            xml.text(this._EXPECTED_ARR_DATE);
            xml.endTag(null, "EXPECTED_ARR_DATE");
        }
        if (this._ARRIVE_DATE != null) {
            xml.startTag(null, "ARRIVE_DATE");
            xml.text(this._ARRIVE_DATE);
            xml.endTag(null, "ARRIVE_DATE");
        }
        if (this._ARRIVE_TIME != null) {
            xml.startTag(null, "ARRIVE_TIME");
            xml.text(this._ARRIVE_TIME);
            xml.endTag(null, "ARRIVE_TIME");
        }
        if (this._DEP_TERM != null) {
            xml.startTag(null, "DEP_TERM");
            xml.text(this._DEP_TERM);
            xml.endTag(null, "DEP_TERM");
        }
        if (this._ARRI_TERM != null) {
            xml.startTag(null, "ARRI_TERM");
            xml.text(this._ARRI_TERM);
            xml.endTag(null, "ARRI_TERM");
        }
        if (this._type != null) {
            xml.startTag(null, "type");
            xml.text(this._type);
            xml.endTag(null, "type");
        }
        if (this._OP_RESULT != null) {
            xml.startTag(null, "OP_RESULT");
            xml.text(this._OP_RESULT);
            xml.endTag(null, "OP_RESULT");
        }
        if (this._IS_INIT != null) {
            xml.startTag(null, "IS_INIT");
            xml.text(this._IS_INIT);
            xml.endTag(null, "IS_INIT");
        }
    }

    @Override // com.common.szair.model.checkinsubmit.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("BOARD_TIME".equals(parser.getName())) {
                        this._BOARD_TIME = parser.nextText();
                    } else if ("BOARDING_GATENUMBER".equals(parser.getName())) {
                        this._BOARDING_GATENUMBER = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("FLIGHT_TIME".equals(parser.getName())) {
                        this._FLIGHT_TIME = parser.nextText();
                    } else if ("FLIGHT_DATE".equals(parser.getName())) {
                        this._FLIGHT_DATE = parser.nextText();
                    } else if ("ORG_CITY".equals(parser.getName())) {
                        this._ORG_CITY = parser.nextText();
                    } else if ("GATE_NUMBER".equals(parser.getName())) {
                        this._GATE_NUMBER = parser.nextText();
                    } else if ("PASSENGER_LIST".equals(parser.getName())) {
                        if (this._PASSENGER_LIST == null) {
                            this._PASSENGER_LIST = new ArrayList();
                        }
                        emdReturnPassengerCheckInVO emdreturnpassengercheckinvo = new emdReturnPassengerCheckInVO();
                        emdreturnpassengercheckinvo.parse(binding, parser);
                        this._PASSENGER_LIST.add(emdreturnpassengercheckinvo);
                    } else if ("DST_CITY".equals(parser.getName())) {
                        this._DST_CITY = parser.nextText();
                    } else if ("EXPECTED_ARR_TIME".equals(parser.getName())) {
                        this._EXPECTED_ARR_TIME = parser.nextText();
                    } else if ("EXPECTED_ARR_DATE".equals(parser.getName())) {
                        this._EXPECTED_ARR_DATE = parser.nextText();
                    } else if ("ARRIVE_DATE".equals(parser.getName())) {
                        this._ARRIVE_DATE = parser.nextText();
                    } else if ("ARRIVE_TIME".equals(parser.getName())) {
                        this._ARRIVE_TIME = parser.nextText();
                    } else if ("DEP_TERM".equals(parser.getName())) {
                        this._DEP_TERM = parser.nextText();
                    } else if ("ARRI_TERM".equals(parser.getName())) {
                        this._ARRI_TERM = parser.nextText();
                    } else if ("type".equals(parser.getName())) {
                        this._type = parser.nextText();
                    } else if ("OP_RESULT".equals(parser.getName())) {
                        this._OP_RESULT = parser.nextText();
                    } else if ("IS_INIT".equals(parser.getName())) {
                        this._IS_INIT = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}