package com.common.szair.model.citycard;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class sqfCardRefundInfo extends baseDTOVO implements SOAPObject, Serializable {
    public String _CARD_NO = null;
    public String _CERT_NO = null;
    public String _PRODUCT_TYPE = null;
    public String _PSGR_NAME = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/sqfcard";
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CARD_NO != null) {
            xml.startTag(null, "CARD_NO");
            xml.text(this._CARD_NO);
            xml.endTag(null, "CARD_NO");
        }
        if (this._CERT_NO != null) {
            xml.startTag(null, "CERT_NO");
            xml.text(this._CERT_NO);
            xml.endTag(null, "CERT_NO");
        }
        if (this._PRODUCT_TYPE != null) {
            xml.startTag(null, "PRODUCT_TYPE");
            xml.text(this._PRODUCT_TYPE);
            xml.endTag(null, "PRODUCT_TYPE");
        }
        if (this._PSGR_NAME != null) {
            xml.startTag(null, "PSGR_NAME");
            xml.text(this._PSGR_NAME);
            xml.endTag(null, "PSGR_NAME");
        }
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CARD_NO".equals(parser.getName())) {
                        this._CARD_NO = parser.nextText();
                    } else if ("CERT_NO".equals(parser.getName())) {
                        this._CERT_NO = parser.nextText();
                    } else if ("PRODUCT_TYPE".equals(parser.getName())) {
                        this._PRODUCT_TYPE = parser.nextText();
                    } else if ("PSGR_NAME".equals(parser.getName())) {
                        this._PSGR_NAME = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}