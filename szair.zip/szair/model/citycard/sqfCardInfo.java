package com.common.szair.model.citycard;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class sqfCardInfo extends baseDTOVO implements SOAPObject, Serializable {
    public String _INVOICE_STATUS = null;
    public String _ORDER_NO = null;
    public String _ORDER_PRICE = null;
    public String _ORDER_STATUS = null;
    public String _ORDER_TIME = null;
    public String _ORG_FULL_NAME = null;
    public String _PRODUCT_NAME = null;
    public String _PRODUCT_TYPE_NAME = null;
    public String _PSGR_NAME = null;
    public String _REFUND_STATUS = null;
    public String _PRODUCT_TYPE = null;
    public String _CARD_TYPE = null;
    public String _ORDER_TYPE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/sqfcard";
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._INVOICE_STATUS != null) {
            xml.startTag(null, "INVOICE_STATUS");
            xml.text(this._INVOICE_STATUS);
            xml.endTag(null, "INVOICE_STATUS");
        }
        if (this._ORDER_NO != null) {
            xml.startTag(null, "ORDER_NO");
            xml.text(this._ORDER_NO);
            xml.endTag(null, "ORDER_NO");
        }
        if (this._ORDER_PRICE != null) {
            xml.startTag(null, "ORDER_PRICE");
            xml.text(this._ORDER_PRICE);
            xml.endTag(null, "ORDER_PRICE");
        }
        if (this._ORDER_STATUS != null) {
            xml.startTag(null, "ORDER_STATUS");
            xml.text(this._ORDER_STATUS);
            xml.endTag(null, "ORDER_STATUS");
        }
        if (this._ORDER_TIME != null) {
            xml.startTag(null, "ORDER_TIME");
            xml.text(this._ORDER_TIME);
            xml.endTag(null, "ORDER_TIME");
        }
        if (this._ORG_FULL_NAME != null) {
            xml.startTag(null, "ORG_FULL_NAME");
            xml.text(this._ORG_FULL_NAME);
            xml.endTag(null, "ORG_FULL_NAME");
        }
        if (this._PRODUCT_NAME != null) {
            xml.startTag(null, "PRODUCT_NAME");
            xml.text(this._PRODUCT_NAME);
            xml.endTag(null, "PRODUCT_NAME");
        }
        if (this._PRODUCT_TYPE_NAME != null) {
            xml.startTag(null, "PRODUCT_TYPE_NAME");
            xml.text(this._PRODUCT_TYPE_NAME);
            xml.endTag(null, "PRODUCT_TYPE_NAME");
        }
        if (this._PSGR_NAME != null) {
            xml.startTag(null, "PSGR_NAME");
            xml.text(this._PSGR_NAME);
            xml.endTag(null, "PSGR_NAME");
        }
        if (this._REFUND_STATUS != null) {
            xml.startTag(null, "REFUND_STATUS");
            xml.text(this._REFUND_STATUS);
            xml.endTag(null, "REFUND_STATUS");
        }
        if (this._PRODUCT_TYPE != null) {
            xml.startTag(null, "PRODUCT_TYPE");
            xml.text(this._PRODUCT_TYPE);
            xml.endTag(null, "PRODUCT_TYPE");
        }
        if (this._CARD_TYPE != null) {
            xml.startTag(null, "CARD_TYPE");
            xml.text(this._CARD_TYPE);
            xml.endTag(null, "CARD_TYPE");
        }
        if (this._ORDER_TYPE != null) {
            xml.startTag(null, "ORDER_TYPE");
            xml.text(this._ORDER_TYPE);
            xml.endTag(null, "ORDER_TYPE");
        }
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("INVOICE_STATUS".equals(parser.getName())) {
                        this._INVOICE_STATUS = parser.nextText();
                    } else if ("ORDER_NO".equals(parser.getName())) {
                        this._ORDER_NO = parser.nextText();
                    } else if ("ORDER_PRICE".equals(parser.getName())) {
                        this._ORDER_PRICE = parser.nextText();
                    } else if ("ORDER_STATUS".equals(parser.getName())) {
                        this._ORDER_STATUS = parser.nextText();
                    } else if ("ORDER_TIME".equals(parser.getName())) {
                        this._ORDER_TIME = parser.nextText();
                    } else if ("ORG_FULL_NAME".equals(parser.getName())) {
                        this._ORG_FULL_NAME = parser.nextText();
                    } else if ("PRODUCT_NAME".equals(parser.getName())) {
                        this._PRODUCT_NAME = parser.nextText();
                    } else if ("PRODUCT_TYPE_NAME".equals(parser.getName())) {
                        this._PRODUCT_TYPE_NAME = parser.nextText();
                    } else if ("PSGR_NAME".equals(parser.getName())) {
                        this._PSGR_NAME = parser.nextText();
                    } else if ("REFUND_STATUS".equals(parser.getName())) {
                        this._REFUND_STATUS = parser.nextText();
                    } else if ("PRODUCT_TYPE".equals(parser.getName())) {
                        this._PRODUCT_TYPE = parser.nextText();
                    } else if ("CARD_TYPE".equals(parser.getName())) {
                        this._CARD_TYPE = parser.nextText();
                    } else if ("ORDER_TYPE".equals(parser.getName())) {
                        this._ORDER_TYPE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}