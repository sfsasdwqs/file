package com.common.szair.model.citycard;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class sqfCityInfo extends baseDTOVO implements SOAPObject, Serializable {
    public String _AIRPORT = null;
    public String _FULL_NAME = null;
    public String _PRICE = null;
    public String _SHORT_NAME = null;
    public String _PY_NAME = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/sqfcard";
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._AIRPORT != null) {
            xml.startTag(null, "AIRPORT");
            xml.text(this._AIRPORT);
            xml.endTag(null, "AIRPORT");
        }
        if (this._FULL_NAME != null) {
            xml.startTag(null, "FULL_NAME");
            xml.text(this._FULL_NAME);
            xml.endTag(null, "FULL_NAME");
        }
        if (this._PRICE != null) {
            xml.startTag(null, "PRICE");
            xml.text(this._PRICE);
            xml.endTag(null, "PRICE");
        }
        if (this._SHORT_NAME != null) {
            xml.startTag(null, "SHORT_NAME");
            xml.text(this._SHORT_NAME);
            xml.endTag(null, "SHORT_NAME");
        }
        if (this._PY_NAME != null) {
            xml.startTag(null, "PY_NAME");
            xml.text(this._PY_NAME);
            xml.endTag(null, "PY_NAME");
        }
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("AIRPORT".equals(parser.getName())) {
                        this._AIRPORT = parser.nextText();
                    } else if ("FULL_NAME".equals(parser.getName())) {
                        this._FULL_NAME = parser.nextText();
                    } else if ("PRICE".equals(parser.getName())) {
                        this._PRICE = parser.nextText();
                    } else if ("SHORT_NAME".equals(parser.getName())) {
                        this._SHORT_NAME = parser.nextText();
                    } else if ("PY_NAME".equals(parser.getName())) {
                        this._PY_NAME = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}