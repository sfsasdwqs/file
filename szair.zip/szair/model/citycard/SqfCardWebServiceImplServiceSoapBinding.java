package com.common.szair.model.citycard;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class SqfCardWebServiceImplServiceSoapBinding extends SOAPBinding {
    public SqfCardWebServiceImplServiceSoapBinding(String endpoint) {
        super(SqfCardWebServiceImplServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns3", "http://impl.webservice.sqf.shenzhenair.com/");
        hashMap.put("ns4", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns2", "http://com/shenzhenair/mobilewebservice/sqfcard");
        hashMap.put("ns1", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns0", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        return hashMap;
    }

    public querySQFCityListResponse querySQFCityList(querySQFCityList parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("querySQFCityList", parameters);
        }
        querySQFCityListResponse querysqfcitylistresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof querySQFCityListResponse)) {
                    querysqfcitylistresponse = (querySQFCityListResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querysqfcitylistresponse = new querySQFCityListResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querysqfcitylistresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querysqfcitylistresponse != null) {
                return querysqfcitylistresponse;
            }
            querySQFCityListResponse querysqfcitylistresponse2 = new querySQFCityListResponse();
            querysqfcitylistresponse2.setexception(new NullPointerException());
            return querysqfcitylistresponse2;
        } catch (Exception e) {
            querySQFCityListResponse querysqfcitylistresponse3 = new querySQFCityListResponse();
            querysqfcitylistresponse3.setexception(e);
            return querysqfcitylistresponse3;
        }
    }

    public getSqfCardDetailResponse getSqfCardDetail(getSqfCardDetail parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("getSqfCardDetail", parameters);
        }
        getSqfCardDetailResponse getsqfcarddetailresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof getSqfCardDetailResponse)) {
                    getsqfcarddetailresponse = (getSqfCardDetailResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    getsqfcarddetailresponse = new getSqfCardDetailResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    getsqfcarddetailresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (getsqfcarddetailresponse != null) {
                return getsqfcarddetailresponse;
            }
            getSqfCardDetailResponse getsqfcarddetailresponse2 = new getSqfCardDetailResponse();
            getsqfcarddetailresponse2.setexception(new NullPointerException());
            return getsqfcarddetailresponse2;
        } catch (Exception e) {
            getSqfCardDetailResponse getsqfcarddetailresponse3 = new getSqfCardDetailResponse();
            getsqfcarddetailresponse3.setexception(e);
            return getsqfcarddetailresponse3;
        }
    }

    public refundCardResponse refundCard(refundCard parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("refundCard", parameters);
        }
        refundCardResponse refundcardresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof refundCardResponse)) {
                    refundcardresponse = (refundCardResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    refundcardresponse = new refundCardResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    refundcardresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (refundcardresponse != null) {
                return refundcardresponse;
            }
            refundCardResponse refundcardresponse2 = new refundCardResponse();
            refundcardresponse2.setexception(new NullPointerException());
            return refundcardresponse2;
        } catch (Exception e) {
            refundCardResponse refundcardresponse3 = new refundCardResponse();
            refundcardresponse3.setexception(e);
            return refundcardresponse3;
        }
    }

    public getSqfCardListResponse getSqfCardList(getSqfCardList parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("getSqfCardList", parameters);
        }
        getSqfCardListResponse getsqfcardlistresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof getSqfCardListResponse)) {
                    getsqfcardlistresponse = (getSqfCardListResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    getsqfcardlistresponse = new getSqfCardListResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    getsqfcardlistresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (getsqfcardlistresponse != null) {
                return getsqfcardlistresponse;
            }
            getSqfCardListResponse getsqfcardlistresponse2 = new getSqfCardListResponse();
            getsqfcardlistresponse2.setexception(new NullPointerException());
            return getsqfcardlistresponse2;
        } catch (Exception e) {
            getSqfCardListResponse getsqfcardlistresponse3 = new getSqfCardListResponse();
            getsqfcardlistresponse3.setexception(e);
            return getsqfcardlistresponse3;
        }
    }

    public getNewSqfCardListResponse getNewSqfCardList(getNewSqfCardList parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("getNewSqfCardList", parameters);
        }
        getNewSqfCardListResponse getnewsqfcardlistresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof getNewSqfCardListResponse)) {
                    getnewsqfcardlistresponse = (getNewSqfCardListResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    getnewsqfcardlistresponse = new getNewSqfCardListResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    getnewsqfcardlistresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (getnewsqfcardlistresponse != null) {
                return getnewsqfcardlistresponse;
            }
            getNewSqfCardListResponse getnewsqfcardlistresponse2 = new getNewSqfCardListResponse();
            getnewsqfcardlistresponse2.setexception(new NullPointerException());
            return getnewsqfcardlistresponse2;
        } catch (Exception e) {
            getNewSqfCardListResponse getnewsqfcardlistresponse3 = new getNewSqfCardListResponse();
            getnewsqfcardlistresponse3.setexception(e);
            return getnewsqfcardlistresponse3;
        }
    }

    public cancelCardResponse cancelCard(cancelCard parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("cancelCard", parameters);
        }
        cancelCardResponse cancelcardresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof cancelCardResponse)) {
                    cancelcardresponse = (cancelCardResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    cancelcardresponse = new cancelCardResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    cancelcardresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (cancelcardresponse != null) {
                return cancelcardresponse;
            }
            cancelCardResponse cancelcardresponse2 = new cancelCardResponse();
            cancelcardresponse2.setexception(new NullPointerException());
            return cancelcardresponse2;
        } catch (Exception e) {
            cancelCardResponse cancelcardresponse3 = new cancelCardResponse();
            cancelcardresponse3.setexception(e);
            return cancelcardresponse3;
        }
    }

    public yykRefundCardResponse yykRefundCard(yykRefundCard parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("yykRefundCard", parameters);
        }
        yykRefundCardResponse yykrefundcardresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof yykRefundCardResponse)) {
                    yykrefundcardresponse = (yykRefundCardResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    yykrefundcardresponse = new yykRefundCardResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    yykrefundcardresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (yykrefundcardresponse != null) {
                return yykrefundcardresponse;
            }
            yykRefundCardResponse yykrefundcardresponse2 = new yykRefundCardResponse();
            yykrefundcardresponse2.setexception(new NullPointerException());
            return yykrefundcardresponse2;
        } catch (Exception e) {
            yykRefundCardResponse yykrefundcardresponse3 = new yykRefundCardResponse();
            yykrefundcardresponse3.setexception(e);
            return yykrefundcardresponse3;
        }
    }
}