package com.common.szair.model.citycard;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class sqfCardPsgrInfo extends baseDTOVO implements SOAPObject, Serializable {
    public boolean _IS_SHOW_PERSON;
    public String _BUNDLE_NAME = null;
    public String _CERT_NO = null;
    public String _CERT_TYPE = null;
    public String _PRODUCT_PRICE = null;
    public String _PSGR_NAME = null;
    public String _PSGR_PHONE = null;
    public String _PSGR_TYPE = null;
    public String _REFUND_BILL_NO = null;
    public String _REFUND_NO = null;
    public String _REFUND_PRICE = null;
    public String _REFUND_STATUS = null;
    public String _REFUND_STATUS_TITLE = null;
    public String _REFUND_TIME = null;
    public String _PRODUCT_STATUS = null;
    public String _PRODUCT_NO = null;
    public boolean isChecked = false;
    private Exception _exception = null;

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/sqfcard";
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._BUNDLE_NAME != null) {
            xml.startTag(null, "BUNDLE_NAME");
            xml.text(this._BUNDLE_NAME);
            xml.endTag(null, "BUNDLE_NAME");
        }
        if (this._CERT_NO != null) {
            xml.startTag(null, "CERT_NO");
            xml.text(this._CERT_NO);
            xml.endTag(null, "CERT_NO");
        }
        if (this._CERT_TYPE != null) {
            xml.startTag(null, "CERT_TYPE");
            xml.text(this._CERT_TYPE);
            xml.endTag(null, "CERT_TYPE");
        }
        if (this._PRODUCT_PRICE != null) {
            xml.startTag(null, "PRODUCT_PRICE");
            xml.text(this._PRODUCT_PRICE);
            xml.endTag(null, "PRODUCT_PRICE");
        }
        if (this._PSGR_NAME != null) {
            xml.startTag(null, "PSGR_NAME");
            xml.text(this._PSGR_NAME);
            xml.endTag(null, "PSGR_NAME");
        }
        if (this._PSGR_PHONE != null) {
            xml.startTag(null, "PSGR_PHONE");
            xml.text(this._PSGR_PHONE);
            xml.endTag(null, "PSGR_PHONE");
        }
        if (this._PSGR_TYPE != null) {
            xml.startTag(null, "PSGR_TYPE");
            xml.text(this._PSGR_TYPE);
            xml.endTag(null, "PSGR_TYPE");
        }
        if (this._REFUND_BILL_NO != null) {
            xml.startTag(null, "REFUND_BILL_NO");
            xml.text(this._REFUND_BILL_NO);
            xml.endTag(null, "REFUND_BILL_NO");
        }
        if (this._REFUND_NO != null) {
            xml.startTag(null, "REFUND_NO");
            xml.text(this._REFUND_NO);
            xml.endTag(null, "REFUND_NO");
        }
        if (this._REFUND_PRICE != null) {
            xml.startTag(null, "REFUND_PRICE");
            xml.text(this._REFUND_PRICE);
            xml.endTag(null, "REFUND_PRICE");
        }
        if (this._REFUND_STATUS != null) {
            xml.startTag(null, "REFUND_STATUS");
            xml.text(this._REFUND_STATUS);
            xml.endTag(null, "REFUND_STATUS");
        }
        if (this._REFUND_STATUS_TITLE != null) {
            xml.startTag(null, "REFUND_STATUS_TITLE");
            xml.text(this._REFUND_STATUS_TITLE);
            xml.endTag(null, "REFUND_STATUS_TITLE");
        }
        if (this._REFUND_TIME != null) {
            xml.startTag(null, "REFUND_TIME");
            xml.text(this._REFUND_TIME);
            xml.endTag(null, "REFUND_TIME");
        }
        if (this._PRODUCT_STATUS != null) {
            xml.startTag(null, "PRODUCT_STATUS");
            xml.text(this._PRODUCT_STATUS);
            xml.endTag(null, "PRODUCT_STATUS");
        }
        if (this._PRODUCT_NO != null) {
            xml.startTag(null, "PRODUCT_NO");
            xml.text(this._PRODUCT_NO);
            xml.endTag(null, "PRODUCT_NO");
        }
    }

    @Override // com.common.szair.model.citycard.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("BUNDLE_NAME".equals(parser.getName())) {
                        this._BUNDLE_NAME = parser.nextText();
                    } else if ("CERT_NO".equals(parser.getName())) {
                        this._CERT_NO = parser.nextText();
                    } else if ("CERT_TYPE".equals(parser.getName())) {
                        this._CERT_TYPE = parser.nextText();
                    } else if ("PRODUCT_PRICE".equals(parser.getName())) {
                        this._PRODUCT_PRICE = parser.nextText();
                    } else if ("PSGR_NAME".equals(parser.getName())) {
                        this._PSGR_NAME = parser.nextText();
                    } else if ("PSGR_PHONE".equals(parser.getName())) {
                        this._PSGR_PHONE = parser.nextText();
                    } else if ("PSGR_TYPE".equals(parser.getName())) {
                        this._PSGR_TYPE = parser.nextText();
                    } else if ("REFUND_BILL_NO".equals(parser.getName())) {
                        this._REFUND_BILL_NO = parser.nextText();
                    } else if ("REFUND_NO".equals(parser.getName())) {
                        this._REFUND_NO = parser.nextText();
                    } else if ("REFUND_PRICE".equals(parser.getName())) {
                        this._REFUND_PRICE = parser.nextText();
                    } else if ("REFUND_STATUS".equals(parser.getName())) {
                        this._REFUND_STATUS = parser.nextText();
                    } else if ("REFUND_STATUS_TITLE".equals(parser.getName())) {
                        this._REFUND_STATUS_TITLE = parser.nextText();
                    } else if ("REFUND_TIME".equals(parser.getName())) {
                        this._REFUND_TIME = parser.nextText();
                    } else if ("PRODUCT_STATUS".equals(parser.getName())) {
                        this._PRODUCT_STATUS = parser.nextText();
                    } else if ("PRODUCT_NO".equals(parser.getName())) {
                        this._PRODUCT_NO = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}