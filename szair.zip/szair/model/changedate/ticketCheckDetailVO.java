package com.common.szair.model.changedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class ticketCheckDetailVO implements SOAPObject, Serializable {
    public String _ARRIVE_TIME = null;
    public String _CLASS_CODE = null;
    public String _CLASS_PRICE = null;
    public String _CTAX = null;
    public String _FLIGHT_NO = null;
    public String _FTAX = null;
    public String _FZY_CLASS_BASIC = null;
    public String _FZY_FLAG = null;
    public String _IS_B2C = null;
    public String _IS_CIVIL = null;
    public String _IS_LOCAL_SYSTEM_TICKET = null;
    public String _IS_NEW = null;
    public String _ZERO_CHANGE_FLAG = null;
    public String _MILEAGE_FLAG = null;
    public String _IS_CHD = null;
    public String _MESSAGE = null;
    public String _PNR_NO = null;
    public String _PSG_ID_NO = null;
    public String _PS_GNAME = null;
    public String _PSG_TYPE = null;
    public String _RATE = null;
    public String _SEGMENT = null;
    public ArrayList<specialAvailInfoVO> _SPECIAL_AVAIL_INFO_LIST = null;
    public String _SZAIR_EXPRESS_FLAG = null;
    public String _TAKEOFF_TIME = null;
    public String _TK_ARRIVE_TIME = null;
    public String _TK_CLASS_CODE = null;
    public String _TK_FLIGHT_NO = null;
    public String _TK_SEGMENT = null;
    public String _TK_TAKEOFF_TIME = null;
    public String _TKT_NO = null;
    public String _ZYFL = null;
    public String _ZY_FLAG = null;
    public String _NEW_FARE = null;
    public babyInfoVO _BABY_INFO = null;
    public String _YHDJK_COUNT = null;
    public String _YHDJK_COUPON_MONEY = null;
    public String _YHDJK_USE_MONEY = null;
    public String _YHDJK_ADD_MONEY = null;
    public String _PRIMARY_TIER_NAME = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/orderChangeMerge";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._ARRIVE_TIME != null) {
            xml.startTag(null, "ARRIVE_TIME");
            xml.text(this._ARRIVE_TIME);
            xml.endTag(null, "ARRIVE_TIME");
        }
        if (this._CLASS_CODE != null) {
            xml.startTag(null, "CLASS_CODE");
            xml.text(this._CLASS_CODE);
            xml.endTag(null, "CLASS_CODE");
        }
        if (this._CLASS_PRICE != null) {
            xml.startTag(null, "CLASS_PRICE");
            xml.text(this._CLASS_PRICE);
            xml.endTag(null, "CLASS_PRICE");
        }
        if (this._CTAX != null) {
            xml.startTag(null, "CTAX");
            xml.text(this._CTAX);
            xml.endTag(null, "CTAX");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._FTAX != null) {
            xml.startTag(null, "FTAX");
            xml.text(this._FTAX);
            xml.endTag(null, "FTAX");
        }
        if (this._FZY_CLASS_BASIC != null) {
            xml.startTag(null, "FZY_CLASS_BASIC");
            xml.text(this._FZY_CLASS_BASIC);
            xml.endTag(null, "FZY_CLASS_BASIC");
        }
        if (this._FZY_FLAG != null) {
            xml.startTag(null, "FZY_FLAG");
            xml.text(this._FZY_FLAG);
            xml.endTag(null, "FZY_FLAG");
        }
        if (this._IS_B2C != null) {
            xml.startTag(null, "IS_B2C");
            xml.text(this._IS_B2C);
            xml.endTag(null, "IS_B2C");
        }
        if (this._IS_CIVIL != null) {
            xml.startTag(null, "IS_CIVIL");
            xml.text(this._IS_CIVIL);
            xml.endTag(null, "IS_CIVIL");
        }
        if (this._IS_LOCAL_SYSTEM_TICKET != null) {
            xml.startTag(null, "IS_LOCAL_SYSTEM_TICKET");
            xml.text(this._IS_LOCAL_SYSTEM_TICKET);
            xml.endTag(null, "IS_LOCAL_SYSTEM_TICKET");
        }
        if (this._IS_NEW != null) {
            xml.startTag(null, "IS_NEW");
            xml.text(this._IS_NEW);
            xml.endTag(null, "IS_NEW");
        }
        if (this._ZERO_CHANGE_FLAG != null) {
            xml.startTag(null, "ZERO_CHANGE_FLAG");
            xml.text(this._ZERO_CHANGE_FLAG);
            xml.endTag(null, "ZERO_CHANGE_FLAG");
        }
        if (this._MILEAGE_FLAG != null) {
            xml.startTag(null, "MILEAGE_FLAG");
            xml.text(this._MILEAGE_FLAG);
            xml.endTag(null, "MILEAGE_FLAG");
        }
        if (this._IS_CHD != null) {
            xml.startTag(null, "IS_CHD");
            xml.text(this._IS_CHD);
            xml.endTag(null, "IS_CHD");
        }
        if (this._MESSAGE != null) {
            xml.startTag(null, "MESSAGE");
            xml.text(this._MESSAGE);
            xml.endTag(null, "MESSAGE");
        }
        if (this._PNR_NO != null) {
            xml.startTag(null, "PNR_NO");
            xml.text(this._PNR_NO);
            xml.endTag(null, "PNR_NO");
        }
        if (this._PSG_ID_NO != null) {
            xml.startTag(null, "PSG_ID_NO");
            xml.text(this._PSG_ID_NO);
            xml.endTag(null, "PSG_ID_NO");
        }
        if (this._PS_GNAME != null) {
            xml.startTag(null, "PS_GNAME");
            xml.text(this._PS_GNAME);
            xml.endTag(null, "PS_GNAME");
        }
        if (this._PSG_TYPE != null) {
            xml.startTag(null, "PSG_TYPE");
            xml.text(this._PSG_TYPE);
            xml.endTag(null, "PSG_TYPE");
        }
        if (this._RATE != null) {
            xml.startTag(null, "RATE");
            xml.text(this._RATE);
            xml.endTag(null, "RATE");
        }
        if (this._SEGMENT != null) {
            xml.startTag(null, "SEGMENT");
            xml.text(this._SEGMENT);
            xml.endTag(null, "SEGMENT");
        }
        ArrayList<specialAvailInfoVO> arrayList = this._SPECIAL_AVAIL_INFO_LIST;
        if (arrayList != null && arrayList.size() > 0) {
            int size = this._SPECIAL_AVAIL_INFO_LIST.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "SPECIAL_AVAIL_INFO_LIST");
                this._SPECIAL_AVAIL_INFO_LIST.get(i).addElementsToNode(xml);
                xml.endTag(null, "SPECIAL_AVAIL_INFO_LIST");
            }
        }
        if (this._SZAIR_EXPRESS_FLAG != null) {
            xml.startTag(null, "SZAIR_EXPRESS_FLAG");
            xml.text(this._SZAIR_EXPRESS_FLAG);
            xml.endTag(null, "SZAIR_EXPRESS_FLAG");
        }
        if (this._TAKEOFF_TIME != null) {
            xml.startTag(null, "TAKEOFF_TIME");
            xml.text(this._TAKEOFF_TIME);
            xml.endTag(null, "TAKEOFF_TIME");
        }
        if (this._TK_ARRIVE_TIME != null) {
            xml.startTag(null, "TK_ARRIVE_TIME");
            xml.text(this._TK_ARRIVE_TIME);
            xml.endTag(null, "TK_ARRIVE_TIME");
        }
        if (this._TK_CLASS_CODE != null) {
            xml.startTag(null, "TK_CLASS_CODE");
            xml.text(this._TK_CLASS_CODE);
            xml.endTag(null, "TK_CLASS_CODE");
        }
        if (this._TK_FLIGHT_NO != null) {
            xml.startTag(null, "TK_FLIGHT_NO");
            xml.text(this._TK_FLIGHT_NO);
            xml.endTag(null, "TK_FLIGHT_NO");
        }
        if (this._TK_SEGMENT != null) {
            xml.startTag(null, "TK_SEGMENT");
            xml.text(this._TK_SEGMENT);
            xml.endTag(null, "TK_SEGMENT");
        }
        if (this._TK_TAKEOFF_TIME != null) {
            xml.startTag(null, "TK_TAKEOFF_TIME");
            xml.text(this._TK_TAKEOFF_TIME);
            xml.endTag(null, "TK_TAKEOFF_TIME");
        }
        if (this._TKT_NO != null) {
            xml.startTag(null, "TKT_NO");
            xml.text(this._TKT_NO);
            xml.endTag(null, "TKT_NO");
        }
        if (this._ZYFL != null) {
            xml.startTag(null, "ZYFL");
            xml.text(this._ZYFL);
            xml.endTag(null, "ZYFL");
        }
        if (this._ZY_FLAG != null) {
            xml.startTag(null, "ZY_FLAG");
            xml.text(this._ZY_FLAG);
            xml.endTag(null, "ZY_FLAG");
        }
        if (this._NEW_FARE != null) {
            xml.startTag(null, "NEW_FARE");
            xml.text(this._NEW_FARE);
            xml.endTag(null, "NEW_FARE");
        }
        if (this._YHDJK_COUNT != null) {
            xml.startTag(null, "YHDJK_COUNT");
            xml.text(this._YHDJK_COUNT);
            xml.endTag(null, "YHDJK_COUNT");
        }
        if (this._YHDJK_COUPON_MONEY != null) {
            xml.startTag(null, "YHDJK_COUPON_MONEY");
            xml.text(this._YHDJK_COUPON_MONEY);
            xml.endTag(null, "YHDJK_COUPON_MONEY");
        }
        if (this._YHDJK_USE_MONEY != null) {
            xml.startTag(null, "YHDJK_USE_MONEY");
            xml.text(this._YHDJK_USE_MONEY);
            xml.endTag(null, "YHDJK_USE_MONEY");
        }
        if (this._YHDJK_ADD_MONEY != null) {
            xml.startTag(null, "YHDJK_ADD_MONEY");
            xml.text(this._YHDJK_ADD_MONEY);
            xml.endTag(null, "YHDJK_ADD_MONEY");
        }
        if (this._PRIMARY_TIER_NAME != null) {
            xml.startTag(null, "PRIMARY_TIER_NAME");
            xml.text(this._PRIMARY_TIER_NAME);
            xml.endTag(null, "PRIMARY_TIER_NAME");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("ARRIVE_TIME".equals(parser.getName())) {
                        this._ARRIVE_TIME = parser.nextText();
                    } else if ("CLASS_CODE".equals(parser.getName())) {
                        this._CLASS_CODE = parser.nextText();
                    } else if ("CLASS_PRICE".equals(parser.getName())) {
                        this._CLASS_PRICE = parser.nextText();
                    } else if ("CTAX".equals(parser.getName())) {
                        this._CTAX = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("FTAX".equals(parser.getName())) {
                        this._FTAX = parser.nextText();
                    } else if ("FZY_CLASS_BASIC".equals(parser.getName())) {
                        this._FZY_CLASS_BASIC = parser.nextText();
                    } else if ("FZY_FLAG".equals(parser.getName())) {
                        this._FZY_FLAG = parser.nextText();
                    } else if ("IS_B2C".equals(parser.getName())) {
                        this._IS_B2C = parser.nextText();
                    } else if ("IS_CIVIL".equals(parser.getName())) {
                        this._IS_CIVIL = parser.nextText();
                    } else if ("IS_LOCAL_SYSTEM_TICKET".equals(parser.getName())) {
                        this._IS_LOCAL_SYSTEM_TICKET = parser.nextText();
                    } else if ("IS_NEW".equals(parser.getName())) {
                        this._IS_NEW = parser.nextText();
                    } else if ("ZERO_CHANGE_FLAG".equals(parser.getName())) {
                        this._ZERO_CHANGE_FLAG = parser.nextText();
                    } else if ("MILEAGE_FLAG".equals(parser.getName())) {
                        this._MILEAGE_FLAG = parser.nextText();
                    } else if ("IS_CHD".equals(parser.getName())) {
                        this._IS_CHD = parser.nextText();
                    } else if ("MESSAGE".equals(parser.getName())) {
                        this._MESSAGE = parser.nextText();
                    } else if ("PNR_NO".equals(parser.getName())) {
                        this._PNR_NO = parser.nextText();
                    } else if ("PSG_ID_NO".equals(parser.getName())) {
                        this._PSG_ID_NO = parser.nextText();
                    } else if ("PS_GNAME".equals(parser.getName())) {
                        this._PS_GNAME = parser.nextText();
                    } else if ("PSG_TYPE".equals(parser.getName())) {
                        this._PSG_TYPE = parser.nextText();
                    } else if ("RATE".equals(parser.getName())) {
                        this._RATE = parser.nextText();
                    } else if ("SEGMENT".equals(parser.getName())) {
                        this._SEGMENT = parser.nextText();
                    } else if ("SPECIAL_AVAIL_INFO_LIST".equals(parser.getName())) {
                        if (this._SPECIAL_AVAIL_INFO_LIST == null) {
                            this._SPECIAL_AVAIL_INFO_LIST = new ArrayList<>();
                        }
                        specialAvailInfoVO specialavailinfovo = new specialAvailInfoVO();
                        specialavailinfovo.parse(binding, parser);
                        this._SPECIAL_AVAIL_INFO_LIST.add(specialavailinfovo);
                    } else if ("SZAIR_EXPRESS_FLAG".equals(parser.getName())) {
                        this._SZAIR_EXPRESS_FLAG = parser.nextText();
                    } else if ("TAKEOFF_TIME".equals(parser.getName())) {
                        this._TAKEOFF_TIME = parser.nextText();
                    } else if ("TK_ARRIVE_TIME".equals(parser.getName())) {
                        this._TK_ARRIVE_TIME = parser.nextText();
                    } else if ("TK_CLASS_CODE".equals(parser.getName())) {
                        this._TK_CLASS_CODE = parser.nextText();
                    } else if ("TK_FLIGHT_NO".equals(parser.getName())) {
                        this._TK_FLIGHT_NO = parser.nextText();
                    } else if ("TK_SEGMENT".equals(parser.getName())) {
                        this._TK_SEGMENT = parser.nextText();
                    } else if ("TK_TAKEOFF_TIME".equals(parser.getName())) {
                        this._TK_TAKEOFF_TIME = parser.nextText();
                    } else if ("TKT_NO".equals(parser.getName())) {
                        this._TKT_NO = parser.nextText();
                    } else if ("ZYFL".equals(parser.getName())) {
                        this._ZYFL = parser.nextText();
                    } else if ("ZY_FLAG".equals(parser.getName())) {
                        this._ZY_FLAG = parser.nextText();
                    } else if ("NEW_FARE".equals(parser.getName())) {
                        this._NEW_FARE = parser.nextText();
                    } else if ("YHDJK_COUNT".equals(parser.getName())) {
                        this._YHDJK_COUNT = parser.nextText();
                    } else if ("YHDJK_COUPON_MONEY".equals(parser.getName())) {
                        this._YHDJK_COUPON_MONEY = parser.nextText();
                    } else if ("YHDJK_USE_MONEY".equals(parser.getName())) {
                        this._YHDJK_USE_MONEY = parser.nextText();
                    } else if ("YHDJK_ADD_MONEY".equals(parser.getName())) {
                        this._YHDJK_ADD_MONEY = parser.nextText();
                    } else if ("PRIMARY_TIER_NAME".equals(parser.getName())) {
                        this._PRIMARY_TIER_NAME = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}