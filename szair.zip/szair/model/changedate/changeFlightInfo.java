package com.common.szair.model.changedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class changeFlightInfo extends baseDTOVO implements SOAPObject {
    public String _ARRIVE_TIME = null;
    public String _FLIGHT_NO = null;
    public String _PNR_NO = null;
    public String _TAKE_OFF_TIME = null;
    public String _ORG_CITY_CODE = null;
    public String _DST_CITY_CODE = null;
    public String _TKT_STATUS = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/orderChangeMerge";
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._ARRIVE_TIME != null) {
            xml.startTag(null, "ARRIVE_TIME");
            xml.text(this._ARRIVE_TIME);
            xml.endTag(null, "ARRIVE_TIME");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._PNR_NO != null) {
            xml.startTag(null, "PNR_NO");
            xml.text(this._PNR_NO);
            xml.endTag(null, "PNR_NO");
        }
        if (this._TAKE_OFF_TIME != null) {
            xml.startTag(null, "TAKE_OFF_TIME");
            xml.text(this._TAKE_OFF_TIME);
            xml.endTag(null, "TAKE_OFF_TIME");
        }
        if (this._ORG_CITY_CODE != null) {
            xml.startTag(null, "ORG_CITY_CODE");
            xml.text(this._ORG_CITY_CODE);
            xml.endTag(null, "ORG_CITY_CODE");
        }
        if (this._DST_CITY_CODE != null) {
            xml.startTag(null, "DST_CITY_CODE");
            xml.text(this._DST_CITY_CODE);
            xml.endTag(null, "DST_CITY_CODE");
        }
        if (this._TKT_STATUS != null) {
            xml.startTag(null, "TKT_STATUS");
            xml.text(this._TKT_STATUS);
            xml.endTag(null, "TKT_STATUS");
        }
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("ARRIVE_TIME".equals(parser.getName())) {
                        this._ARRIVE_TIME = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("PNR_NO".equals(parser.getName())) {
                        this._PNR_NO = parser.nextText();
                    } else if ("TAKE_OFF_TIME".equals(parser.getName())) {
                        this._TAKE_OFF_TIME = parser.nextText();
                    } else if ("ORG_CITY_CODE".equals(parser.getName())) {
                        this._ORG_CITY_CODE = parser.nextText();
                    } else if ("DST_CITY_CODE".equals(parser.getName())) {
                        this._DST_CITY_CODE = parser.nextText();
                    } else if ("TKT_STATUS".equals(parser.getName())) {
                        this._TKT_STATUS = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}