package com.common.szair.model.changedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class confirmFlightResultVO extends bookingResponseBaseVO implements SOAPObject {
    public String _CODE = null;
    public String _CONTACT_MOBILE = null;
    public String _ERROR_MSG = null;
    public String _PNRNO = null;
    public String _REC_NO = null;
    public String _OP_RESULT = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.changedate.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.changedate.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/orderChangeMerge";
    }

    @Override // com.common.szair.model.changedate.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.changedate.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.changedate.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.changedate.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CODE != null) {
            xml.startTag(null, "CODE");
            xml.text(this._CODE);
            xml.endTag(null, "CODE");
        }
        if (this._CONTACT_MOBILE != null) {
            xml.startTag(null, "CONTACT_MOBILE");
            xml.text(this._CONTACT_MOBILE);
            xml.endTag(null, "CONTACT_MOBILE");
        }
        if (this._ERROR_MSG != null) {
            xml.startTag(null, "ERROR_MSG");
            xml.text(this._ERROR_MSG);
            xml.endTag(null, "ERROR_MSG");
        }
        if (this._PNRNO != null) {
            xml.startTag(null, "PNRNO");
            xml.text(this._PNRNO);
            xml.endTag(null, "PNRNO");
        }
        if (this._REC_NO != null) {
            xml.startTag(null, "REC_NO");
            xml.text(this._REC_NO);
            xml.endTag(null, "REC_NO");
        }
        if (this._OP_RESULT != null) {
            xml.startTag(null, "OP_RESULT");
            xml.text(this._OP_RESULT);
            xml.endTag(null, "OP_RESULT");
        }
    }

    @Override // com.common.szair.model.changedate.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CODE".equals(parser.getName())) {
                        this._CODE = parser.nextText();
                    } else if ("CONTACT_MOBILE".equals(parser.getName())) {
                        this._CONTACT_MOBILE = parser.nextText();
                    } else if ("ERROR_MSG".equals(parser.getName())) {
                        this._ERROR_MSG = parser.nextText();
                    } else if ("PNRNO".equals(parser.getName())) {
                        this._PNRNO = parser.nextText();
                    } else if ("REC_NO".equals(parser.getName())) {
                        this._REC_NO = parser.nextText();
                    } else if ("OP_RESULT".equals(parser.getName())) {
                        this._OP_RESULT = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}