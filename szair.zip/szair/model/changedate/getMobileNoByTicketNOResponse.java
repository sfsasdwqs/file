package com.common.szair.model.changedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class getMobileNoByTicketNOResponse implements SOAPObject {
    public getMobileNoByTicketNOResultVO _GET_MOBILENO_BY_TICKETNO_RESULT = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/orderChangeMerge";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._GET_MOBILENO_BY_TICKETNO_RESULT != null) {
            xml.startTag(null, "GET_MOBILENO_BY_TICKETNO_RESULT");
            this._GET_MOBILENO_BY_TICKETNO_RESULT.addElementsToNode(xml);
            xml.endTag(null, "GET_MOBILENO_BY_TICKETNO_RESULT");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("GET_MOBILENO_BY_TICKETNO_RESULT".equals(parser.getName())) {
                        getMobileNoByTicketNOResultVO getmobilenobyticketnoresultvo = new getMobileNoByTicketNOResultVO();
                        getmobilenobyticketnoresultvo.parse(binding, parser);
                        this._GET_MOBILENO_BY_TICKETNO_RESULT = getmobilenobyticketnoresultvo;
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}