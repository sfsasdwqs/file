package com.common.szair.model.changedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class saveChangeOrderNewConditionVO implements SOAPObject {
    public String _CLIENT_TYPE = null;
    public String _FLIGHT_NO = null;
    public String _IS_SZ_EXPRESS = null;
    public String _MOBILE_NUM = null;
    public String _ORG_DATE = null;
    public String _SEGMENT = null;
    public List<String> _TICKETS = null;
    public String _USER_ID = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/orderChangeMerge";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CLIENT_TYPE != null) {
            xml.startTag(null, "CLIENT_TYPE");
            xml.text(this._CLIENT_TYPE);
            xml.endTag(null, "CLIENT_TYPE");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._IS_SZ_EXPRESS != null) {
            xml.startTag(null, "IS_SZ_EXPRESS");
            xml.text(this._IS_SZ_EXPRESS);
            xml.endTag(null, "IS_SZ_EXPRESS");
        }
        if (this._MOBILE_NUM != null) {
            xml.startTag(null, "MOBILE_NUM");
            xml.text(this._MOBILE_NUM);
            xml.endTag(null, "MOBILE_NUM");
        }
        if (this._ORG_DATE != null) {
            xml.startTag(null, "ORG_DATE");
            xml.text(this._ORG_DATE);
            xml.endTag(null, "ORG_DATE");
        }
        if (this._SEGMENT != null) {
            xml.startTag(null, "SEGMENT");
            xml.text(this._SEGMENT);
            xml.endTag(null, "SEGMENT");
        }
        List<String> list = this._TICKETS;
        if (list != null && list.size() > 0) {
            int size = this._TICKETS.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "TICKETS");
                xml.text(this._TICKETS.get(i));
                xml.endTag(null, "TICKETS");
            }
        }
        if (this._USER_ID != null) {
            xml.startTag(null, "USER_ID");
            xml.text(this._USER_ID);
            xml.endTag(null, "USER_ID");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CLIENT_TYPE".equals(parser.getName())) {
                        this._CLIENT_TYPE = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("IS_SZ_EXPRESS".equals(parser.getName())) {
                        this._IS_SZ_EXPRESS = parser.nextText();
                    } else if ("MOBILE_NUM".equals(parser.getName())) {
                        this._MOBILE_NUM = parser.nextText();
                    } else if ("ORG_DATE".equals(parser.getName())) {
                        this._ORG_DATE = parser.nextText();
                    } else if ("SEGMENT".equals(parser.getName())) {
                        this._SEGMENT = parser.nextText();
                    } else if ("TICKETS".equals(parser.getName())) {
                        if (this._TICKETS == null) {
                            this._TICKETS = new ArrayList();
                        }
                        this._TICKETS.add(parser.nextText());
                    } else if ("USER_ID".equals(parser.getName())) {
                        this._USER_ID = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}