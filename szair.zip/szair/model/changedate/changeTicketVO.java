package com.common.szair.model.changedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class changeTicketVO implements SOAPObject, Serializable {
    public List<changeTicketPersonVO> _ACQUAINTANCE = null;
    public String _ARRV_AIRPT = null;
    public String _ARRV_CT = null;
    public String _CLS_NM = null;
    public String _DPT_AIRPT = null;
    public String _DPT_CT = null;
    public String _EI = null;
    public String _ET_TKT_NO = null;
    public String _ET_TKT_STATUS = null;
    public Double _FARE = null;
    public String _FFP_CRD_NBR = null;
    public String _FFP_PAX_CLASS = null;
    public String _FLT_ATUL_DPT_TM = null;
    public String _FLT_NBR = null;
    public String _FLT_SCHD_ARRV_TM = null;
    public String _FST_LEG_DPT_DT = null;
    public String _FST_LEG_ARR_DT = null;
    public String _INDVL_ID_NBR = null;
    public String _PAX_NM = null;
    public String _SUB_CLS_CD = null;
    public ticketCheckDetailVO _TICKET_CHANGE_DETAIL = null;
    public String _TICKET_STATUS = null;
    public String _TOUR_CODE = null;
    public String _ERROR_MESSAGE = null;
    public String _PNR = null;
    public String _SEARCH_TYPE = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/orderChangeMerge";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        List<changeTicketPersonVO> list = this._ACQUAINTANCE;
        if (list != null && list.size() > 0) {
            int size = this._ACQUAINTANCE.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "ACQUAINTANCE");
                this._ACQUAINTANCE.get(i).addElementsToNode(xml);
                xml.endTag(null, "ACQUAINTANCE");
            }
        }
        if (this._ARRV_AIRPT != null) {
            xml.startTag(null, "ARRV_AIRPT");
            xml.text(this._ARRV_AIRPT);
            xml.endTag(null, "ARRV_AIRPT");
        }
        if (this._ARRV_CT != null) {
            xml.startTag(null, "ARRV_CT");
            xml.text(this._ARRV_CT);
            xml.endTag(null, "ARRV_CT");
        }
        if (this._CLS_NM != null) {
            xml.startTag(null, "CLS_NM");
            xml.text(this._CLS_NM);
            xml.endTag(null, "CLS_NM");
        }
        if (this._DPT_AIRPT != null) {
            xml.startTag(null, "DPT_AIRPT");
            xml.text(this._DPT_AIRPT);
            xml.endTag(null, "DPT_AIRPT");
        }
        if (this._DPT_CT != null) {
            xml.startTag(null, "DPT_CT");
            xml.text(this._DPT_CT);
            xml.endTag(null, "DPT_CT");
        }
        if (this._EI != null) {
            xml.startTag(null, "EI");
            xml.text(this._EI);
            xml.endTag(null, "EI");
        }
        if (this._ET_TKT_NO != null) {
            xml.startTag(null, "ET_TKT_NO");
            xml.text(this._ET_TKT_NO);
            xml.endTag(null, "ET_TKT_NO");
        }
        if (this._ET_TKT_STATUS != null) {
            xml.startTag(null, "ET_TKT_STATUS");
            xml.text(this._ET_TKT_STATUS);
            xml.endTag(null, "ET_TKT_STATUS");
        }
        if (this._FARE != null) {
            xml.startTag(null, "FARE");
            xml.text(String.valueOf(this._FARE));
            xml.endTag(null, "FARE");
        }
        if (this._FFP_CRD_NBR != null) {
            xml.startTag(null, "FFP_CRD_NBR");
            xml.text(this._FFP_CRD_NBR);
            xml.endTag(null, "FFP_CRD_NBR");
        }
        if (this._FFP_PAX_CLASS != null) {
            xml.startTag(null, "FFP_PAX_CLASS");
            xml.text(this._FFP_PAX_CLASS);
            xml.endTag(null, "FFP_PAX_CLASS");
        }
        if (this._FLT_ATUL_DPT_TM != null) {
            xml.startTag(null, "FLT_ATUL_DPT_TM");
            xml.text(this._FLT_ATUL_DPT_TM);
            xml.endTag(null, "FLT_ATUL_DPT_TM");
        }
        if (this._FLT_NBR != null) {
            xml.startTag(null, "FLT_NBR");
            xml.text(this._FLT_NBR);
            xml.endTag(null, "FLT_NBR");
        }
        if (this._FLT_SCHD_ARRV_TM != null) {
            xml.startTag(null, "FLT_SCHD_ARRV_TM");
            xml.text(this._FLT_SCHD_ARRV_TM);
            xml.endTag(null, "FLT_SCHD_ARRV_TM");
        }
        if (this._FST_LEG_DPT_DT != null) {
            xml.startTag(null, "FST_LEG_DPT_DT");
            xml.text(this._FST_LEG_DPT_DT);
            xml.endTag(null, "FST_LEG_DPT_DT");
        }
        if (this._FST_LEG_ARR_DT != null) {
            xml.startTag(null, "FST_LEG_ARR_DT");
            xml.text(this._FST_LEG_ARR_DT);
            xml.endTag(null, "FST_LEG_ARR_DT");
        }
        if (this._INDVL_ID_NBR != null) {
            xml.startTag(null, "INDVL_ID_NBR");
            xml.text(this._INDVL_ID_NBR);
            xml.endTag(null, "INDVL_ID_NBR");
        }
        if (this._PAX_NM != null) {
            xml.startTag(null, "PAX_NM");
            xml.text(this._PAX_NM);
            xml.endTag(null, "PAX_NM");
        }
        if (this._SUB_CLS_CD != null) {
            xml.startTag(null, "SUB_CLS_CD");
            xml.text(this._SUB_CLS_CD);
            xml.endTag(null, "SUB_CLS_CD");
        }
        if (this._TICKET_CHANGE_DETAIL != null) {
            xml.startTag(null, "TICKET_CHANGE_DETAIL");
            this._TICKET_CHANGE_DETAIL.addElementsToNode(xml);
            xml.endTag(null, "TICKET_CHANGE_DETAIL");
        }
        if (this._TICKET_STATUS != null) {
            xml.startTag(null, "TICKET_STATUS");
            xml.text(this._TICKET_STATUS);
            xml.endTag(null, "TICKET_STATUS");
        }
        if (this._TOUR_CODE != null) {
            xml.startTag(null, "TOUR_CODE");
            xml.text(this._TOUR_CODE);
            xml.endTag(null, "TOUR_CODE");
        }
        if (this._PNR != null) {
            xml.startTag(null, "PNR");
            xml.text(this._PNR);
            xml.endTag(null, "PNR");
        }
        if (this._ERROR_MESSAGE != null) {
            xml.startTag(null, "ERROR_MESSAGE");
            xml.text(this._ERROR_MESSAGE);
            xml.endTag(null, "ERROR_MESSAGE");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("ACQUAINTANCE".equals(parser.getName())) {
                        if (this._ACQUAINTANCE == null) {
                            this._ACQUAINTANCE = new ArrayList();
                        }
                        changeTicketPersonVO changeticketpersonvo = new changeTicketPersonVO();
                        changeticketpersonvo.parse(binding, parser);
                        this._ACQUAINTANCE.add(changeticketpersonvo);
                    } else if ("ARRV_AIRPT".equals(parser.getName())) {
                        this._ARRV_AIRPT = parser.nextText();
                    } else if ("ARRV_CT".equals(parser.getName())) {
                        this._ARRV_CT = parser.nextText();
                    } else if ("CLS_NM".equals(parser.getName())) {
                        this._CLS_NM = parser.nextText();
                    } else if ("DPT_AIRPT".equals(parser.getName())) {
                        this._DPT_AIRPT = parser.nextText();
                    } else if ("DPT_CT".equals(parser.getName())) {
                        this._DPT_CT = parser.nextText();
                    } else if ("EI".equals(parser.getName())) {
                        this._EI = parser.nextText();
                    } else if ("ET_TKT_NO".equals(parser.getName())) {
                        this._ET_TKT_NO = parser.nextText();
                    } else if ("ET_TKT_STATUS".equals(parser.getName())) {
                        this._ET_TKT_STATUS = parser.nextText();
                    } else if ("FARE".equals(parser.getName())) {
                        this._FARE = Double.valueOf(parser.nextText());
                    } else if ("FFP_CRD_NBR".equals(parser.getName())) {
                        this._FFP_CRD_NBR = parser.nextText();
                    } else if ("FFP_PAX_CLASS".equals(parser.getName())) {
                        this._FFP_PAX_CLASS = parser.nextText();
                    } else if ("FLT_ATUL_DPT_TM".equals(parser.getName())) {
                        this._FLT_ATUL_DPT_TM = parser.nextText();
                    } else if ("FLT_NBR".equals(parser.getName())) {
                        this._FLT_NBR = parser.nextText();
                    } else if ("FLT_SCHD_ARRV_TM".equals(parser.getName())) {
                        this._FLT_SCHD_ARRV_TM = parser.nextText();
                    } else if ("FST_LEG_DPT_DT".equals(parser.getName())) {
                        this._FST_LEG_DPT_DT = parser.nextText();
                    } else if ("FST_LEG_ARR_DT".equals(parser.getName())) {
                        this._FST_LEG_ARR_DT = parser.nextText();
                    } else if ("INDVL_ID_NBR".equals(parser.getName())) {
                        this._INDVL_ID_NBR = parser.nextText();
                    } else if ("PAX_NM".equals(parser.getName())) {
                        this._PAX_NM = parser.nextText();
                    } else if ("SUB_CLS_CD".equals(parser.getName())) {
                        this._SUB_CLS_CD = parser.nextText();
                    } else if ("TICKET_CHANGE_DETAIL".equals(parser.getName())) {
                        ticketCheckDetailVO ticketcheckdetailvo = new ticketCheckDetailVO();
                        ticketcheckdetailvo.parse(binding, parser);
                        this._TICKET_CHANGE_DETAIL = ticketcheckdetailvo;
                    } else if ("TICKET_STATUS".equals(parser.getName())) {
                        this._TICKET_STATUS = parser.nextText();
                    } else if ("TOUR_CODE".equals(parser.getName())) {
                        this._TOUR_CODE = parser.nextText();
                    } else if ("ERROR_MESSAGE".equals(parser.getName())) {
                        this._ERROR_MESSAGE = parser.nextText();
                    } else if ("PNR".equals(parser.getName())) {
                        this._PNR = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}