package com.common.szair.model.changedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class searchChangeTicketByTicketNoConditionVO implements SOAPObject {
    public String _CAPTCHA_CODE = null;
    public String _DST_CODE = null;
    public String _ORG_CODE = null;
    public String _SEARCH_TYPE = null;
    public String _TICKET_NO = null;
    public String _USER_ID = null;
    public String _CONST_ID = null;
    public String _CAPTCHA_RESULT = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/orderChangeMerge";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CAPTCHA_CODE != null) {
            xml.startTag(null, "CAPTCHA_CODE");
            xml.text(this._CAPTCHA_CODE);
            xml.endTag(null, "CAPTCHA_CODE");
        }
        if (this._DST_CODE != null) {
            xml.startTag(null, "DST_CODE");
            xml.text(this._DST_CODE);
            xml.endTag(null, "DST_CODE");
        }
        if (this._ORG_CODE != null) {
            xml.startTag(null, "ORG_CODE");
            xml.text(this._ORG_CODE);
            xml.endTag(null, "ORG_CODE");
        }
        if (this._SEARCH_TYPE != null) {
            xml.startTag(null, "SEARCH_TYPE");
            xml.text(this._SEARCH_TYPE);
            xml.endTag(null, "SEARCH_TYPE");
        }
        if (this._TICKET_NO != null) {
            xml.startTag(null, "TICKET_NO");
            xml.text(this._TICKET_NO);
            xml.endTag(null, "TICKET_NO");
        }
        if (this._USER_ID != null) {
            xml.startTag(null, "USER_ID");
            xml.text(this._USER_ID);
            xml.endTag(null, "USER_ID");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CAPTCHA_CODE".equals(parser.getName())) {
                        this._CAPTCHA_CODE = parser.nextText();
                    } else if ("DST_CODE".equals(parser.getName())) {
                        this._DST_CODE = parser.nextText();
                    } else if ("ORG_CODE".equals(parser.getName())) {
                        this._ORG_CODE = parser.nextText();
                    } else if ("SEARCH_TYPE".equals(parser.getName())) {
                        this._SEARCH_TYPE = parser.nextText();
                    } else if ("TICKET_NO".equals(parser.getName())) {
                        this._TICKET_NO = parser.nextText();
                    } else if ("USER_ID".equals(parser.getName())) {
                        this._USER_ID = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}