package com.common.szair.model.changedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class OrderChangeMergeWebServiceImplServiceSoapBinding extends SOAPBinding {
    public OrderChangeMergeWebServiceImplServiceSoapBinding(String endpoint) {
        super(OrderChangeMergeWebServiceImplServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns4", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns1", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns0", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns3", "http://impl.webservice.orderchange.shenzhenair.com/");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        hashMap.put("ns2", "http://com/shenzhenair/mobilewebservice/orderChangeMerge");
        return hashMap;
    }

    public saveChangeOrderResponse saveChangeOrder(saveChangeOrder parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("saveChangeOrder", parameters);
        }
        saveChangeOrderResponse savechangeorderresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof saveChangeOrderResponse)) {
                    savechangeorderresponse = (saveChangeOrderResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    savechangeorderresponse = new saveChangeOrderResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    savechangeorderresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (savechangeorderresponse != null) {
                return savechangeorderresponse;
            }
            saveChangeOrderResponse savechangeorderresponse2 = new saveChangeOrderResponse();
            savechangeorderresponse2.setexception(new NullPointerException());
            return savechangeorderresponse2;
        } catch (java.lang.Exception e) {
            saveChangeOrderResponse savechangeorderresponse3 = new saveChangeOrderResponse();
            savechangeorderresponse3.setexception(e);
            return savechangeorderresponse3;
        }
    }

    public getMobileNoByTicketNOResponse getMobileNoByTicketNO(getMobileNoByTicketNO parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("getMobileNoByTicketNO", parameters);
        }
        getMobileNoByTicketNOResponse getmobilenobyticketnoresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof getMobileNoByTicketNOResponse)) {
                    getmobilenobyticketnoresponse = (getMobileNoByTicketNOResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    getmobilenobyticketnoresponse = new getMobileNoByTicketNOResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    getmobilenobyticketnoresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (getmobilenobyticketnoresponse != null) {
                return getmobilenobyticketnoresponse;
            }
            getMobileNoByTicketNOResponse getmobilenobyticketnoresponse2 = new getMobileNoByTicketNOResponse();
            getmobilenobyticketnoresponse2.setexception(new NullPointerException());
            return getmobilenobyticketnoresponse2;
        } catch (java.lang.Exception e) {
            getMobileNoByTicketNOResponse getmobilenobyticketnoresponse3 = new getMobileNoByTicketNOResponse();
            getmobilenobyticketnoresponse3.setexception(e);
            return getmobilenobyticketnoresponse3;
        }
    }

    public sendCaptchaResponse sendCaptcha(sendCaptcha parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("sendCaptcha", parameters);
        }
        sendCaptchaResponse sendcaptcharesponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof sendCaptchaResponse)) {
                    sendcaptcharesponse = (sendCaptchaResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    sendcaptcharesponse = new sendCaptchaResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    sendcaptcharesponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (sendcaptcharesponse != null) {
                return sendcaptcharesponse;
            }
            sendCaptchaResponse sendcaptcharesponse2 = new sendCaptchaResponse();
            sendcaptcharesponse2.setexception(new NullPointerException());
            return sendcaptcharesponse2;
        } catch (java.lang.Exception e) {
            sendCaptchaResponse sendcaptcharesponse3 = new sendCaptchaResponse();
            sendcaptcharesponse3.setexception(e);
            return sendcaptcharesponse3;
        }
    }

    public searchChangeTicketByTicketNoResponse searchChangeTicketByTicketNo(searchChangeTicketByTicketNo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("searchChangeTicketByTicketNo", parameters);
        }
        searchChangeTicketByTicketNoResponse searchchangeticketbyticketnoresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof searchChangeTicketByTicketNoResponse)) {
                    searchchangeticketbyticketnoresponse = (searchChangeTicketByTicketNoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    searchchangeticketbyticketnoresponse = new searchChangeTicketByTicketNoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    searchchangeticketbyticketnoresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (searchchangeticketbyticketnoresponse != null) {
                return searchchangeticketbyticketnoresponse;
            }
            searchChangeTicketByTicketNoResponse searchchangeticketbyticketnoresponse2 = new searchChangeTicketByTicketNoResponse();
            searchchangeticketbyticketnoresponse2.setexception(new NullPointerException());
            return searchchangeticketbyticketnoresponse2;
        } catch (java.lang.Exception e) {
            searchChangeTicketByTicketNoResponse searchchangeticketbyticketnoresponse3 = new searchChangeTicketByTicketNoResponse();
            searchchangeticketbyticketnoresponse3.setexception(e);
            return searchchangeticketbyticketnoresponse3;
        }
    }

    public sendMessageByTicketNoResponse sendMessageByTicketNo(sendMessageByTicketNo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("sendMessageByTicketNo", parameters);
        }
        sendMessageByTicketNoResponse sendmessagebyticketnoresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof sendMessageByTicketNoResponse)) {
                    sendmessagebyticketnoresponse = (sendMessageByTicketNoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    sendmessagebyticketnoresponse = new sendMessageByTicketNoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    sendmessagebyticketnoresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (sendmessagebyticketnoresponse != null) {
                return sendmessagebyticketnoresponse;
            }
            sendMessageByTicketNoResponse sendmessagebyticketnoresponse2 = new sendMessageByTicketNoResponse();
            sendmessagebyticketnoresponse2.setexception(new NullPointerException());
            return sendmessagebyticketnoresponse2;
        } catch (java.lang.Exception e) {
            sendMessageByTicketNoResponse sendmessagebyticketnoresponse3 = new sendMessageByTicketNoResponse();
            sendmessagebyticketnoresponse3.setexception(e);
            return sendmessagebyticketnoresponse3;
        }
    }

    public searchChangeTicketByCertNoResponse searchChangeTicketByCertNo(searchChangeTicketByCertNo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("searchChangeTicketByCertNo", parameters);
        }
        searchChangeTicketByCertNoResponse searchchangeticketbycertnoresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof searchChangeTicketByCertNoResponse)) {
                    searchchangeticketbycertnoresponse = (searchChangeTicketByCertNoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    searchchangeticketbycertnoresponse = new searchChangeTicketByCertNoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    searchchangeticketbycertnoresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (searchchangeticketbycertnoresponse != null) {
                return searchchangeticketbycertnoresponse;
            }
            searchChangeTicketByCertNoResponse searchchangeticketbycertnoresponse2 = new searchChangeTicketByCertNoResponse();
            searchchangeticketbycertnoresponse2.setexception(new NullPointerException());
            return searchchangeticketbycertnoresponse2;
        } catch (java.lang.Exception e) {
            searchChangeTicketByCertNoResponse searchchangeticketbycertnoresponse3 = new searchChangeTicketByCertNoResponse();
            searchchangeticketbycertnoresponse3.setexception(e);
            return searchchangeticketbycertnoresponse3;
        }
    }

    public checkTicketsResponse checkTickets(checkTickets parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("checkTickets", parameters);
        }
        checkTicketsResponse checkticketsresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof checkTicketsResponse)) {
                    checkticketsresponse = (checkTicketsResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    checkticketsresponse = new checkTicketsResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    checkticketsresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (checkticketsresponse != null) {
                return checkticketsresponse;
            }
            checkTicketsResponse checkticketsresponse2 = new checkTicketsResponse();
            checkticketsresponse2.setexception(new NullPointerException());
            return checkticketsresponse2;
        } catch (java.lang.Exception e) {
            checkTicketsResponse checkticketsresponse3 = new checkTicketsResponse();
            checkticketsresponse3.setexception(e);
            return checkticketsresponse3;
        }
    }

    public searchChangeTicketByAllResponse searchChangeTicketByAll(searchChangeTicketByAll parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("searchChangeTicketByAll", parameters);
        }
        searchChangeTicketByAllResponse searchchangeticketbyallresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof searchChangeTicketByAllResponse)) {
                    searchchangeticketbyallresponse = (searchChangeTicketByAllResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    searchchangeticketbyallresponse = new searchChangeTicketByAllResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    searchchangeticketbyallresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (searchchangeticketbyallresponse != null) {
                return searchchangeticketbyallresponse;
            }
            searchChangeTicketByAllResponse searchchangeticketbyallresponse2 = new searchChangeTicketByAllResponse();
            searchchangeticketbyallresponse2.setexception(new NullPointerException());
            return searchchangeticketbyallresponse2;
        } catch (java.lang.Exception e) {
            searchChangeTicketByAllResponse searchchangeticketbyallresponse3 = new searchChangeTicketByAllResponse();
            searchchangeticketbyallresponse3.setexception(e);
            return searchchangeticketbyallresponse3;
        }
    }

    public confirmFlightResponse confirmFlight(confirmFlight parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("confirmFlight", parameters);
        }
        confirmFlightResponse confirmflightresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof confirmFlightResponse)) {
                    confirmflightresponse = (confirmFlightResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    confirmflightresponse = new confirmFlightResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    confirmflightresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (confirmflightresponse != null) {
                return confirmflightresponse;
            }
            confirmFlightResponse confirmflightresponse2 = new confirmFlightResponse();
            confirmflightresponse2.setexception(new NullPointerException());
            return confirmflightresponse2;
        } catch (java.lang.Exception e) {
            confirmFlightResponse confirmflightresponse3 = new confirmFlightResponse();
            confirmflightresponse3.setexception(e);
            return confirmflightresponse3;
        }
    }

    public printLogResponse printLog(printLog parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("printLog", parameters);
        }
        printLogResponse printlogresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof printLogResponse)) {
                    printlogresponse = (printLogResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    printlogresponse = new printLogResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    printlogresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (printlogresponse != null) {
                return printlogresponse;
            }
            printLogResponse printlogresponse2 = new printLogResponse();
            printlogresponse2.setexception(new NullPointerException());
            return printlogresponse2;
        } catch (java.lang.Exception e) {
            printLogResponse printlogresponse3 = new printLogResponse();
            printlogresponse3.setexception(e);
            return printlogresponse3;
        }
    }

    public checkCourrentChannelResponse checkCourrentChannel(checkCourrentChannel parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("checkCourrentChannel", parameters);
        }
        checkCourrentChannelResponse checkcourrentchannelresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof checkCourrentChannelResponse)) {
                    checkcourrentchannelresponse = (checkCourrentChannelResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    checkcourrentchannelresponse = new checkCourrentChannelResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    checkcourrentchannelresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (checkcourrentchannelresponse != null) {
                return checkcourrentchannelresponse;
            }
            checkCourrentChannelResponse checkcourrentchannelresponse2 = new checkCourrentChannelResponse();
            checkcourrentchannelresponse2.setexception(new NullPointerException());
            return checkcourrentchannelresponse2;
        } catch (java.lang.Exception e) {
            checkCourrentChannelResponse checkcourrentchannelresponse3 = new checkCourrentChannelResponse();
            checkcourrentchannelresponse3.setexception(e);
            return checkcourrentchannelresponse3;
        }
    }

    public newSearchChangeTicketByCertNoResponse newSearchChangeTicketByCertNo(newSearchChangeTicketByCertNo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("newSearchChangeTicketByCertNo", parameters);
        }
        newSearchChangeTicketByCertNoResponse newsearchchangeticketbycertnoresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof newSearchChangeTicketByCertNoResponse)) {
                    newsearchchangeticketbycertnoresponse = (newSearchChangeTicketByCertNoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    newsearchchangeticketbycertnoresponse = new newSearchChangeTicketByCertNoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    newsearchchangeticketbycertnoresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (newsearchchangeticketbycertnoresponse != null) {
                return newsearchchangeticketbycertnoresponse;
            }
            newSearchChangeTicketByCertNoResponse newsearchchangeticketbycertnoresponse2 = new newSearchChangeTicketByCertNoResponse();
            newsearchchangeticketbycertnoresponse2.setexception(new NullPointerException());
            return newsearchchangeticketbycertnoresponse2;
        } catch (java.lang.Exception e) {
            newSearchChangeTicketByCertNoResponse newsearchchangeticketbycertnoresponse3 = new newSearchChangeTicketByCertNoResponse();
            newsearchchangeticketbycertnoresponse3.setexception(e);
            return newsearchchangeticketbycertnoresponse3;
        }
    }

    public newSearchChangeTicketByAllResponse newSearchChangeTicketByAll(newSearchChangeTicketByAll parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("newSearchChangeTicketByAll", parameters);
        }
        newSearchChangeTicketByAllResponse newsearchchangeticketbyallresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof newSearchChangeTicketByAllResponse)) {
                    newsearchchangeticketbyallresponse = (newSearchChangeTicketByAllResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    newsearchchangeticketbyallresponse = new newSearchChangeTicketByAllResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    newsearchchangeticketbyallresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (newsearchchangeticketbyallresponse != null) {
                return newsearchchangeticketbyallresponse;
            }
            newSearchChangeTicketByAllResponse newsearchchangeticketbyallresponse2 = new newSearchChangeTicketByAllResponse();
            newsearchchangeticketbyallresponse2.setexception(new NullPointerException());
            return newsearchchangeticketbyallresponse2;
        } catch (java.lang.Exception e) {
            newSearchChangeTicketByAllResponse newsearchchangeticketbyallresponse3 = new newSearchChangeTicketByAllResponse();
            newsearchchangeticketbyallresponse3.setexception(e);
            return newsearchchangeticketbyallresponse3;
        }
    }

    public newSearchChangeTicketByTicketNoResponse newSearchChangeTicketByTicketNo(newSearchChangeTicketByTicketNo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("newSearchChangeTicketByTicketNo", parameters);
        }
        newSearchChangeTicketByTicketNoResponse newsearchchangeticketbyticketnoresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof newSearchChangeTicketByTicketNoResponse)) {
                    newsearchchangeticketbyticketnoresponse = (newSearchChangeTicketByTicketNoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    newsearchchangeticketbyticketnoresponse = new newSearchChangeTicketByTicketNoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    newsearchchangeticketbyticketnoresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (newsearchchangeticketbyticketnoresponse != null) {
                return newsearchchangeticketbyticketnoresponse;
            }
            newSearchChangeTicketByTicketNoResponse newsearchchangeticketbyticketnoresponse2 = new newSearchChangeTicketByTicketNoResponse();
            newsearchchangeticketbyticketnoresponse2.setexception(new NullPointerException());
            return newsearchchangeticketbyticketnoresponse2;
        } catch (java.lang.Exception e) {
            newSearchChangeTicketByTicketNoResponse newsearchchangeticketbyticketnoresponse3 = new newSearchChangeTicketByTicketNoResponse();
            newsearchchangeticketbyticketnoresponse3.setexception(e);
            return newsearchchangeticketbyticketnoresponse3;
        }
    }

    public searchChangeRefundTicketByCertNoResponse searchChangeRefundTicketByCertNo(searchChangeRefundTicketByCertNo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("searchChangeRefundTicketByCertNo", parameters);
        }
        searchChangeRefundTicketByCertNoResponse searchchangerefundticketbycertnoresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof searchChangeRefundTicketByCertNoResponse)) {
                    searchchangerefundticketbycertnoresponse = (searchChangeRefundTicketByCertNoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    searchchangerefundticketbycertnoresponse = new searchChangeRefundTicketByCertNoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    searchchangerefundticketbycertnoresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (searchchangerefundticketbycertnoresponse != null) {
                return searchchangerefundticketbycertnoresponse;
            }
            searchChangeRefundTicketByCertNoResponse searchchangerefundticketbycertnoresponse2 = new searchChangeRefundTicketByCertNoResponse();
            searchchangerefundticketbycertnoresponse2.setexception(new NullPointerException());
            return searchchangerefundticketbycertnoresponse2;
        } catch (java.lang.Exception e) {
            searchChangeRefundTicketByCertNoResponse searchchangerefundticketbycertnoresponse3 = new searchChangeRefundTicketByCertNoResponse();
            searchchangerefundticketbycertnoresponse3.setexception(e);
            return searchchangerefundticketbycertnoresponse3;
        }
    }

    public searchChangedRefundedTicketByCertNoResponse searchChangedRefundedTicketByCertNo(searchChangedRefundedTicketByCertNo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("searchChangedRefundedTicketByCertNo", parameters);
        }
        searchChangedRefundedTicketByCertNoResponse searchchangedrefundedticketbycertnoresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof searchChangedRefundedTicketByCertNoResponse)) {
                    searchchangedrefundedticketbycertnoresponse = (searchChangedRefundedTicketByCertNoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    searchchangedrefundedticketbycertnoresponse = new searchChangedRefundedTicketByCertNoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    searchchangedrefundedticketbycertnoresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (searchchangedrefundedticketbycertnoresponse != null) {
                return searchchangedrefundedticketbycertnoresponse;
            }
            searchChangedRefundedTicketByCertNoResponse searchchangedrefundedticketbycertnoresponse2 = new searchChangedRefundedTicketByCertNoResponse();
            searchchangedrefundedticketbycertnoresponse2.setexception(new NullPointerException());
            return searchchangedrefundedticketbycertnoresponse2;
        } catch (java.lang.Exception e) {
            searchChangedRefundedTicketByCertNoResponse searchchangedrefundedticketbycertnoresponse3 = new searchChangedRefundedTicketByCertNoResponse();
            searchchangedrefundedticketbycertnoresponse3.setexception(e);
            return searchchangedrefundedticketbycertnoresponse3;
        }
    }

    public checkAllChannelResponse checkAllChannel(checkAllChannel parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("checkAllChannel", parameters);
        }
        checkAllChannelResponse checkallchannelresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof checkAllChannelResponse)) {
                    checkallchannelresponse = (checkAllChannelResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    checkallchannelresponse = new checkAllChannelResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    checkallchannelresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (checkallchannelresponse != null) {
                return checkallchannelresponse;
            }
            checkAllChannelResponse checkallchannelresponse2 = new checkAllChannelResponse();
            checkallchannelresponse2.setexception(new NullPointerException());
            return checkallchannelresponse2;
        } catch (java.lang.Exception e) {
            checkAllChannelResponse checkallchannelresponse3 = new checkAllChannelResponse();
            checkallchannelresponse3.setexception(e);
            return checkallchannelresponse3;
        }
    }
}