package com.common.szair.model.changedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class checkCourrentChannelConditionVO extends baseDTOVO implements SOAPObject {
    public babyInfoVO _BABY_INFO = null;
    public String _CLASS_CODE = null;
    public changeFlightInfo _FLIGHT_INFO = null;
    public String _PASS_TYPE = null;
    public String _PSDID_NO = null;
    public String _PSG_NAME = null;
    public String _TICKET_PRICE = null;
    public String _TKT_NO = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/orderChangeMerge";
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._BABY_INFO != null) {
            xml.startTag(null, "BABY_INFO");
            this._BABY_INFO.addElementsToNode(xml);
            xml.endTag(null, "BABY_INFO");
        }
        if (this._CLASS_CODE != null) {
            xml.startTag(null, "CLASS_CODE");
            xml.text(this._CLASS_CODE);
            xml.endTag(null, "CLASS_CODE");
        }
        if (this._FLIGHT_INFO != null) {
            xml.startTag(null, "FLIGHT_INFO");
            this._FLIGHT_INFO.addElementsToNode(xml);
            xml.endTag(null, "FLIGHT_INFO");
        }
        if (this._PASS_TYPE != null) {
            xml.startTag(null, "PASS_TYPE");
            xml.text(this._PASS_TYPE);
            xml.endTag(null, "PASS_TYPE");
        }
        if (this._PSDID_NO != null) {
            xml.startTag(null, "PSDID_NO");
            xml.text(this._PSDID_NO);
            xml.endTag(null, "PSDID_NO");
        }
        if (this._PSG_NAME != null) {
            xml.startTag(null, "PSG_NAME");
            xml.text(this._PSG_NAME);
            xml.endTag(null, "PSG_NAME");
        }
        if (this._TICKET_PRICE != null) {
            xml.startTag(null, "TICKET_PRICE");
            xml.text(this._TICKET_PRICE);
            xml.endTag(null, "TICKET_PRICE");
        }
        if (this._TKT_NO != null) {
            xml.startTag(null, "TKT_NO");
            xml.text(this._TKT_NO);
            xml.endTag(null, "TKT_NO");
        }
    }

    @Override // com.common.szair.model.changedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("BABY_INFO".equals(parser.getName())) {
                        babyInfoVO babyinfovo = new babyInfoVO();
                        babyinfovo.parse(binding, parser);
                        this._BABY_INFO = babyinfovo;
                    } else if ("CLASS_CODE".equals(parser.getName())) {
                        this._CLASS_CODE = parser.nextText();
                    } else if ("FLIGHT_INFO".equals(parser.getName())) {
                        changeFlightInfo changeflightinfo = new changeFlightInfo();
                        changeflightinfo.parse(binding, parser);
                        this._FLIGHT_INFO = changeflightinfo;
                    } else if ("PASS_TYPE".equals(parser.getName())) {
                        this._PASS_TYPE = parser.nextText();
                    } else if ("PSDID_NO".equals(parser.getName())) {
                        this._PSDID_NO = parser.nextText();
                    } else if ("PSG_NAME".equals(parser.getName())) {
                        this._PSG_NAME = parser.nextText();
                    } else if ("TICKET_PRICE".equals(parser.getName())) {
                        this._TICKET_PRICE = parser.nextText();
                    } else if ("TKT_NO".equals(parser.getName())) {
                        this._TKT_NO = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}