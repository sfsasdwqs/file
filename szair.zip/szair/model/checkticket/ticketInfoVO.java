package com.common.szair.model.checkticket;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class ticketInfoVO extends bookingResponseBaseVO implements SOAPObject, Serializable {
    public String _CABIN = null;
    public String _DST_CITY = null;
    public String _FLIGHT_DATE = null;
    public String _FLIGHT_NO = null;
    public String _MID_CITY = null;
    public String _ORG_CITY = null;
    public String _PLANE_STYLE = null;
    public String _SEAT_NO = null;
    public String _ARR_TIME = null;
    public String _DEP_TIME = null;
    public String _TICKET_STATUS = null;
    public String _OP_RESULT = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/booking";
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CABIN != null) {
            xml.startTag(null, "CABIN");
            xml.text(this._CABIN);
            xml.endTag(null, "CABIN");
        }
        if (this._DST_CITY != null) {
            xml.startTag(null, "DST_CITY");
            xml.text(this._DST_CITY);
            xml.endTag(null, "DST_CITY");
        }
        if (this._FLIGHT_DATE != null) {
            xml.startTag(null, "FLIGHT_DATE");
            xml.text(this._FLIGHT_DATE);
            xml.endTag(null, "FLIGHT_DATE");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._MID_CITY != null) {
            xml.startTag(null, "MID_CITY");
            xml.text(this._MID_CITY);
            xml.endTag(null, "MID_CITY");
        }
        if (this._ORG_CITY != null) {
            xml.startTag(null, "ORG_CITY");
            xml.text(this._ORG_CITY);
            xml.endTag(null, "ORG_CITY");
        }
        if (this._PLANE_STYLE != null) {
            xml.startTag(null, "PLANE_STYLE");
            xml.text(this._PLANE_STYLE);
            xml.endTag(null, "PLANE_STYLE");
        }
        if (this._SEAT_NO != null) {
            xml.startTag(null, "SEAT_NO");
            xml.text(this._SEAT_NO);
            xml.endTag(null, "SEAT_NO");
        }
        if (this._ARR_TIME != null) {
            xml.startTag(null, "ARR_TIME");
            xml.text(this._ARR_TIME);
            xml.endTag(null, "ARR_TIME");
        }
        if (this._DEP_TIME != null) {
            xml.startTag(null, "DEP_TIME");
            xml.text(this._DEP_TIME);
            xml.endTag(null, "DEP_TIME");
        }
        if (this._TICKET_STATUS != null) {
            xml.startTag(null, "TICKET_STATUS");
            xml.text(this._TICKET_STATUS);
            xml.endTag(null, "TICKET_STATUS");
        }
        if (this._OP_RESULT != null) {
            xml.startTag(null, "OP_RESULT");
            xml.text(this._OP_RESULT);
            xml.endTag(null, "OP_RESULT");
        }
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CABIN".equals(parser.getName())) {
                        this._CABIN = parser.nextText();
                    } else if ("DST_CITY".equals(parser.getName())) {
                        this._DST_CITY = parser.nextText();
                    } else if ("FLIGHT_DATE".equals(parser.getName())) {
                        this._FLIGHT_DATE = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("MID_CITY".equals(parser.getName())) {
                        this._MID_CITY = parser.nextText();
                    } else if ("ORG_CITY".equals(parser.getName())) {
                        this._ORG_CITY = parser.nextText();
                    } else if ("PLANE_STYLE".equals(parser.getName())) {
                        this._PLANE_STYLE = parser.nextText();
                    } else if ("SEAT_NO".equals(parser.getName())) {
                        this._SEAT_NO = parser.nextText();
                    } else if ("ARR_TIME".equals(parser.getName())) {
                        this._ARR_TIME = parser.nextText();
                    } else if ("DEP_TIME".equals(parser.getName())) {
                        this._DEP_TIME = parser.nextText();
                    } else if ("TICKET_STATUS".equals(parser.getName())) {
                        this._TICKET_STATUS = parser.nextText();
                    } else if ("OP_RESULT".equals(parser.getName())) {
                        this._OP_RESULT = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}