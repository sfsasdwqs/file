package com.common.szair.model.checkticket;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class CheckTicketWebServiceServiceSoapBinding extends SOAPBinding {
    public CheckTicketWebServiceServiceSoapBinding(String endpoint) {
        super(CheckTicketWebServiceServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns3", "http://impl.webservice.checkticket.shenzhenair.com/");
        hashMap.put("ns4", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns2", "http://com/shenzhenair/mobilewebservice/booking");
        hashMap.put("ns1", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns0", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        return hashMap;
    }

    public checkTicketResponse checkTicket(checkTicket parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("checkTicket", parameters);
        }
        checkTicketResponse checkticketresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof checkTicketResponse)) {
                    checkticketresponse = (checkTicketResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    checkticketresponse = new checkTicketResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    checkticketresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (checkticketresponse != null) {
                return checkticketresponse;
            }
            checkTicketResponse checkticketresponse2 = new checkTicketResponse();
            checkticketresponse2.setexception(new NullPointerException());
            return checkticketresponse2;
        } catch (Exception e) {
            checkTicketResponse checkticketresponse3 = new checkTicketResponse();
            checkticketresponse3.setexception(e);
            return checkticketresponse3;
        }
    }

    public ticketCheckNewResponse ticketCheckNew(ticketCheckNew parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("ticketCheckNew", parameters);
        }
        ticketCheckNewResponse ticketchecknewresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof ticketCheckNewResponse)) {
                    ticketchecknewresponse = (ticketCheckNewResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    ticketchecknewresponse = new ticketCheckNewResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    ticketchecknewresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (ticketchecknewresponse != null) {
                return ticketchecknewresponse;
            }
            ticketCheckNewResponse ticketchecknewresponse2 = new ticketCheckNewResponse();
            ticketchecknewresponse2.setexception(new NullPointerException());
            return ticketchecknewresponse2;
        } catch (Exception e) {
            ticketCheckNewResponse ticketchecknewresponse3 = new ticketCheckNewResponse();
            ticketchecknewresponse3.setexception(e);
            return ticketchecknewresponse3;
        }
    }
}