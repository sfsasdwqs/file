package com.common.szair.model.checkticket;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class ticketCheckNewResultVO extends bookingResponseBaseVO implements SOAPObject, Serializable {
    public String _AIRPORT_DUTY = null;
    public String _COMPANY_CODE = null;
    public String _CURRENCY_TYPE = null;
    public String _DK_NAME = null;
    public String _FARE = null;
    public String _FLAG = null;
    public String _ID_NO = null;
    public String _ID_TYPE = null;
    public String _INSURANCE_COUNT = null;
    public String _MESSAGE = null;
    public String _NOW_DATE = null;
    public String _OIL_TAX = null;
    public String _PASSENRGER_ID = null;
    public String _PASSENGER_ID_TYPE = null;
    public String _PHONE_NO = null;
    public String _PREMIUM = null;
    public Boolean _IS_PRINT = null;
    public String _PSER_NAME = null;
    public String _PSGR_NAME = null;
    public String _PSGR_TYPE = null;
    public String _TAX = null;
    public String _TICKET_NO = null;
    public List<ticketInfoVO> _LIST_TICKETS = null;
    public String _TOTAL_AMOUNT = null;
    public String _TOTAL_PREMIUM = null;
    public String _TOTAL_REPAY = null;
    public String _OP_RESULT = null;
    public String _FARE_TEXT = null;
    public String _OIL_TAX_TEXT = null;
    public String _AIRPORT_DUTY_TEXT = null;
    public String _TAX_TEXT = null;
    public String _PREMIUM_TEXT = null;
    public String _TOTAL_TEXT = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/booking";
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._AIRPORT_DUTY != null) {
            xml.startTag(null, "AIRPORT_DUTY");
            xml.text(this._AIRPORT_DUTY);
            xml.endTag(null, "AIRPORT_DUTY");
        }
        if (this._COMPANY_CODE != null) {
            xml.startTag(null, "COMPANY_CODE");
            xml.text(this._COMPANY_CODE);
            xml.endTag(null, "COMPANY_CODE");
        }
        if (this._CURRENCY_TYPE != null) {
            xml.startTag(null, "CURRENCY_TYPE");
            xml.text(this._CURRENCY_TYPE);
            xml.endTag(null, "CURRENCY_TYPE");
        }
        if (this._DK_NAME != null) {
            xml.startTag(null, "DK_NAME");
            xml.text(this._DK_NAME);
            xml.endTag(null, "DK_NAME");
        }
        if (this._FARE != null) {
            xml.startTag(null, "FARE");
            xml.text(this._FARE);
            xml.endTag(null, "FARE");
        }
        if (this._FLAG != null) {
            xml.startTag(null, "FLAG");
            xml.text(this._FLAG);
            xml.endTag(null, "FLAG");
        }
        if (this._ID_NO != null) {
            xml.startTag(null, "ID_NO");
            xml.text(this._ID_NO);
            xml.endTag(null, "ID_NO");
        }
        if (this._ID_TYPE != null) {
            xml.startTag(null, "ID_TYPE");
            xml.text(this._ID_TYPE);
            xml.endTag(null, "ID_TYPE");
        }
        if (this._INSURANCE_COUNT != null) {
            xml.startTag(null, "INSURANCE_COUNT");
            xml.text(this._INSURANCE_COUNT);
            xml.endTag(null, "INSURANCE_COUNT");
        }
        if (this._MESSAGE != null) {
            xml.startTag(null, "MESSAGE");
            xml.text(this._MESSAGE);
            xml.endTag(null, "MESSAGE");
        }
        if (this._NOW_DATE != null) {
            xml.startTag(null, "NOW_DATE");
            xml.text(this._NOW_DATE);
            xml.endTag(null, "NOW_DATE");
        }
        if (this._OIL_TAX != null) {
            xml.startTag(null, "OIL_TAX");
            xml.text(this._OIL_TAX);
            xml.endTag(null, "OIL_TAX");
        }
        if (this._PASSENRGER_ID != null) {
            xml.startTag(null, "PASSENRGER_ID");
            xml.text(this._PASSENRGER_ID);
            xml.endTag(null, "PASSENRGER_ID");
        }
        if (this._PASSENGER_ID_TYPE != null) {
            xml.startTag(null, "PASSENGER_ID_TYPE");
            xml.text(this._PASSENGER_ID_TYPE);
            xml.endTag(null, "PASSENGER_ID_TYPE");
        }
        if (this._PHONE_NO != null) {
            xml.startTag(null, "PHONE_NO");
            xml.text(this._PHONE_NO);
            xml.endTag(null, "PHONE_NO");
        }
        if (this._PREMIUM != null) {
            xml.startTag(null, "PREMIUM");
            xml.text(this._PREMIUM);
            xml.endTag(null, "PREMIUM");
        }
        if (this._IS_PRINT != null) {
            xml.startTag(null, "IS_PRINT");
            xml.text(String.valueOf(this._IS_PRINT));
            xml.endTag(null, "IS_PRINT");
        }
        if (this._PSER_NAME != null) {
            xml.startTag(null, "PSER_NAME");
            xml.text(this._PSER_NAME);
            xml.endTag(null, "PSER_NAME");
        }
        if (this._PSGR_NAME != null) {
            xml.startTag(null, "PSGR_NAME");
            xml.text(this._PSGR_NAME);
            xml.endTag(null, "PSGR_NAME");
        }
        if (this._PSGR_TYPE != null) {
            xml.startTag(null, "PSGR_TYPE");
            xml.text(this._PSGR_TYPE);
            xml.endTag(null, "PSGR_TYPE");
        }
        if (this._TAX != null) {
            xml.startTag(null, "TAX");
            xml.text(this._TAX);
            xml.endTag(null, "TAX");
        }
        if (this._TICKET_NO != null) {
            xml.startTag(null, "TICKET_NO");
            xml.text(this._TICKET_NO);
            xml.endTag(null, "TICKET_NO");
        }
        List<ticketInfoVO> list = this._LIST_TICKETS;
        if (list != null && list.size() > 0) {
            int size = this._LIST_TICKETS.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "LIST_TICKETS");
                this._LIST_TICKETS.get(i).addElementsToNode(xml);
                xml.endTag(null, "LIST_TICKETS");
            }
        }
        if (this._TOTAL_AMOUNT != null) {
            xml.startTag(null, "TOTAL_AMOUNT");
            xml.text(this._TOTAL_AMOUNT);
            xml.endTag(null, "TOTAL_AMOUNT");
        }
        if (this._TOTAL_PREMIUM != null) {
            xml.startTag(null, "TOTAL_PREMIUM");
            xml.text(this._TOTAL_PREMIUM);
            xml.endTag(null, "TOTAL_PREMIUM");
        }
        if (this._TOTAL_REPAY != null) {
            xml.startTag(null, "TOTAL_REPAY");
            xml.text(this._TOTAL_REPAY);
            xml.endTag(null, "TOTAL_REPAY");
        }
        if (this._OP_RESULT != null) {
            xml.startTag(null, "OP_RESULT");
            xml.text(this._OP_RESULT);
            xml.endTag(null, "OP_RESULT");
        }
        if (this._FARE_TEXT != null) {
            xml.startTag(null, "FARE_TEXT");
            xml.text(this._FARE_TEXT);
            xml.endTag(null, "FARE_TEXT");
        }
        if (this._TAX_TEXT != null) {
            xml.startTag(null, "TAX_TEXT");
            xml.text(this._TAX_TEXT);
            xml.endTag(null, "TAX_TEXT");
        }
        if (this._PREMIUM_TEXT != null) {
            xml.startTag(null, "PREMIUM_TEXT");
            xml.text(this._PREMIUM_TEXT);
            xml.endTag(null, "PREMIUM_TEXT");
        }
        if (this._TOTAL_TEXT != null) {
            xml.startTag(null, "TOTAL_TEXT");
            xml.text(this._TOTAL_TEXT);
            xml.endTag(null, "TOTAL_TEXT");
        }
        if (this._OIL_TAX_TEXT != null) {
            xml.startTag(null, "OIL_TAX_TEXT");
            xml.text(this._OIL_TAX_TEXT);
            xml.endTag(null, "OIL_TAX_TEXT");
        }
        if (this._AIRPORT_DUTY_TEXT != null) {
            xml.startTag(null, "AIRPORT_DUTY_TEXT");
            xml.text(this._AIRPORT_DUTY_TEXT);
            xml.endTag(null, "AIRPORT_DUTY_TEXT");
        }
    }

    @Override // com.common.szair.model.checkticket.bookingResponseBaseVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("AIRPORT_DUTY".equals(parser.getName())) {
                        this._AIRPORT_DUTY = parser.nextText();
                    } else if ("COMPANY_CODE".equals(parser.getName())) {
                        this._COMPANY_CODE = parser.nextText();
                    } else if ("CURRENCY_TYPE".equals(parser.getName())) {
                        this._CURRENCY_TYPE = parser.nextText();
                    } else if ("DK_NAME".equals(parser.getName())) {
                        this._DK_NAME = parser.nextText();
                    } else if ("FARE".equals(parser.getName())) {
                        this._FARE = parser.nextText();
                    } else if ("FLAG".equals(parser.getName())) {
                        this._FLAG = parser.nextText();
                    } else if ("ID_NO".equals(parser.getName())) {
                        this._ID_NO = parser.nextText();
                    } else if ("ID_TYPE".equals(parser.getName())) {
                        this._ID_TYPE = parser.nextText();
                    } else if ("INSURANCE_COUNT".equals(parser.getName())) {
                        this._INSURANCE_COUNT = parser.nextText();
                    } else if ("MESSAGE".equals(parser.getName())) {
                        this._MESSAGE = parser.nextText();
                    } else if ("NOW_DATE".equals(parser.getName())) {
                        this._NOW_DATE = parser.nextText();
                    } else if ("OIL_TAX".equals(parser.getName())) {
                        this._OIL_TAX = parser.nextText();
                    } else if ("PASSENRGER_ID".equals(parser.getName())) {
                        this._PASSENRGER_ID = parser.nextText();
                    } else if ("PASSENGER_ID_TYPE".equals(parser.getName())) {
                        this._PASSENGER_ID_TYPE = parser.nextText();
                    } else if ("PHONE_NO".equals(parser.getName())) {
                        this._PHONE_NO = parser.nextText();
                    } else if ("PREMIUM".equals(parser.getName())) {
                        this._PREMIUM = parser.nextText();
                    } else if ("IS_PRINT".equals(parser.getName())) {
                        this._IS_PRINT = Boolean.valueOf(parser.nextText());
                    } else if ("PSER_NAME".equals(parser.getName())) {
                        this._PSER_NAME = parser.nextText();
                    } else if ("PSGR_NAME".equals(parser.getName())) {
                        this._PSGR_NAME = parser.nextText();
                    } else if ("PSGR_TYPE".equals(parser.getName())) {
                        this._PSGR_TYPE = parser.nextText();
                    } else if ("TAX".equals(parser.getName())) {
                        this._TAX = parser.nextText();
                    } else if ("TICKET_NO".equals(parser.getName())) {
                        this._TICKET_NO = parser.nextText();
                    } else if ("LIST_TICKETS".equals(parser.getName())) {
                        if (this._LIST_TICKETS == null) {
                            this._LIST_TICKETS = new ArrayList();
                        }
                        ticketInfoVO ticketinfovo = new ticketInfoVO();
                        ticketinfovo.parse(binding, parser);
                        this._LIST_TICKETS.add(ticketinfovo);
                    } else if ("TOTAL_AMOUNT".equals(parser.getName())) {
                        this._TOTAL_AMOUNT = parser.nextText();
                    } else if ("TOTAL_PREMIUM".equals(parser.getName())) {
                        this._TOTAL_PREMIUM = parser.nextText();
                    } else if ("TOTAL_REPAY".equals(parser.getName())) {
                        this._TOTAL_REPAY = parser.nextText();
                    } else if ("OP_RESULT".equals(parser.getName())) {
                        this._OP_RESULT = parser.nextText();
                    } else if ("FARE_TEXT".equals(parser.getName())) {
                        this._FARE_TEXT = parser.nextText();
                    } else if ("TAX_TEXT".equals(parser.getName())) {
                        this._TAX_TEXT = parser.nextText();
                    } else if ("PREMIUM_TEXT".equals(parser.getName())) {
                        this._PREMIUM_TEXT = parser.nextText();
                    } else if ("TOTAL_TEXT".equals(parser.getName())) {
                        this._TOTAL_TEXT = parser.nextText();
                    } else if ("OIL_TAX_TEXT".equals(parser.getName())) {
                        this._OIL_TAX_TEXT = parser.nextText();
                    } else if ("AIRPORT_DUTY_TEXT".equals(parser.getName())) {
                        this._AIRPORT_DUTY_TEXT = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}