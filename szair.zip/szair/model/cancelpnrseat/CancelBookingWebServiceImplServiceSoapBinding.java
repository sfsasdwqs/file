package com.common.szair.model.cancelpnrseat;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class CancelBookingWebServiceImplServiceSoapBinding extends SOAPBinding {
    public CancelBookingWebServiceImplServiceSoapBinding(String endpoint) {
        super(CancelBookingWebServiceImplServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns2", "http://com/shenzhenair/mobilewebservice/cancel/booking");
        hashMap.put("ns4", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns1", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns0", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        hashMap.put("ns3", "http://impl.webservice.cancelBooking.shenzhenair.com/");
        return hashMap;
    }

    public cancelTicketResponse cancelTicket(cancelTicket parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("cancelTicket", parameters);
        }
        cancelTicketResponse cancelticketresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof cancelTicketResponse)) {
                    cancelticketresponse = (cancelTicketResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    cancelticketresponse = new cancelTicketResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    cancelticketresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (cancelticketresponse != null) {
                return cancelticketresponse;
            }
            cancelTicketResponse cancelticketresponse2 = new cancelTicketResponse();
            cancelticketresponse2.setexception(new NullPointerException());
            return cancelticketresponse2;
        } catch (Exception e) {
            cancelTicketResponse cancelticketresponse3 = new cancelTicketResponse();
            cancelticketresponse3.setexception(e);
            return cancelticketresponse3;
        }
    }

    public tripDetailResponse tripDetail(tripDetail parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("tripDetail", parameters);
        }
        tripDetailResponse tripdetailresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof tripDetailResponse)) {
                    tripdetailresponse = (tripDetailResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    tripdetailresponse = new tripDetailResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    tripdetailresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (tripdetailresponse != null) {
                return tripdetailresponse;
            }
            tripDetailResponse tripdetailresponse2 = new tripDetailResponse();
            tripdetailresponse2.setexception(new NullPointerException());
            return tripdetailresponse2;
        } catch (Exception e) {
            tripDetailResponse tripdetailresponse3 = new tripDetailResponse();
            tripdetailresponse3.setexception(e);
            return tripdetailresponse3;
        }
    }

    public queryTripResponse queryTrip(queryTrip parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryTrip", parameters);
        }
        queryTripResponse querytripresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryTripResponse)) {
                    querytripresponse = (queryTripResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querytripresponse = new queryTripResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querytripresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querytripresponse != null) {
                return querytripresponse;
            }
            queryTripResponse querytripresponse2 = new queryTripResponse();
            querytripresponse2.setexception(new NullPointerException());
            return querytripresponse2;
        } catch (Exception e) {
            queryTripResponse querytripresponse3 = new queryTripResponse();
            querytripresponse3.setexception(e);
            return querytripresponse3;
        }
    }

    public queryOrderResponse queryOrder(queryOrder parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryOrder", parameters);
        }
        queryOrderResponse queryorderresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryOrderResponse)) {
                    queryorderresponse = (queryOrderResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    queryorderresponse = new queryOrderResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    queryorderresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (queryorderresponse != null) {
                return queryorderresponse;
            }
            queryOrderResponse queryorderresponse2 = new queryOrderResponse();
            queryorderresponse2.setexception(new NullPointerException());
            return queryorderresponse2;
        } catch (Exception e) {
            queryOrderResponse queryorderresponse3 = new queryOrderResponse();
            queryorderresponse3.setexception(e);
            return queryorderresponse3;
        }
    }

    public sendCaptchaResponse sendCaptcha(sendCaptcha parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("sendCaptcha", parameters);
        }
        sendCaptchaResponse sendcaptcharesponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof sendCaptchaResponse)) {
                    sendcaptcharesponse = (sendCaptchaResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    sendcaptcharesponse = new sendCaptchaResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    sendcaptcharesponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (sendcaptcharesponse != null) {
                return sendcaptcharesponse;
            }
            sendCaptchaResponse sendcaptcharesponse2 = new sendCaptchaResponse();
            sendcaptcharesponse2.setexception(new NullPointerException());
            return sendcaptcharesponse2;
        } catch (Exception e) {
            sendCaptchaResponse sendcaptcharesponse3 = new sendCaptchaResponse();
            sendcaptcharesponse3.setexception(e);
            return sendcaptcharesponse3;
        }
    }

    public checkCertNoResponse checkCertNo(checkCertNo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("checkCertNo", parameters);
        }
        checkCertNoResponse checkcertnoresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof checkCertNoResponse)) {
                    checkcertnoresponse = (checkCertNoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    checkcertnoresponse = new checkCertNoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    checkcertnoresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (checkcertnoresponse != null) {
                return checkcertnoresponse;
            }
            checkCertNoResponse checkcertnoresponse2 = new checkCertNoResponse();
            checkcertnoresponse2.setexception(new NullPointerException());
            return checkcertnoresponse2;
        } catch (Exception e) {
            checkCertNoResponse checkcertnoresponse3 = new checkCertNoResponse();
            checkcertnoresponse3.setexception(e);
            return checkcertnoresponse3;
        }
    }
}