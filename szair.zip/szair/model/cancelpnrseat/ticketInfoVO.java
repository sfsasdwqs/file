package com.common.szair.model.cancelpnrseat;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class ticketInfoVO implements SOAPObject, Serializable {
    public ticketInfoVO baby;
    public boolean isHasLastThree;
    public boolean isSelect;
    public boolean needLastThree;
    public String _BUNDLE_TICKET_NO = null;
    public String _CERT_NO = null;
    public String _CERT_TYPE = null;
    public String _LAST_THREE = null;
    public Boolean _ONESELF = null;
    public String _PASSENGER_NAME = null;
    public String _PASSENGER_TYPE = null;
    public String _TICKET_NO = null;
    public String _TICKET_PERIOD = null;
    public String PSGR_ID = null;
    public String PNR = null;
    public String CANCEL_TRIP_RESULT = null;
    public String _CERT_NO_CHECK = null;
    public String _MOBILE_CHECK = null;
    public String ORG_CITY = null;
    public String DST_CITY = null;
    public String CLASS_CODE = null;
    public String TICKET_STATUS = null;
    public boolean isEnable = true;
    public String lastOne = null;
    public String lastTwo = null;
    public String lastThree = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/cancel/booking";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._BUNDLE_TICKET_NO != null) {
            xml.startTag(null, "BUNDLE_TICKET_NO");
            xml.text(this._BUNDLE_TICKET_NO);
            xml.endTag(null, "BUNDLE_TICKET_NO");
        }
        if (this._CERT_NO != null) {
            xml.startTag(null, "CERT_NO");
            xml.text(this._CERT_NO);
            xml.endTag(null, "CERT_NO");
        }
        if (this._CERT_TYPE != null) {
            xml.startTag(null, "CERT_TYPE");
            xml.text(this._CERT_TYPE);
            xml.endTag(null, "CERT_TYPE");
        }
        if (this._LAST_THREE != null) {
            xml.startTag(null, "LAST_THREE");
            xml.text(this._LAST_THREE);
            xml.endTag(null, "LAST_THREE");
        }
        if (this._ONESELF != null) {
            xml.startTag(null, "ONESELF");
            xml.text(String.valueOf(this._ONESELF));
            xml.endTag(null, "ONESELF");
        }
        if (this._PASSENGER_NAME != null) {
            xml.startTag(null, "PASSENGER_NAME");
            xml.text(this._PASSENGER_NAME);
            xml.endTag(null, "PASSENGER_NAME");
        }
        if (this._PASSENGER_TYPE != null) {
            xml.startTag(null, "PASSENGER_TYPE");
            xml.text(this._PASSENGER_TYPE);
            xml.endTag(null, "PASSENGER_TYPE");
        }
        if (this._TICKET_NO != null) {
            xml.startTag(null, "TICKET_NO");
            xml.text(this._TICKET_NO);
            xml.endTag(null, "TICKET_NO");
        }
        if (this._TICKET_PERIOD != null) {
            xml.startTag(null, "TICKET_PERIOD");
            xml.text(this._TICKET_PERIOD);
            xml.endTag(null, "TICKET_PERIOD");
        }
        if (this.PSGR_ID != null) {
            xml.startTag(null, "PSGR_ID");
            xml.text(this.PSGR_ID);
            xml.endTag(null, "PSGR_ID");
        }
        if (this.PNR != null) {
            xml.startTag(null, "PNR");
            xml.text(this.PNR);
            xml.endTag(null, "PNR");
        }
        if (this.CANCEL_TRIP_RESULT != null) {
            xml.startTag(null, "CANCEL_TRIP_RESULT");
            xml.text(this.CANCEL_TRIP_RESULT);
            xml.endTag(null, "CANCEL_TRIP_RESULT");
        }
        if (this._CERT_NO_CHECK != null) {
            xml.startTag(null, "CERT_NO_CHECK");
            xml.text(this._CERT_NO_CHECK);
            xml.endTag(null, "CERT_NO_CHECK");
        }
        if (this._MOBILE_CHECK != null) {
            xml.startTag(null, "MOBILE_CHECK");
            xml.text(this._MOBILE_CHECK);
            xml.endTag(null, "MOBILE_CHECK");
        }
        if (this.ORG_CITY != null) {
            xml.startTag(null, "ORG_CITY");
            xml.text(this.ORG_CITY);
            xml.endTag(null, "ORG_CITY");
        }
        if (this.DST_CITY != null) {
            xml.startTag(null, "DST_CITY");
            xml.text(this.DST_CITY);
            xml.endTag(null, "DST_CITY");
        }
        if (this.TICKET_STATUS != null) {
            xml.startTag(null, "TICKET_STATUS");
            xml.text(this.TICKET_STATUS);
            xml.endTag(null, "TICKET_STATUS");
        }
        if (this.CLASS_CODE != null) {
            xml.startTag(null, "CLASS_CODE");
            xml.text(this.CLASS_CODE);
            xml.endTag(null, "CLASS_CODE");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("BUNDLE_TICKET_NO".equals(parser.getName())) {
                        this._BUNDLE_TICKET_NO = parser.nextText();
                    } else if ("CERT_NO".equals(parser.getName())) {
                        this._CERT_NO = parser.nextText();
                    } else if ("CERT_TYPE".equals(parser.getName())) {
                        this._CERT_TYPE = parser.nextText();
                    } else if ("LAST_THREE".equals(parser.getName())) {
                        this._LAST_THREE = parser.nextText();
                    } else if ("ONESELF".equals(parser.getName())) {
                        this._ONESELF = Boolean.valueOf(parser.nextText());
                    } else if ("PASSENGER_NAME".equals(parser.getName())) {
                        this._PASSENGER_NAME = parser.nextText();
                    } else if ("PASSENGER_TYPE".equals(parser.getName())) {
                        this._PASSENGER_TYPE = parser.nextText();
                    } else if ("TICKET_NO".equals(parser.getName())) {
                        this._TICKET_NO = parser.nextText();
                    } else if ("TICKET_PERIOD".equals(parser.getName())) {
                        this._TICKET_PERIOD = parser.nextText();
                    } else if ("PSGR_ID".equals(parser.getName())) {
                        this.PSGR_ID = parser.nextText();
                    } else if ("PNR".equals(parser.getName())) {
                        this.PNR = parser.nextText();
                    } else if ("CANCEL_TRIP_RESULT".equals(parser.getName())) {
                        this.CANCEL_TRIP_RESULT = parser.nextText();
                    } else if ("CERT_NO_CHECK".equals(parser.getName())) {
                        this._CERT_NO_CHECK = parser.nextText();
                    } else if ("MOBILE_CHECK".equals(parser.getName())) {
                        this._MOBILE_CHECK = parser.nextText();
                    } else if ("ORG_CITY".equals(parser.getName())) {
                        this.ORG_CITY = parser.nextText();
                    } else if ("DST_CITY".equals(parser.getName())) {
                        this.DST_CITY = parser.nextText();
                    } else if ("TICKET_STATUS".equals(parser.getName())) {
                        this.TICKET_STATUS = parser.nextText();
                    } else if ("CLASS_CODE".equals(parser.getName())) {
                        this.CLASS_CODE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}