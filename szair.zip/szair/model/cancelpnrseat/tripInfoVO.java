package com.common.szair.model.cancelpnrseat;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class tripInfoVO implements SOAPObject, Serializable {
    public boolean isSelect;
    public String _ACTUAL_FLIGHT_NO = null;
    public String _AFTER_HOURS_REFUND = null;
    public String _AFTER_HOURS_RESCHEDULE = null;
    public String _ARRIVAL_DATE = null;
    public String _ARRIVAL_TIME = null;
    public String _BEFORE_DAYS_REFUND = null;
    public String _BEFORE_DAYS_RESCHEDULE = null;
    public String _BEFORE_HOURS_REFUND = null;
    public String _BEFORE_HOURS_RESCHEDULE = null;
    public String _BEFORE_WEEK_REFUND = null;
    public String _BEFORE_WEEK_RESCHEDULE = null;
    public String _CLASS_TYPE = null;
    public String _CLASS_CODE = null;
    public String _DEPARTURE_DATE = null;
    public String _DEPARTURE_TIME = null;
    public String _DST_CITY = null;
    public String _DURING = null;
    public String _FLIGHT_NO = null;
    public String _ORDER_NO = null;
    public String _ORG_CITY = null;
    public String _PNR = null;
    public String _SEG_ID = null;
    public String _STOP_CITY = null;
    public String _TICKET_NO = null;
    public String DEP_AIRPORT_NAME = null;
    public String ARR_AIRPORT_NAME = null;
    public String SEGMENT_INDEX = null;
    public String AC_TYPE = null;
    public String _IS_SHARE_FLIGHT = null;
    public String _NEWRULES_FLAG = null;
    public ArrayList<ticketInfoVO> _TICKET_INFO_LIST_NEW = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/cancel/booking";
    }

    public ArrayList<ticketInfoVO> get_TICKET_INFO_LIST_NEW() {
        return this._TICKET_INFO_LIST_NEW;
    }

    public void set_TICKET_INFO_LIST_NEW(ArrayList<ticketInfoVO> _TICKET_INFO_LIST_NEW) {
        this._TICKET_INFO_LIST_NEW = _TICKET_INFO_LIST_NEW;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._ACTUAL_FLIGHT_NO != null) {
            xml.startTag(null, "ACTUAL_FLIGHT_NO");
            xml.text(this._ACTUAL_FLIGHT_NO);
            xml.endTag(null, "ACTUAL_FLIGHT_NO");
        }
        if (this._AFTER_HOURS_REFUND != null) {
            xml.startTag(null, "AFTER_HOURS_REFUND");
            xml.text(this._AFTER_HOURS_REFUND);
            xml.endTag(null, "AFTER_HOURS_REFUND");
        }
        if (this._AFTER_HOURS_RESCHEDULE != null) {
            xml.startTag(null, "AFTER_HOURS_RESCHEDULE");
            xml.text(this._AFTER_HOURS_RESCHEDULE);
            xml.endTag(null, "AFTER_HOURS_RESCHEDULE");
        }
        if (this._ARRIVAL_DATE != null) {
            xml.startTag(null, "ARRIVAL_DATE");
            xml.text(this._ARRIVAL_DATE);
            xml.endTag(null, "ARRIVAL_DATE");
        }
        if (this._ARRIVAL_TIME != null) {
            xml.startTag(null, "ARRIVAL_TIME");
            xml.text(this._ARRIVAL_TIME);
            xml.endTag(null, "ARRIVAL_TIME");
        }
        if (this._BEFORE_DAYS_REFUND != null) {
            xml.startTag(null, "BEFORE_DAYS_REFUND");
            xml.text(this._BEFORE_DAYS_REFUND);
            xml.endTag(null, "BEFORE_DAYS_REFUND");
        }
        if (this._BEFORE_DAYS_RESCHEDULE != null) {
            xml.startTag(null, "BEFORE_DAYS_RESCHEDULE");
            xml.text(this._BEFORE_DAYS_RESCHEDULE);
            xml.endTag(null, "BEFORE_DAYS_RESCHEDULE");
        }
        if (this._BEFORE_HOURS_REFUND != null) {
            xml.startTag(null, "BEFORE_HOURS_REFUND");
            xml.text(this._BEFORE_HOURS_REFUND);
            xml.endTag(null, "BEFORE_HOURS_REFUND");
        }
        if (this._BEFORE_HOURS_RESCHEDULE != null) {
            xml.startTag(null, "BEFORE_HOURS_RESCHEDULE");
            xml.text(this._BEFORE_HOURS_RESCHEDULE);
            xml.endTag(null, "BEFORE_HOURS_RESCHEDULE");
        }
        if (this._BEFORE_WEEK_REFUND != null) {
            xml.startTag(null, "BEFORE_WEEK_REFUND");
            xml.text(this._BEFORE_WEEK_REFUND);
            xml.endTag(null, "BEFORE_WEEK_REFUND");
        }
        if (this._BEFORE_WEEK_RESCHEDULE != null) {
            xml.startTag(null, "BEFORE_WEEK_RESCHEDULE");
            xml.text(this._BEFORE_WEEK_RESCHEDULE);
            xml.endTag(null, "BEFORE_WEEK_RESCHEDULE");
        }
        if (this._CLASS_TYPE != null) {
            xml.startTag(null, "CLASS_TYPE");
            xml.text(this._CLASS_TYPE);
            xml.endTag(null, "CLASS_TYPE");
        }
        if (this._CLASS_CODE != null) {
            xml.startTag(null, "CLASS_CODE");
            xml.text(this._CLASS_CODE);
            xml.endTag(null, "CLASS_CODE");
        }
        if (this._DEPARTURE_DATE != null) {
            xml.startTag(null, "DEPARTURE_DATE");
            xml.text(this._DEPARTURE_DATE);
            xml.endTag(null, "DEPARTURE_DATE");
        }
        if (this._DEPARTURE_TIME != null) {
            xml.startTag(null, "DEPARTURE_TIME");
            xml.text(this._DEPARTURE_TIME);
            xml.endTag(null, "DEPARTURE_TIME");
        }
        if (this._DST_CITY != null) {
            xml.startTag(null, "DST_CITY");
            xml.text(this._DST_CITY);
            xml.endTag(null, "DST_CITY");
        }
        if (this._DURING != null) {
            xml.startTag(null, "DURING");
            xml.text(this._DURING);
            xml.endTag(null, "DURING");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._ORDER_NO != null) {
            xml.startTag(null, "ORDER_NO");
            xml.text(this._ORDER_NO);
            xml.endTag(null, "ORDER_NO");
        }
        if (this._ORG_CITY != null) {
            xml.startTag(null, "ORG_CITY");
            xml.text(this._ORG_CITY);
            xml.endTag(null, "ORG_CITY");
        }
        if (this._PNR != null) {
            xml.startTag(null, "PNR");
            xml.text(this._PNR);
            xml.endTag(null, "PNR");
        }
        if (this._SEG_ID != null) {
            xml.startTag(null, "SEG_ID");
            xml.text(this._SEG_ID);
            xml.endTag(null, "SEG_ID");
        }
        if (this._STOP_CITY != null) {
            xml.startTag(null, "STOP_CITY");
            xml.text(this._STOP_CITY);
            xml.endTag(null, "STOP_CITY");
        }
        if (this._TICKET_NO != null) {
            xml.startTag(null, "TICKET_NO");
            xml.text(this._TICKET_NO);
            xml.endTag(null, "TICKET_NO");
        }
        if (this._NEWRULES_FLAG != null) {
            xml.startTag(null, "NEWRULES_FLAG");
            xml.text(this._NEWRULES_FLAG);
            xml.endTag(null, "NEWRULES_FLAG");
        }
        if (this.DEP_AIRPORT_NAME != null) {
            xml.startTag(null, "DEP_AIRPORT_NAME");
            xml.text(this.DEP_AIRPORT_NAME);
            xml.endTag(null, "DEP_AIRPORT_NAME");
        }
        if (this.ARR_AIRPORT_NAME != null) {
            xml.startTag(null, "ARR_AIRPORT_NAME");
            xml.text(this.ARR_AIRPORT_NAME);
            xml.endTag(null, "ARR_AIRPORT_NAME");
        }
        if (this.SEGMENT_INDEX != null) {
            xml.startTag(null, "SEGMENT_INDEX");
            xml.text(this.SEGMENT_INDEX);
            xml.endTag(null, "SEGMENT_INDEX");
        }
        if (this.AC_TYPE != null) {
            xml.startTag(null, "AC_TYPE");
            xml.text(this.AC_TYPE);
            xml.endTag(null, "AC_TYPE");
        }
        if (this._IS_SHARE_FLIGHT != null) {
            xml.startTag(null, "IS_SHARE_FLIGHT");
            xml.text(this._IS_SHARE_FLIGHT);
            xml.endTag(null, "IS_SHARE_FLIGHT");
        }
        ArrayList<ticketInfoVO> arrayList = this._TICKET_INFO_LIST_NEW;
        if (arrayList == null || arrayList.size() <= 0) {
            return;
        }
        int size = this._TICKET_INFO_LIST_NEW.size();
        for (int i = 0; i < size; i++) {
            xml.startTag(null, "TICKET_INFO_LIST_NEW");
            this._TICKET_INFO_LIST_NEW.get(i).addElementsToNode(xml);
            xml.endTag(null, "TICKET_INFO_LIST_NEW");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("ACTUAL_FLIGHT_NO".equals(parser.getName())) {
                        this._ACTUAL_FLIGHT_NO = parser.nextText();
                    } else if ("AFTER_HOURS_REFUND".equals(parser.getName())) {
                        this._AFTER_HOURS_REFUND = parser.nextText();
                    } else if ("AFTER_HOURS_RESCHEDULE".equals(parser.getName())) {
                        this._AFTER_HOURS_RESCHEDULE = parser.nextText();
                    } else if ("ARRIVAL_DATE".equals(parser.getName())) {
                        this._ARRIVAL_DATE = parser.nextText();
                    } else if ("ARRIVAL_TIME".equals(parser.getName())) {
                        this._ARRIVAL_TIME = parser.nextText();
                    } else if ("BEFORE_DAYS_REFUND".equals(parser.getName())) {
                        this._BEFORE_DAYS_REFUND = parser.nextText();
                    } else if ("BEFORE_DAYS_RESCHEDULE".equals(parser.getName())) {
                        this._BEFORE_DAYS_RESCHEDULE = parser.nextText();
                    } else if ("BEFORE_HOURS_REFUND".equals(parser.getName())) {
                        this._BEFORE_HOURS_REFUND = parser.nextText();
                    } else if ("BEFORE_HOURS_RESCHEDULE".equals(parser.getName())) {
                        this._BEFORE_HOURS_RESCHEDULE = parser.nextText();
                    } else if ("BEFORE_WEEK_REFUND".equals(parser.getName())) {
                        this._BEFORE_WEEK_REFUND = parser.nextText();
                    } else if ("BEFORE_WEEK_RESCHEDULE".equals(parser.getName())) {
                        this._BEFORE_WEEK_RESCHEDULE = parser.nextText();
                    } else if ("CLASS_CODE".equals(parser.getName())) {
                        this._CLASS_CODE = parser.nextText();
                    } else if ("DEPARTURE_DATE".equals(parser.getName())) {
                        this._DEPARTURE_DATE = parser.nextText();
                    } else if ("DEPARTURE_TIME".equals(parser.getName())) {
                        this._DEPARTURE_TIME = parser.nextText();
                    } else if ("DST_CITY".equals(parser.getName())) {
                        this._DST_CITY = parser.nextText();
                    } else if ("DURING".equals(parser.getName())) {
                        this._DURING = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("ORDER_NO".equals(parser.getName())) {
                        this._ORDER_NO = parser.nextText();
                    } else if ("ORG_CITY".equals(parser.getName())) {
                        this._ORG_CITY = parser.nextText();
                    } else if ("PNR".equals(parser.getName())) {
                        this._PNR = parser.nextText();
                    } else if ("SEG_ID".equals(parser.getName())) {
                        this._SEG_ID = parser.nextText();
                    } else if ("STOP_CITY".equals(parser.getName())) {
                        this._STOP_CITY = parser.nextText();
                    } else if ("TICKET_NO".equals(parser.getName())) {
                        this._TICKET_NO = parser.nextText();
                    } else if ("CLASS_TYPE".equals(parser.getName())) {
                        this._CLASS_TYPE = parser.nextText();
                    } else if ("NEWRULES_FLAG".equals(parser.getName())) {
                        this._NEWRULES_FLAG = parser.nextText();
                    } else if ("DEP_AIRPORT_NAME".equals(parser.getName())) {
                        this.DEP_AIRPORT_NAME = parser.nextText();
                    } else if ("ARR_AIRPORT_NAME".equals(parser.getName())) {
                        this.ARR_AIRPORT_NAME = parser.nextText();
                    } else if ("SEGMENT_INDEX".equals(parser.getName())) {
                        this.SEGMENT_INDEX = parser.nextText();
                    } else if ("AC_TYPE".equals(parser.getName())) {
                        this.AC_TYPE = parser.nextText();
                    } else if ("IS_SHARE_FLIGHT".equals(parser.getName())) {
                        this._IS_SHARE_FLIGHT = parser.nextText();
                    } else if ("TICKET_INFO_LIST_NEW".equals(parser.getName())) {
                        if (this._TICKET_INFO_LIST_NEW == null) {
                            this._TICKET_INFO_LIST_NEW = new ArrayList<>();
                        }
                        ticketInfoVO ticketinfovo = new ticketInfoVO();
                        ticketinfovo.parse(binding, parser);
                        this._TICKET_INFO_LIST_NEW.add(ticketinfovo);
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}