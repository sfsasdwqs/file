package com.common.szair.model.cancelpnrseat;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class checkCertNoConditionVO implements SOAPObject {
    public String _CONTACTS_MOBILE = null;
    public String _ORIG_CAPTCHA = null;
    public List<ticketInfoVO> _TICKET_INFO_LIST = null;
    public List<tripInfoVO> _TRIP_INFO_LIST = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/cancel/booking";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CONTACTS_MOBILE != null) {
            xml.startTag(null, "CONTACTS_MOBILE");
            xml.text(this._CONTACTS_MOBILE);
            xml.endTag(null, "CONTACTS_MOBILE");
        }
        if (this._ORIG_CAPTCHA != null) {
            xml.startTag(null, "ORIG_CAPTCHA");
            xml.text(this._ORIG_CAPTCHA);
            xml.endTag(null, "ORIG_CAPTCHA");
        }
        List<ticketInfoVO> list = this._TICKET_INFO_LIST;
        if (list != null && list.size() > 0) {
            int size = this._TICKET_INFO_LIST.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "TICKET_INFO_LIST");
                this._TICKET_INFO_LIST.get(i).addElementsToNode(xml);
                xml.endTag(null, "TICKET_INFO_LIST");
            }
        }
        List<tripInfoVO> list2 = this._TRIP_INFO_LIST;
        if (list2 == null || list2.size() <= 0) {
            return;
        }
        int size2 = this._TRIP_INFO_LIST.size();
        for (int i2 = 0; i2 < size2; i2++) {
            xml.startTag(null, "TRIP_INFO_LIST");
            this._TRIP_INFO_LIST.get(i2).addElementsToNode(xml);
            xml.endTag(null, "TRIP_INFO_LIST");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CONTACTS_MOBILE".equals(parser.getName())) {
                        this._CONTACTS_MOBILE = parser.nextText();
                    } else if ("ORIG_CAPTCHA".equals(parser.getName())) {
                        this._ORIG_CAPTCHA = parser.nextText();
                    } else if ("TICKET_INFO_LIST".equals(parser.getName())) {
                        if (this._TICKET_INFO_LIST == null) {
                            this._TICKET_INFO_LIST = new ArrayList();
                        }
                        ticketInfoVO ticketinfovo = new ticketInfoVO();
                        ticketinfovo.parse(binding, parser);
                        this._TICKET_INFO_LIST.add(ticketinfovo);
                    } else if ("TRIP_INFO_LIST".equals(parser.getName())) {
                        if (this._TRIP_INFO_LIST == null) {
                            this._TRIP_INFO_LIST = new ArrayList();
                        }
                        tripInfoVO tripinfovo = new tripInfoVO();
                        tripinfovo.parse(binding, parser);
                        this._TRIP_INFO_LIST.add(tripinfovo);
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}