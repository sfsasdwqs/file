package com.common.szair.model.cancelpnrseat;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class orderInfoVO implements SOAPObject, Serializable {
    public String _CONTACTS_MOBILE = null;
    public String _CREATE_TIME = null;
    public String _ID = null;
    public String _MEMBER_ID = null;
    public String _ORDER_NO = null;
    public String _REFUND_TIME = null;
    public ArrayList<segmentInfoVO> _SEGMENT_INFO_LIST = null;
    public String _SOURCE = null;
    public String _STATUS = null;
    public ArrayList<ticketInfoVO> _TICKET_INFO_LIST = null;
    public String _EXTEND1 = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/cancel/booking";
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CONTACTS_MOBILE != null) {
            xml.startTag(null, "CONTACTS_MOBILE");
            xml.text(this._CONTACTS_MOBILE);
            xml.endTag(null, "CONTACTS_MOBILE");
        }
        if (this._CREATE_TIME != null) {
            xml.startTag(null, "CREATE_TIME");
            xml.text(this._CREATE_TIME);
            xml.endTag(null, "CREATE_TIME");
        }
        if (this._ID != null) {
            xml.startTag(null, "ID");
            xml.text(this._ID);
            xml.endTag(null, "ID");
        }
        if (this._MEMBER_ID != null) {
            xml.startTag(null, "MEMBER_ID");
            xml.text(this._MEMBER_ID);
            xml.endTag(null, "MEMBER_ID");
        }
        if (this._ORDER_NO != null) {
            xml.startTag(null, "ORDER_NO");
            xml.text(this._ORDER_NO);
            xml.endTag(null, "ORDER_NO");
        }
        if (this._EXTEND1 != null) {
            xml.startTag(null, "EXTEND1");
            xml.text(this._EXTEND1);
            xml.endTag(null, "EXTEND1");
        }
        if (this._REFUND_TIME != null) {
            xml.startTag(null, "REFUND_TIME");
            xml.text(this._REFUND_TIME);
            xml.endTag(null, "REFUND_TIME");
        }
        ArrayList<segmentInfoVO> arrayList = this._SEGMENT_INFO_LIST;
        if (arrayList != null && arrayList.size() > 0) {
            int size = this._SEGMENT_INFO_LIST.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "SEGMENT_INFO_LIST");
                this._SEGMENT_INFO_LIST.get(i).addElementsToNode(xml);
                xml.endTag(null, "SEGMENT_INFO_LIST");
            }
        }
        if (this._SOURCE != null) {
            xml.startTag(null, "SOURCE");
            xml.text(this._SOURCE);
            xml.endTag(null, "SOURCE");
        }
        if (this._STATUS != null) {
            xml.startTag(null, "STATUS");
            xml.text(this._STATUS);
            xml.endTag(null, "STATUS");
        }
        ArrayList<ticketInfoVO> arrayList2 = this._TICKET_INFO_LIST;
        if (arrayList2 == null || arrayList2.size() <= 0) {
            return;
        }
        int size2 = this._TICKET_INFO_LIST.size();
        for (int i2 = 0; i2 < size2; i2++) {
            xml.startTag(null, "TICKET_INFO_LIST");
            this._TICKET_INFO_LIST.get(i2).addElementsToNode(xml);
            xml.endTag(null, "TICKET_INFO_LIST");
        }
    }

    @Override // com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CONTACTS_MOBILE".equals(parser.getName())) {
                        this._CONTACTS_MOBILE = parser.nextText();
                    } else if ("CREATE_TIME".equals(parser.getName())) {
                        this._CREATE_TIME = parser.nextText();
                    } else if ("ID".equals(parser.getName())) {
                        this._ID = parser.nextText();
                    } else if ("MEMBER_ID".equals(parser.getName())) {
                        this._MEMBER_ID = parser.nextText();
                    } else if ("ORDER_NO".equals(parser.getName())) {
                        this._ORDER_NO = parser.nextText();
                    } else if ("EXTEND1".equals(parser.getName())) {
                        this._EXTEND1 = parser.nextText();
                    } else if ("REFUND_TIME".equals(parser.getName())) {
                        this._REFUND_TIME = parser.nextText();
                    } else if ("SEGMENT_INFO_LIST".equals(parser.getName())) {
                        if (this._SEGMENT_INFO_LIST == null) {
                            this._SEGMENT_INFO_LIST = new ArrayList<>();
                        }
                        segmentInfoVO segmentinfovo = new segmentInfoVO();
                        segmentinfovo.parse(binding, parser);
                        this._SEGMENT_INFO_LIST.add(segmentinfovo);
                    } else if ("SOURCE".equals(parser.getName())) {
                        this._SOURCE = parser.nextText();
                    } else if ("STATUS".equals(parser.getName())) {
                        this._STATUS = parser.nextText();
                    } else if ("TICKET_INFO_LIST".equals(parser.getName())) {
                        if (this._TICKET_INFO_LIST == null) {
                            this._TICKET_INFO_LIST = new ArrayList<>();
                        }
                        ticketInfoVO ticketinfovo = new ticketInfoVO();
                        ticketinfovo.parse(binding, parser);
                        this._TICKET_INFO_LIST.add(ticketinfovo);
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}