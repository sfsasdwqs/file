package com.common.szair.model.cancelpnrseat;

import java.io.Serializable;
import java.util.ArrayList;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class CancelPnrDataBean implements Serializable {
    public ArrayList<ticketInfoVO> passengerList;
    public ArrayList<tripInfoVO> selectTripList;
    public String _MOBILE = null;
    public String _AES_MOBILE = null;
    public boolean isMobileCheck = false;
}