package com.common.szair.model.campaign;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class SFCampaignWebServiceImplServiceSoapBinding extends SOAPBinding {
    public SFCampaignWebServiceImplServiceSoapBinding(String endpoint) {
        super(SFCampaignWebServiceImplServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns4", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns1", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns2", "http://com/shenzhenair/mobilewebservice/sfCampaign");
        hashMap.put("ns0", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns3", "http://impl.webservice.shenzhenMember.shenzhenair.com/");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        return hashMap;
    }

    public checkCampaignResponse checkCampaign(checkCampaign parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("checkCampaign", parameters);
        }
        checkCampaignResponse checkcampaignresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof checkCampaignResponse)) {
                    checkcampaignresponse = (checkCampaignResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    checkcampaignresponse = new checkCampaignResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    checkcampaignresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (checkcampaignresponse != null) {
                return checkcampaignresponse;
            }
            checkCampaignResponse checkcampaignresponse2 = new checkCampaignResponse();
            checkcampaignresponse2.setexception(new NullPointerException());
            return checkcampaignresponse2;
        } catch (Exception e) {
            checkCampaignResponse checkcampaignresponse3 = new checkCampaignResponse();
            checkcampaignresponse3.setexception(e);
            return checkcampaignresponse3;
        }
    }

    public testResponse test(test parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("test", parameters);
        }
        testResponse testresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof testResponse)) {
                    testresponse = (testResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    testresponse = new testResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    testresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (testresponse != null) {
                return testresponse;
            }
            testResponse testresponse2 = new testResponse();
            testresponse2.setexception(new NullPointerException());
            return testresponse2;
        } catch (Exception e) {
            testResponse testresponse3 = new testResponse();
            testresponse3.setexception(e);
            return testresponse3;
        }
    }
}