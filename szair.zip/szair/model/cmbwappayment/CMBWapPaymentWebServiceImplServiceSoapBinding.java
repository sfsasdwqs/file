package com.common.szair.model.cmbwappayment;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class CMBWapPaymentWebServiceImplServiceSoapBinding extends SOAPBinding {
    public CMBWapPaymentWebServiceImplServiceSoapBinding(String endpoint) {
        super(CMBWapPaymentWebServiceImplServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns0", "http://com/shenzhenair/mobilewebservice/payment");
        hashMap.put("ns2", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        hashMap.put("ns4", "http://impl.webservice.payment.shenzhenair.com/");
        hashMap.put("ns1", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns3", "http://schemas.xmlsoap.org/soap/http");
        return hashMap;
    }

    public queryCMBWapPaymentParamResponse queryCMBWapPaymentParam(queryCMBWapPaymentParam parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryCMBWapPaymentParam", parameters);
        }
        queryCMBWapPaymentParamResponse querycmbwappaymentparamresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryCMBWapPaymentParamResponse)) {
                    querycmbwappaymentparamresponse = (queryCMBWapPaymentParamResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querycmbwappaymentparamresponse = new queryCMBWapPaymentParamResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querycmbwappaymentparamresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querycmbwappaymentparamresponse != null) {
                return querycmbwappaymentparamresponse;
            }
            queryCMBWapPaymentParamResponse querycmbwappaymentparamresponse2 = new queryCMBWapPaymentParamResponse();
            querycmbwappaymentparamresponse2.setexception(new NullPointerException());
            return querycmbwappaymentparamresponse2;
        } catch (Exception e) {
            queryCMBWapPaymentParamResponse querycmbwappaymentparamresponse3 = new queryCMBWapPaymentParamResponse();
            querycmbwappaymentparamresponse3.setexception(e);
            return querycmbwappaymentparamresponse3;
        }
    }
}