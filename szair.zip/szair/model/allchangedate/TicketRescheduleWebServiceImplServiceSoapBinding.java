package com.common.szair.model.allchangedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class TicketRescheduleWebServiceImplServiceSoapBinding extends SOAPBinding {
    public TicketRescheduleWebServiceImplServiceSoapBinding(String endpoint) {
        super(TicketRescheduleWebServiceImplServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns2", "http://com/shenzhenair/mobilewebservice/allChannelTicketReschedule");
        hashMap.put("ns4", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns1", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns3", "http://impl.webservice.allChannelReschedule.shenzhenair.com/");
        hashMap.put("ns0", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        return hashMap;
    }

    public checkWorkOrderTypeResponse checkWorkOrderType(checkWorkOrderType parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("checkWorkOrderType", parameters);
        }
        checkWorkOrderTypeResponse checkworkordertyperesponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof checkWorkOrderTypeResponse)) {
                    checkworkordertyperesponse = (checkWorkOrderTypeResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    checkworkordertyperesponse = new checkWorkOrderTypeResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    checkworkordertyperesponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (checkworkordertyperesponse != null) {
                return checkworkordertyperesponse;
            }
            checkWorkOrderTypeResponse checkworkordertyperesponse2 = new checkWorkOrderTypeResponse();
            checkworkordertyperesponse2.setexception(new NullPointerException());
            return checkworkordertyperesponse2;
        } catch (java.lang.Exception e) {
            checkWorkOrderTypeResponse checkworkordertyperesponse3 = new checkWorkOrderTypeResponse();
            checkworkordertyperesponse3.setexception(e);
            return checkworkordertyperesponse3;
        }
    }

    public rescheduleInfoQuickCheckResponse rescheduleInfoQuickCheck(rescheduleInfoQuickCheck parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("rescheduleInfoQuickCheck", parameters);
        }
        rescheduleInfoQuickCheckResponse rescheduleinfoquickcheckresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof rescheduleInfoQuickCheckResponse)) {
                    rescheduleinfoquickcheckresponse = (rescheduleInfoQuickCheckResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    rescheduleinfoquickcheckresponse = new rescheduleInfoQuickCheckResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    rescheduleinfoquickcheckresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (rescheduleinfoquickcheckresponse != null) {
                return rescheduleinfoquickcheckresponse;
            }
            rescheduleInfoQuickCheckResponse rescheduleinfoquickcheckresponse2 = new rescheduleInfoQuickCheckResponse();
            rescheduleinfoquickcheckresponse2.setexception(new NullPointerException());
            return rescheduleinfoquickcheckresponse2;
        } catch (java.lang.Exception e) {
            rescheduleInfoQuickCheckResponse rescheduleinfoquickcheckresponse3 = new rescheduleInfoQuickCheckResponse();
            rescheduleinfoquickcheckresponse3.setexception(e);
            return rescheduleinfoquickcheckresponse3;
        }
    }

    public searchTicketRescheduleInfoResponse searchTicketRescheduleInfo(searchTicketRescheduleInfo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("searchTicketRescheduleInfo", parameters);
        }
        searchTicketRescheduleInfoResponse searchticketrescheduleinforesponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof searchTicketRescheduleInfoResponse)) {
                    searchticketrescheduleinforesponse = (searchTicketRescheduleInfoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    searchticketrescheduleinforesponse = new searchTicketRescheduleInfoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    searchticketrescheduleinforesponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (searchticketrescheduleinforesponse != null) {
                return searchticketrescheduleinforesponse;
            }
            searchTicketRescheduleInfoResponse searchticketrescheduleinforesponse2 = new searchTicketRescheduleInfoResponse();
            searchticketrescheduleinforesponse2.setexception(new NullPointerException());
            return searchticketrescheduleinforesponse2;
        } catch (java.lang.Exception e) {
            searchTicketRescheduleInfoResponse searchticketrescheduleinforesponse3 = new searchTicketRescheduleInfoResponse();
            searchticketrescheduleinforesponse3.setexception(e);
            return searchticketrescheduleinforesponse3;
        }
    }

    public searchReschedulePartnersInfoResponse searchReschedulePartnersInfo(searchReschedulePartnersInfo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("searchReschedulePartnersInfo", parameters);
        }
        searchReschedulePartnersInfoResponse searchreschedulepartnersinforesponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof searchReschedulePartnersInfoResponse)) {
                    searchreschedulepartnersinforesponse = (searchReschedulePartnersInfoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    searchreschedulepartnersinforesponse = new searchReschedulePartnersInfoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    searchreschedulepartnersinforesponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (searchreschedulepartnersinforesponse != null) {
                return searchreschedulepartnersinforesponse;
            }
            searchReschedulePartnersInfoResponse searchreschedulepartnersinforesponse2 = new searchReschedulePartnersInfoResponse();
            searchreschedulepartnersinforesponse2.setexception(new NullPointerException());
            return searchreschedulepartnersinforesponse2;
        } catch (java.lang.Exception e) {
            searchReschedulePartnersInfoResponse searchreschedulepartnersinforesponse3 = new searchReschedulePartnersInfoResponse();
            searchreschedulepartnersinforesponse3.setexception(e);
            return searchreschedulepartnersinforesponse3;
        }
    }

    public commitRescheduleOrderResponse commitRescheduleOrder(commitRescheduleOrder parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("commitRescheduleOrder", parameters);
        }
        commitRescheduleOrderResponse commitrescheduleorderresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof commitRescheduleOrderResponse)) {
                    commitrescheduleorderresponse = (commitRescheduleOrderResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    commitrescheduleorderresponse = new commitRescheduleOrderResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    commitrescheduleorderresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (commitrescheduleorderresponse != null) {
                return commitrescheduleorderresponse;
            }
            commitRescheduleOrderResponse commitrescheduleorderresponse2 = new commitRescheduleOrderResponse();
            commitrescheduleorderresponse2.setexception(new NullPointerException());
            return commitrescheduleorderresponse2;
        } catch (java.lang.Exception e) {
            commitRescheduleOrderResponse commitrescheduleorderresponse3 = new commitRescheduleOrderResponse();
            commitrescheduleorderresponse3.setexception(e);
            return commitrescheduleorderresponse3;
        }
    }

    public rescheduleInfoCheckResponse rescheduleInfoCheck(rescheduleInfoCheck parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("rescheduleInfoCheck", parameters);
        }
        rescheduleInfoCheckResponse rescheduleinfocheckresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof rescheduleInfoCheckResponse)) {
                    rescheduleinfocheckresponse = (rescheduleInfoCheckResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    rescheduleinfocheckresponse = new rescheduleInfoCheckResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    rescheduleinfocheckresponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (rescheduleinfocheckresponse != null) {
                return rescheduleinfocheckresponse;
            }
            rescheduleInfoCheckResponse rescheduleinfocheckresponse2 = new rescheduleInfoCheckResponse();
            rescheduleinfocheckresponse2.setexception(new NullPointerException());
            return rescheduleinfocheckresponse2;
        } catch (java.lang.Exception e) {
            rescheduleInfoCheckResponse rescheduleinfocheckresponse3 = new rescheduleInfoCheckResponse();
            rescheduleinfocheckresponse3.setexception(e);
            return rescheduleinfocheckresponse3;
        }
    }

    public searchRescheduleFlightInfoResponse searchRescheduleFlightInfo(searchRescheduleFlightInfo parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("searchRescheduleFlightInfo", parameters);
        }
        searchRescheduleFlightInfoResponse searchrescheduleflightinforesponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof searchRescheduleFlightInfoResponse)) {
                    searchrescheduleflightinforesponse = (searchRescheduleFlightInfoResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    searchrescheduleflightinforesponse = new searchRescheduleFlightInfoResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    searchrescheduleflightinforesponse.setexception(new java.lang.Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (searchrescheduleflightinforesponse != null) {
                return searchrescheduleflightinforesponse;
            }
            searchRescheduleFlightInfoResponse searchrescheduleflightinforesponse2 = new searchRescheduleFlightInfoResponse();
            searchrescheduleflightinforesponse2.setexception(new NullPointerException());
            return searchrescheduleflightinforesponse2;
        } catch (java.lang.Exception e) {
            searchRescheduleFlightInfoResponse searchrescheduleflightinforesponse3 = new searchRescheduleFlightInfoResponse();
            searchrescheduleflightinforesponse3.setexception(e);
            return searchrescheduleflightinforesponse3;
        }
    }
}