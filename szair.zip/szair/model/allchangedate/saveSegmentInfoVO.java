package com.common.szair.model.allchangedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class saveSegmentInfoVO extends baseDTOVO implements SOAPObject, Serializable {
    public String _DST_CITY = null;
    public String _DST_CITY_NEW = null;
    public String _FLIGHT_DATE = null;
    public String _FLIGHT_DATE_NEW = null;
    public String _FLIGHT_NO = null;
    public String _FLIGHT_NO_NEW = null;
    public String _ORG_CITY = null;
    public String _ORG_CITY_NEW = null;
    public String _CONNECT_FLAG = null;
    public String _SEARCH_FLAG = null;
    public List<savePassengerInfoVO> _PASSENGER_INFO_LIST = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/rescheduleMktWebService";
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._DST_CITY != null) {
            xml.startTag(null, "DST_CITY");
            xml.text(this._DST_CITY);
            xml.endTag(null, "DST_CITY");
        }
        if (this._DST_CITY_NEW != null) {
            xml.startTag(null, "DST_CITY_NEW");
            xml.text(this._DST_CITY_NEW);
            xml.endTag(null, "DST_CITY_NEW");
        }
        if (this._FLIGHT_DATE != null) {
            xml.startTag(null, "FLIGHT_DATE");
            xml.text(this._FLIGHT_DATE);
            xml.endTag(null, "FLIGHT_DATE");
        }
        if (this._FLIGHT_DATE_NEW != null) {
            xml.startTag(null, "FLIGHT_DATE_NEW");
            xml.text(this._FLIGHT_DATE_NEW);
            xml.endTag(null, "FLIGHT_DATE_NEW");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._FLIGHT_NO_NEW != null) {
            xml.startTag(null, "FLIGHT_NO_NEW");
            xml.text(this._FLIGHT_NO_NEW);
            xml.endTag(null, "FLIGHT_NO_NEW");
        }
        if (this._ORG_CITY != null) {
            xml.startTag(null, "ORG_CITY");
            xml.text(this._ORG_CITY);
            xml.endTag(null, "ORG_CITY");
        }
        if (this._ORG_CITY_NEW != null) {
            xml.startTag(null, "ORG_CITY_NEW");
            xml.text(this._ORG_CITY_NEW);
            xml.endTag(null, "ORG_CITY_NEW");
        }
        if (this._CONNECT_FLAG != null) {
            xml.startTag(null, "CONNECT_FLAG");
            xml.text(this._CONNECT_FLAG);
            xml.endTag(null, "CONNECT_FLAG");
        }
        if (this._SEARCH_FLAG != null) {
            xml.startTag(null, "SEARCH_FLAG");
            xml.text(this._SEARCH_FLAG);
            xml.endTag(null, "SEARCH_FLAG");
        }
        List<savePassengerInfoVO> list = this._PASSENGER_INFO_LIST;
        if (list == null || list.size() <= 0) {
            return;
        }
        int size = this._PASSENGER_INFO_LIST.size();
        for (int i = 0; i < size; i++) {
            xml.startTag(null, "PASSENGER_INFO_LIST");
            this._PASSENGER_INFO_LIST.get(i).addElementsToNode(xml);
            xml.endTag(null, "PASSENGER_INFO_LIST");
        }
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("DST_CITY".equals(parser.getName())) {
                        this._DST_CITY = parser.nextText();
                    } else if ("DST_CITY_NEW".equals(parser.getName())) {
                        this._DST_CITY_NEW = parser.nextText();
                    } else if ("FLIGHT_DATE".equals(parser.getName())) {
                        this._FLIGHT_DATE = parser.nextText();
                    } else if ("FLIGHT_DATE_NEW".equals(parser.getName())) {
                        this._FLIGHT_DATE_NEW = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("FLIGHT_NO_NEW".equals(parser.getName())) {
                        this._FLIGHT_NO_NEW = parser.nextText();
                    } else if ("ORG_CITY".equals(parser.getName())) {
                        this._ORG_CITY = parser.nextText();
                    } else if ("ORG_CITY_NEW".equals(parser.getName())) {
                        this._ORG_CITY_NEW = parser.nextText();
                    } else if ("CONNECT_FLAG".equals(parser.getName())) {
                        this._CONNECT_FLAG = parser.nextText();
                    } else if ("SEARCH_FLAG".equals(parser.getName())) {
                        this._SEARCH_FLAG = parser.nextText();
                    } else if ("PASSENGER_INFO_LIST".equals(parser.getName())) {
                        if (this._PASSENGER_INFO_LIST == null) {
                            this._PASSENGER_INFO_LIST = new ArrayList();
                        }
                        savePassengerInfoVO savepassengerinfovo = new savePassengerInfoVO();
                        savepassengerinfovo.parse(binding, parser);
                        this._PASSENGER_INFO_LIST.add(savepassengerinfovo);
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}