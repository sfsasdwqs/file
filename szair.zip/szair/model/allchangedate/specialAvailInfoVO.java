package com.common.szair.model.allchangedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class specialAvailInfoVO extends baseDTOVO implements SOAPObject, Serializable {
    public String _AVAIL_TIME_LIST = null;
    public String _SPECIAL_AVAIL_INFO_FLIGHT_NO = null;
    public String _FREE_TYPE = null;
    public String _SPECIAL_AVAIL_INFO_USABLE = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/allChannelTicketReschedule";
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._AVAIL_TIME_LIST != null) {
            xml.startTag(null, "AVAIL_TIME_LIST");
            xml.text(this._AVAIL_TIME_LIST);
            xml.endTag(null, "AVAIL_TIME_LIST");
        }
        if (this._SPECIAL_AVAIL_INFO_FLIGHT_NO != null) {
            xml.startTag(null, "SPECIAL_AVAIL_INFO_FLIGHT_NO");
            xml.text(this._SPECIAL_AVAIL_INFO_FLIGHT_NO);
            xml.endTag(null, "SPECIAL_AVAIL_INFO_FLIGHT_NO");
        }
        if (this._FREE_TYPE != null) {
            xml.startTag(null, "FREE_TYPE");
            xml.text(this._FREE_TYPE);
            xml.endTag(null, "FREE_TYPE");
        }
        if (this._SPECIAL_AVAIL_INFO_USABLE != null) {
            xml.startTag(null, "SPECIAL_AVAIL_INFO_USABLE");
            xml.text(this._SPECIAL_AVAIL_INFO_USABLE);
            xml.endTag(null, "SPECIAL_AVAIL_INFO_USABLE");
        }
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("AVAIL_TIME_LIST".equals(parser.getName())) {
                        this._AVAIL_TIME_LIST = parser.nextText();
                    } else if ("SPECIAL_AVAIL_INFO_FLIGHT_NO".equals(parser.getName())) {
                        this._SPECIAL_AVAIL_INFO_FLIGHT_NO = parser.nextText();
                    } else if ("FREE_TYPE".equals(parser.getName())) {
                        this._FREE_TYPE = parser.nextText();
                    } else if ("SPECIAL_AVAIL_INFO_USABLE".equals(parser.getName())) {
                        this._SPECIAL_AVAIL_INFO_USABLE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}