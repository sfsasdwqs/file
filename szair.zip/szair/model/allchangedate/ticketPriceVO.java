package com.common.szair.model.allchangedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class ticketPriceVO extends baseDTOVO implements SOAPObject, Serializable {
    public Double _ADD_PRICE = null;
    public Double _CN = null;
    public Double _PRICE = null;
    public List<productInfoVO> _PRODUCT_INFO_LIST = null;
    public Double _USE_PRICE = null;
    public Double _YQ = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/rescheduleMktWebService";
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._ADD_PRICE != null) {
            xml.startTag(null, "ADD_PRICE");
            xml.text(String.valueOf(this._ADD_PRICE));
            xml.endTag(null, "ADD_PRICE");
        }
        if (this._CN != null) {
            xml.startTag(null, "CN");
            xml.text(String.valueOf(this._CN));
            xml.endTag(null, "CN");
        }
        if (this._PRICE != null) {
            xml.startTag(null, "PRICE");
            xml.text(String.valueOf(this._PRICE));
            xml.endTag(null, "PRICE");
        }
        List<productInfoVO> list = this._PRODUCT_INFO_LIST;
        if (list != null && list.size() > 0) {
            int size = this._PRODUCT_INFO_LIST.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "PRODUCT_INFO_LIST");
                this._PRODUCT_INFO_LIST.get(i).addElementsToNode(xml);
                xml.endTag(null, "PRODUCT_INFO_LIST");
            }
        }
        if (this._USE_PRICE != null) {
            xml.startTag(null, "USE_PRICE");
            xml.text(String.valueOf(this._USE_PRICE));
            xml.endTag(null, "USE_PRICE");
        }
        if (this._YQ != null) {
            xml.startTag(null, "YQ");
            xml.text(String.valueOf(this._YQ));
            xml.endTag(null, "YQ");
        }
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("ADD_PRICE".equals(parser.getName())) {
                        this._ADD_PRICE = Double.valueOf(parser.nextText());
                    } else if ("CN".equals(parser.getName())) {
                        this._CN = Double.valueOf(parser.nextText());
                    } else if ("PRICE".equals(parser.getName())) {
                        this._PRICE = Double.valueOf(parser.nextText());
                    } else if ("PRODUCT_INFO_LIST".equals(parser.getName())) {
                        if (this._PRODUCT_INFO_LIST == null) {
                            this._PRODUCT_INFO_LIST = new ArrayList();
                        }
                        productInfoVO productinfovo = new productInfoVO();
                        productinfovo.parse(binding, parser);
                        this._PRODUCT_INFO_LIST.add(productinfovo);
                    } else if ("USE_PRICE".equals(parser.getName())) {
                        this._USE_PRICE = Double.valueOf(parser.nextText());
                    } else if ("YQ".equals(parser.getName())) {
                        this._YQ = Double.valueOf(parser.nextText());
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}