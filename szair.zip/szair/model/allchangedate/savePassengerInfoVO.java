package com.common.szair.model.allchangedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class savePassengerInfoVO extends baseDTOVO implements SOAPObject, Serializable {
    public String _ADT_TICKET_NO = null;
    public String _CLASS_CODE = null;
    public String _FREE_FEE_TYPE = null;
    public String _PRODUCT_VALUE = null;
    public String _REAL_PRODUCT_VALUE = null;
    public String _TICKET_NO = null;
    public String _SEX = null;
    public String _EXPIRATION_DATE = null;
    public String _CN_FIRST_NAME = null;
    public String _CN_LAST_NAME = null;
    public String _EN_FIRST_NAME = null;
    public String _EN_LAST_NAME = null;
    public String _ISSUE_NATION = null;
    public String _NATION = null;
    public String _BIRTHDAY = null;
    public String _CERT_TYPE = null;
    public String _CERT_NO = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/rescheduleMktWebService";
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._ADT_TICKET_NO != null) {
            xml.startTag(null, "ADT_TICKET_NO");
            xml.text(this._ADT_TICKET_NO);
            xml.endTag(null, "ADT_TICKET_NO");
        }
        if (this._CLASS_CODE != null) {
            xml.startTag(null, "CLASS_CODE");
            xml.text(this._CLASS_CODE);
            xml.endTag(null, "CLASS_CODE");
        }
        if (this._FREE_FEE_TYPE != null) {
            xml.startTag(null, "FREE_FEE_TYPE");
            xml.text(this._FREE_FEE_TYPE);
            xml.endTag(null, "FREE_FEE_TYPE");
        }
        if (this._PRODUCT_VALUE != null) {
            xml.startTag(null, "PRODUCT_VALUE");
            xml.text(this._PRODUCT_VALUE);
            xml.endTag(null, "PRODUCT_VALUE");
        }
        if (this._REAL_PRODUCT_VALUE != null) {
            xml.startTag(null, "REAL_PRODUCT_VALUE");
            xml.text(this._REAL_PRODUCT_VALUE);
            xml.endTag(null, "REAL_PRODUCT_VALUE");
        }
        if (this._TICKET_NO != null) {
            xml.startTag(null, "TICKET_NO");
            xml.text(this._TICKET_NO);
            xml.endTag(null, "TICKET_NO");
        }
        if (this._SEX != null) {
            xml.startTag(null, "SEX");
            xml.text(this._SEX);
            xml.endTag(null, "SEX");
        }
        if (this._EXPIRATION_DATE != null) {
            xml.startTag(null, "EXPIRATION_DATE");
            xml.text(this._EXPIRATION_DATE);
            xml.endTag(null, "EXPIRATION_DATE");
        }
        if (this._CN_FIRST_NAME != null) {
            xml.startTag(null, "CN_FIRST_NAME");
            xml.text(this._CN_FIRST_NAME);
            xml.endTag(null, "CN_FIRST_NAME");
        }
        if (this._CN_LAST_NAME != null) {
            xml.startTag(null, "CN_LAST_NAME");
            xml.text(this._CN_LAST_NAME);
            xml.endTag(null, "CN_LAST_NAME");
        }
        if (this._EN_FIRST_NAME != null) {
            xml.startTag(null, "EN_FIRST_NAME");
            xml.text(this._EN_FIRST_NAME);
            xml.endTag(null, "EN_FIRST_NAME");
        }
        if (this._EN_LAST_NAME != null) {
            xml.startTag(null, "EN_LAST_NAME");
            xml.text(this._EN_LAST_NAME);
            xml.endTag(null, "EN_LAST_NAME");
        }
        if (this._ISSUE_NATION != null) {
            xml.startTag(null, "ISSUE_NATION");
            xml.text(this._ISSUE_NATION);
            xml.endTag(null, "ISSUE_NATION");
        }
        if (this._NATION != null) {
            xml.startTag(null, "NATION");
            xml.text(this._NATION);
            xml.endTag(null, "NATION");
        }
        if (this._BIRTHDAY != null) {
            xml.startTag(null, "BIRTHDAY");
            xml.text(this._BIRTHDAY);
            xml.endTag(null, "BIRTHDAY");
        }
        if (this._CERT_TYPE != null) {
            xml.startTag(null, "CERT_TYPE");
            xml.text(this._CERT_TYPE);
            xml.endTag(null, "CERT_TYPE");
        }
        if (this._CERT_NO != null) {
            xml.startTag(null, "CERT_NO");
            xml.text(this._CERT_NO);
            xml.endTag(null, "CERT_NO");
        }
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("ADT_TICKET_NO".equals(parser.getName())) {
                        this._ADT_TICKET_NO = parser.nextText();
                    } else if ("CLASS_CODE".equals(parser.getName())) {
                        this._CLASS_CODE = parser.nextText();
                    } else if ("FREE_FEE_TYPE".equals(parser.getName())) {
                        this._FREE_FEE_TYPE = parser.nextText();
                    } else if ("PRODUCT_VALUE".equals(parser.getName())) {
                        this._PRODUCT_VALUE = parser.nextText();
                    } else if ("REAL_PRODUCT_VALUE".equals(parser.getName())) {
                        this._REAL_PRODUCT_VALUE = parser.nextText();
                    } else if ("TICKET_NO".equals(parser.getName())) {
                        this._TICKET_NO = parser.nextText();
                    } else if ("SEX".equals(parser.getName())) {
                        this._SEX = parser.nextText();
                    } else if ("EXPIRATION_DATE".equals(parser.getName())) {
                        this._EXPIRATION_DATE = parser.nextText();
                    } else if ("CN_FIRST_NAME".equals(parser.getName())) {
                        this._CN_FIRST_NAME = parser.nextText();
                    } else if ("CN_LAST_NAME".equals(parser.getName())) {
                        this._CN_LAST_NAME = parser.nextText();
                    } else if ("EN_FIRST_NAME".equals(parser.getName())) {
                        this._EN_FIRST_NAME = parser.nextText();
                    } else if ("EN_LAST_NAME".equals(parser.getName())) {
                        this._EN_LAST_NAME = parser.nextText();
                    } else if ("ISSUE_NATION".equals(parser.getName())) {
                        this._ISSUE_NATION = parser.nextText();
                    } else if ("NATION".equals(parser.getName())) {
                        this._NATION = parser.nextText();
                    } else if ("BIRTHDAY".equals(parser.getName())) {
                        this._BIRTHDAY = parser.nextText();
                    } else if ("CERT_TYPE".equals(parser.getName())) {
                        this._CERT_TYPE = parser.nextText();
                    } else if ("CERT_NO".equals(parser.getName())) {
                        this._CERT_NO = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}