package com.common.szair.model.allchangedate;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class ticketRescheduleInfoSearchConditionVO extends baseDTOVO implements SOAPObject {
    public String _CERT_NO = null;
    public String _FLIGHT_DATE = null;
    public String _INTERNATIONAL_FLAG = null;
    public String _PASSENGER_NAME = null;
    public String _USER_ID = null;
    public String _ORG_CITY = null;
    public String _DST_CITY = null;
    public String _CONST_ID = null;
    public String _CAPTCHA_RESULT = null;
    public String _OTHER_FLAG = null;
    public String REFUND_TICKET_FLAG = null;
    private java.lang.Exception _exception = null;

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/allChannelTicketReschedule";
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(java.lang.Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public java.lang.Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CERT_NO != null) {
            xml.startTag(null, "CERT_NO");
            xml.text(this._CERT_NO);
            xml.endTag(null, "CERT_NO");
        }
        if (this._FLIGHT_DATE != null) {
            xml.startTag(null, "FLIGHT_DATE");
            xml.text(this._FLIGHT_DATE);
            xml.endTag(null, "FLIGHT_DATE");
        }
        if (this._INTERNATIONAL_FLAG != null) {
            xml.startTag(null, "INTERNATIONAL_FLAG");
            xml.text(this._INTERNATIONAL_FLAG);
            xml.endTag(null, "INTERNATIONAL_FLAG");
        }
        if (this._PASSENGER_NAME != null) {
            xml.startTag(null, "PASSENGER_NAME");
            xml.text(this._PASSENGER_NAME);
            xml.endTag(null, "PASSENGER_NAME");
        }
        if (this._USER_ID != null) {
            xml.startTag(null, "USER_ID");
            xml.text(this._USER_ID);
            xml.endTag(null, "USER_ID");
        }
        if (this._ORG_CITY != null) {
            xml.startTag(null, "ORG_CITY");
            xml.text(this._ORG_CITY);
            xml.endTag(null, "ORG_CITY");
        }
        if (this._DST_CITY != null) {
            xml.startTag(null, "DST_CITY");
            xml.text(this._DST_CITY);
            xml.endTag(null, "DST_CITY");
        }
        if (this._CONST_ID != null) {
            xml.startTag(null, "CONST_ID");
            xml.text(this._CONST_ID);
            xml.endTag(null, "CONST_ID");
        }
        if (this._CAPTCHA_RESULT != null) {
            xml.startTag(null, "CAPTCHA_RESULT");
            xml.text(this._CAPTCHA_RESULT);
            xml.endTag(null, "CAPTCHA_RESULT");
        }
        if (this._OTHER_FLAG != null) {
            xml.startTag(null, "OTHER_FLAG");
            xml.text(this._OTHER_FLAG);
            xml.endTag(null, "OTHER_FLAG");
        }
        if (this.REFUND_TICKET_FLAG != null) {
            xml.startTag(null, "REFUND_TICKET_FLAG");
            xml.text(this.REFUND_TICKET_FLAG);
            xml.endTag(null, "REFUND_TICKET_FLAG");
        }
    }

    @Override // com.common.szair.model.allchangedate.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CERT_NO".equals(parser.getName())) {
                        this._CERT_NO = parser.nextText();
                    } else if ("FLIGHT_DATE".equals(parser.getName())) {
                        this._FLIGHT_DATE = parser.nextText();
                    } else if ("INTERNATIONAL_FLAG".equals(parser.getName())) {
                        this._INTERNATIONAL_FLAG = parser.nextText();
                    } else if ("PASSENGER_NAME".equals(parser.getName())) {
                        this._PASSENGER_NAME = parser.nextText();
                    } else if ("USER_ID".equals(parser.getName())) {
                        this._USER_ID = parser.nextText();
                    } else if ("ORG_CITY".equals(parser.getName())) {
                        this._ORG_CITY = parser.nextText();
                    } else if ("DST_CITY".equals(parser.getName())) {
                        this._DST_CITY = parser.nextText();
                    } else if ("CONST_ID".equals(parser.getName())) {
                        this._CONST_ID = parser.nextText();
                    } else if ("CAPTCHA_RESULT".equals(parser.getName())) {
                        this._CAPTCHA_RESULT = parser.nextText();
                    } else if ("OTHER_FLAG".equals(parser.getName())) {
                        this._OTHER_FLAG = parser.nextText();
                    } else if ("REFUND_TICKET_FLAG".equals(parser.getName())) {
                        this.REFUND_TICKET_FLAG = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}