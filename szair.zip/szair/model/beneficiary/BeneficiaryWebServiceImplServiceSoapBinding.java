package com.common.szair.model.beneficiary;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class BeneficiaryWebServiceImplServiceSoapBinding extends SOAPBinding {
    public BeneficiaryWebServiceImplServiceSoapBinding(String endpoint) {
        super(BeneficiaryWebServiceImplServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns4", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns3", "http://impl.webservice.beneficiary.shenzhenair.com/");
        hashMap.put("ns1", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns2", "http://com/shenzhenair/mobilewebservice/beneficiary");
        hashMap.put("ns0", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        return hashMap;
    }

    public addBeneficiaryResponse addBeneficiary(addBeneficiary parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("addBeneficiary", parameters);
        }
        addBeneficiaryResponse addbeneficiaryresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof addBeneficiaryResponse)) {
                    addbeneficiaryresponse = (addBeneficiaryResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    addbeneficiaryresponse = new addBeneficiaryResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    addbeneficiaryresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (addbeneficiaryresponse != null) {
                return addbeneficiaryresponse;
            }
            addBeneficiaryResponse addbeneficiaryresponse2 = new addBeneficiaryResponse();
            addbeneficiaryresponse2.setexception(new NullPointerException());
            return addbeneficiaryresponse2;
        } catch (Exception e) {
            addBeneficiaryResponse addbeneficiaryresponse3 = new addBeneficiaryResponse();
            addbeneficiaryresponse3.setexception(e);
            return addbeneficiaryresponse3;
        }
    }

    public deleteBeneficiaryResponse deleteBeneficiary(deleteBeneficiary parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("deleteBeneficiary", parameters);
        }
        deleteBeneficiaryResponse deletebeneficiaryresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof deleteBeneficiaryResponse)) {
                    deletebeneficiaryresponse = (deleteBeneficiaryResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    deletebeneficiaryresponse = new deleteBeneficiaryResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    deletebeneficiaryresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (deletebeneficiaryresponse != null) {
                return deletebeneficiaryresponse;
            }
            deleteBeneficiaryResponse deletebeneficiaryresponse2 = new deleteBeneficiaryResponse();
            deletebeneficiaryresponse2.setexception(new NullPointerException());
            return deletebeneficiaryresponse2;
        } catch (Exception e) {
            deleteBeneficiaryResponse deletebeneficiaryresponse3 = new deleteBeneficiaryResponse();
            deletebeneficiaryresponse3.setexception(e);
            return deletebeneficiaryresponse3;
        }
    }

    public sendSmsResponse sendSms(sendSms parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("sendSms", parameters);
        }
        sendSmsResponse sendsmsresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof sendSmsResponse)) {
                    sendsmsresponse = (sendSmsResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    sendsmsresponse = new sendSmsResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    sendsmsresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (sendsmsresponse != null) {
                return sendsmsresponse;
            }
            sendSmsResponse sendsmsresponse2 = new sendSmsResponse();
            sendsmsresponse2.setexception(new NullPointerException());
            return sendsmsresponse2;
        } catch (Exception e) {
            sendSmsResponse sendsmsresponse3 = new sendSmsResponse();
            sendsmsresponse3.setexception(e);
            return sendsmsresponse3;
        }
    }

    public queryBeneficiaryResponse queryBeneficiary(queryBeneficiary parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryBeneficiary", parameters);
        }
        queryBeneficiaryResponse querybeneficiaryresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryBeneficiaryResponse)) {
                    querybeneficiaryresponse = (queryBeneficiaryResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querybeneficiaryresponse = new queryBeneficiaryResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querybeneficiaryresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querybeneficiaryresponse != null) {
                return querybeneficiaryresponse;
            }
            queryBeneficiaryResponse querybeneficiaryresponse2 = new queryBeneficiaryResponse();
            querybeneficiaryresponse2.setexception(new NullPointerException());
            return querybeneficiaryresponse2;
        } catch (Exception e) {
            queryBeneficiaryResponse querybeneficiaryresponse3 = new queryBeneficiaryResponse();
            querybeneficiaryresponse3.setexception(e);
            return querybeneficiaryresponse3;
        }
    }

    public modifyBeneficiaryResponse modifyBeneficiary(modifyBeneficiary parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("modifyBeneficiary", parameters);
        }
        modifyBeneficiaryResponse modifybeneficiaryresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof modifyBeneficiaryResponse)) {
                    modifybeneficiaryresponse = (modifyBeneficiaryResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    modifybeneficiaryresponse = new modifyBeneficiaryResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    modifybeneficiaryresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (modifybeneficiaryresponse != null) {
                return modifybeneficiaryresponse;
            }
            modifyBeneficiaryResponse modifybeneficiaryresponse2 = new modifyBeneficiaryResponse();
            modifybeneficiaryresponse2.setexception(new NullPointerException());
            return modifybeneficiaryresponse2;
        } catch (Exception e) {
            modifyBeneficiaryResponse modifybeneficiaryresponse3 = new modifyBeneficiaryResponse();
            modifybeneficiaryresponse3.setexception(e);
            return modifybeneficiaryresponse3;
        }
    }

    public queryBeneficiaryUrlResponse queryBeneficiaryUrl(queryBeneficiaryUrl parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("queryBeneficiaryUrl", parameters);
        }
        queryBeneficiaryUrlResponse querybeneficiaryurlresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof queryBeneficiaryUrlResponse)) {
                    querybeneficiaryurlresponse = (queryBeneficiaryUrlResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    querybeneficiaryurlresponse = new queryBeneficiaryUrlResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    querybeneficiaryurlresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (querybeneficiaryurlresponse != null) {
                return querybeneficiaryurlresponse;
            }
            queryBeneficiaryUrlResponse querybeneficiaryurlresponse2 = new queryBeneficiaryUrlResponse();
            querybeneficiaryurlresponse2.setexception(new NullPointerException());
            return querybeneficiaryurlresponse2;
        } catch (Exception e) {
            queryBeneficiaryUrlResponse querybeneficiaryurlresponse3 = new queryBeneficiaryUrlResponse();
            querybeneficiaryurlresponse3.setexception(e);
            return querybeneficiaryurlresponse3;
        }
    }
}