package com.common.szair.model.beneficiary;

import com.air.sz.ui.widget.timeSelector.TextUtil;
import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class certVO extends baseDTOVO implements SOAPObject, Serializable, Comparable<certVO> {
    public String _CERT_ID = null;
    public String _CERT_NO = null;
    public String _CERT_TYPE = null;
    public String _NATION = null;
    public String _ISSUE_NATION = null;
    public String _EXPIRATION_DATE = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/beneficiary";
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._CERT_ID != null) {
            xml.startTag(null, "CERT_ID");
            xml.text(this._CERT_ID);
            xml.endTag(null, "CERT_ID");
        }
        if (this._CERT_NO != null) {
            xml.startTag(null, "CERT_NO");
            xml.text(this._CERT_NO);
            xml.endTag(null, "CERT_NO");
        }
        if (this._CERT_TYPE != null) {
            xml.startTag(null, "CERT_TYPE");
            xml.text(this._CERT_TYPE);
            xml.endTag(null, "CERT_TYPE");
        }
        if (this._NATION != null) {
            xml.startTag(null, "NATION");
            xml.text(this._NATION);
            xml.endTag(null, "NATION");
        }
        if (this._ISSUE_NATION != null) {
            xml.startTag(null, "ISSUE_NATION");
            xml.text(this._ISSUE_NATION);
            xml.endTag(null, "ISSUE_NATION");
        }
        if (this._EXPIRATION_DATE != null) {
            xml.startTag(null, "EXPIRATION_DATE");
            xml.text(this._EXPIRATION_DATE);
            xml.endTag(null, "EXPIRATION_DATE");
        }
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("CERT_ID".equals(parser.getName())) {
                        this._CERT_ID = parser.nextText();
                    } else if ("CERT_NO".equals(parser.getName())) {
                        this._CERT_NO = parser.nextText();
                    } else if ("CERT_TYPE".equals(parser.getName())) {
                        this._CERT_TYPE = parser.nextText();
                    } else if ("NATION".equals(parser.getName())) {
                        this._NATION = parser.nextText();
                    } else if ("ISSUE_NATION".equals(parser.getName())) {
                        this._ISSUE_NATION = parser.nextText();
                    } else if ("EXPIRATION_DATE".equals(parser.getName())) {
                        this._EXPIRATION_DATE = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }

    public int getLevel() {
        if ("ID Card".equals(this._CERT_TYPE)) {
            return 1;
        }
        return "Ordinary_Passport".equals(this._CERT_TYPE) ? 2 : 3;
    }

    @Override // java.lang.Comparable
    public int compareTo(certVO o) {
        return getLevel() - o.getLevel();
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return !TextUtil.isEmpty(this._CERT_NO) && this._CERT_NO.equals(((certVO) o)._CERT_NO);
    }

    public int hashCode() {
        return TextUtil.isEmpty(this._CERT_NO) ? super.hashCode() : this._CERT_NO.hashCode();
    }
}