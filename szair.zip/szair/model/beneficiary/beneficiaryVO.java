package com.common.szair.model.beneficiary;

import com.air.sz.ui.widget.timeSelector.TextUtil;
import com.air.sz.util.UiUtil;
import com.air.sz.zxing.decoding.Intents;
import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class beneficiaryVO extends baseDTOVO implements SOAPObject, Serializable {
    public boolean isSelf;
    public String _BIRTHDAY = null;
    public List<certVO> _CERT_LIST = null;
    public String _FIRST_NAME = null;
    public String _FIRST_NAME_EN = null;
    public String _BENEFICIARY_jID = null;
    public String _LAST_NAME = null;
    public String _LAST_NAME_EN = null;
    public String _OTHER_INFO = null;
    public String _PSGR_TYPE = null;
    public String _STATUS = null;
    public String _TYPE = null;
    public String _SEX = null;
    public String _NATION = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/beneficiary";
    }

    public int checkIdTypeRepeat(certVO cert) {
        List<certVO> list;
        if (cert != null && !TextUtil.isEmpty(cert._CERT_TYPE) && ((cert._CERT_TYPE.equals("Ordinary_Passport") || cert._CERT_TYPE.equals("ID Card")) && (list = this._CERT_LIST) != null && list.size() > 0)) {
            Iterator<certVO> it = this._CERT_LIST.iterator();
            while (it.hasNext()) {
                if (cert._CERT_TYPE.equals(it.next()._CERT_TYPE)) {
                    return cert._CERT_TYPE.equals("ID Card") ? 1 : 2;
                }
            }
        }
        return 0;
    }

    public boolean checkIdNumRepeat() {
        return new HashSet(this._CERT_LIST).size() != this._CERT_LIST.size();
    }

    public int checkIdNo() {
        List<certVO> list = this._CERT_LIST;
        if (list == null || list.size() <= 0) {
            return 1;
        }
        for (certVO certvo : this._CERT_LIST) {
            if ("ID Card".equals(certvo._CERT_TYPE)) {
                if (!UiUtil.isIdentification(certvo._CERT_NO)) {
                    return 3;
                }
            } else if (TextUtil.isEmpty(certvo._CERT_NO)) {
                return 2;
            }
        }
        return 0;
    }

    public boolean isSamePassenger(beneficiaryVO passenger) {
        List<certVO> list;
        List<certVO> list2;
        if ((!TextUtil.isEmpty(this._BENEFICIARY_jID) && !TextUtil.isEmpty(passenger._BENEFICIARY_jID) && this._BENEFICIARY_jID.equals(passenger._BENEFICIARY_jID)) || passenger == null || (list = passenger._CERT_LIST) == null || list.size() <= 0 || (list2 = this._CERT_LIST) == null || list2.size() <= 0) {
            return false;
        }
        Iterator<certVO> it = this._CERT_LIST.iterator();
        while (it.hasNext()) {
            if (passenger._CERT_LIST.contains(it.next()) && passenger.getAllBookingName().equals(getAllBookingName())) {
                return true;
            }
        }
        return false;
    }

    public String getDisplayNameCn() {
        StringBuilder sb = new StringBuilder();
        String str = this._LAST_NAME;
        if (str == null) {
            str = "";
        }
        sb.append(str);
        String str2 = this._FIRST_NAME;
        sb.append(str2 != null ? str2 : "");
        return sb.toString();
    }

    public String getDisplayNameEn() {
        if (!TextUtil.isEmpty(this._LAST_NAME_EN) && !TextUtil.isEmpty(this._FIRST_NAME_EN)) {
            return this._LAST_NAME_EN + "/" + this._FIRST_NAME_EN;
        }
        StringBuilder sb = new StringBuilder();
        String str = this._LAST_NAME_EN;
        if (str == null) {
            str = "";
        }
        sb.append(str);
        String str2 = this._FIRST_NAME_EN;
        sb.append(str2 != null ? str2 : "");
        return sb.toString();
    }

    public String getBookingNameEn() {
        StringBuilder sb = new StringBuilder();
        String str = this._LAST_NAME_EN;
        if (str == null) {
            str = "";
        }
        sb.append(str);
        sb.append("/");
        String str2 = this._FIRST_NAME_EN;
        sb.append(str2 != null ? str2 : "");
        return sb.toString();
    }

    public String getAllBookingName() {
        StringBuilder sb = new StringBuilder();
        String str = this._LAST_NAME_EN;
        if (str == null) {
            str = "";
        }
        sb.append(str);
        String str2 = this._FIRST_NAME_EN;
        if (str2 == null) {
            str2 = "";
        }
        sb.append(str2);
        String str3 = this._LAST_NAME;
        if (str3 == null) {
            str3 = "";
        }
        sb.append(str3);
        String str4 = this._FIRST_NAME;
        sb.append(str4 != null ? str4 : "");
        return sb.toString();
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._BIRTHDAY != null) {
            xml.startTag(null, "BIRTHDAY");
            xml.text(this._BIRTHDAY);
            xml.endTag(null, "BIRTHDAY");
        }
        List<certVO> list = this._CERT_LIST;
        if (list != null && list.size() > 0) {
            int size = this._CERT_LIST.size();
            for (int i = 0; i < size; i++) {
                xml.startTag(null, "CERT_LIST");
                this._CERT_LIST.get(i).addElementsToNode(xml);
                xml.endTag(null, "CERT_LIST");
            }
        }
        if (this._FIRST_NAME != null) {
            xml.startTag(null, "FIRST_NAME");
            xml.text(this._FIRST_NAME);
            xml.endTag(null, "FIRST_NAME");
        }
        if (this._FIRST_NAME_EN != null) {
            xml.startTag(null, "FIRST_NAME_EN");
            xml.text(this._FIRST_NAME_EN);
            xml.endTag(null, "FIRST_NAME_EN");
        }
        if (this._BENEFICIARY_jID != null) {
            xml.startTag(null, "BENEFICIARY_jID");
            xml.text(this._BENEFICIARY_jID);
            xml.endTag(null, "BENEFICIARY_jID");
        }
        if (this._LAST_NAME != null) {
            xml.startTag(null, "LAST_NAME");
            xml.text(this._LAST_NAME);
            xml.endTag(null, "LAST_NAME");
        }
        if (this._LAST_NAME_EN != null) {
            xml.startTag(null, "LAST_NAME_EN");
            xml.text(this._LAST_NAME_EN);
            xml.endTag(null, "LAST_NAME_EN");
        }
        if (this._OTHER_INFO != null) {
            xml.startTag(null, "OTHER_INFO");
            xml.text(this._OTHER_INFO);
            xml.endTag(null, "OTHER_INFO");
        }
        if (this._PSGR_TYPE != null) {
            xml.startTag(null, "PSGR_TYPE");
            xml.text(this._PSGR_TYPE);
            xml.endTag(null, "PSGR_TYPE");
        }
        if (this._STATUS != null) {
            xml.startTag(null, "STATUS");
            xml.text(this._STATUS);
            xml.endTag(null, "STATUS");
        }
        if (this._TYPE != null) {
            xml.startTag(null, Intents.WifiConnect.TYPE);
            xml.text(this._TYPE);
            xml.endTag(null, Intents.WifiConnect.TYPE);
        }
        if (this._SEX != null) {
            xml.startTag(null, "SEX");
            xml.text(this._SEX);
            xml.endTag(null, "SEX");
        }
        if (this._NATION != null) {
            xml.startTag(null, "NATION");
            xml.text(this._NATION);
            xml.endTag(null, "NATION");
        }
    }

    @Override // com.common.szair.model.beneficiary.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("BIRTHDAY".equals(parser.getName())) {
                        this._BIRTHDAY = parser.nextText();
                    } else if ("CERT_LIST".equals(parser.getName())) {
                        if (this._CERT_LIST == null) {
                            this._CERT_LIST = new ArrayList();
                        }
                        certVO certvo = new certVO();
                        certvo.parse(binding, parser);
                        this._CERT_LIST.add(certvo);
                    } else if ("FIRST_NAME".equals(parser.getName())) {
                        this._FIRST_NAME = parser.nextText();
                    } else if ("FIRST_NAME_EN".equals(parser.getName())) {
                        this._FIRST_NAME_EN = parser.nextText();
                    } else if ("BENEFICIARY_jID".equals(parser.getName())) {
                        this._BENEFICIARY_jID = parser.nextText();
                    } else if ("LAST_NAME".equals(parser.getName())) {
                        this._LAST_NAME = parser.nextText();
                    } else if ("LAST_NAME_EN".equals(parser.getName())) {
                        this._LAST_NAME_EN = parser.nextText();
                    } else if ("OTHER_INFO".equals(parser.getName())) {
                        this._OTHER_INFO = parser.nextText();
                    } else if ("PSGR_TYPE".equals(parser.getName())) {
                        this._PSGR_TYPE = parser.nextText();
                    } else if ("STATUS".equals(parser.getName())) {
                        this._STATUS = parser.nextText();
                    } else if (Intents.WifiConnect.TYPE.equals(parser.getName())) {
                        this._TYPE = parser.nextText();
                    } else if ("SEX".equals(parser.getName())) {
                        this._SEX = parser.nextText();
                    } else if ("NATION".equals(parser.getName())) {
                        this._NATION = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}