package com.common.szair.model.cabinsearch;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class cabinSearchConditionVO extends baseDTOVO implements SOAPObject {
    public String _DST = null;
    public String _FLIGHT_DATE = null;
    public String _ORG = null;
    public String _FLIGHT_NO = null;
    public String _LEVEL = null;
    public String _INTER_FLG = null;
    public String _SHARE_FLAG = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/booking";
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._DST != null) {
            xml.startTag(null, "DST");
            xml.text(this._DST);
            xml.endTag(null, "DST");
        }
        if (this._FLIGHT_DATE != null) {
            xml.startTag(null, "FLIGHT_DATE");
            xml.text(this._FLIGHT_DATE);
            xml.endTag(null, "FLIGHT_DATE");
        }
        if (this._ORG != null) {
            xml.startTag(null, "ORG");
            xml.text(this._ORG);
            xml.endTag(null, "ORG");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._LEVEL != null) {
            xml.startTag(null, "LEVEL");
            xml.text(this._LEVEL);
            xml.endTag(null, "LEVEL");
        }
        if (this._INTER_FLG != null) {
            xml.startTag(null, "INTER_FLG");
            xml.text(this._INTER_FLG);
            xml.endTag(null, "INTER_FLG");
        }
        if (this._SHARE_FLAG != null) {
            xml.startTag(null, "SHARE_FLAG");
            xml.text(this._SHARE_FLAG);
            xml.endTag(null, "SHARE_FLAG");
        }
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("DST".equals(parser.getName())) {
                        this._DST = parser.nextText();
                    } else if ("FLIGHT_DATE".equals(parser.getName())) {
                        this._FLIGHT_DATE = parser.nextText();
                    } else if ("ORG".equals(parser.getName())) {
                        this._ORG = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("LEVEL".equals(parser.getName())) {
                        this._LEVEL = parser.nextText();
                    } else if ("INTER_FLG".equals(parser.getName())) {
                        this._INTER_FLG = parser.nextText();
                    } else if ("SHARE_FLAG".equals(parser.getName())) {
                        this._SHARE_FLAG = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}