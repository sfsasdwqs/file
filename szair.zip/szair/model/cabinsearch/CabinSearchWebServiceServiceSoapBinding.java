package com.common.szair.model.cabinsearch;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPFault;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class CabinSearchWebServiceServiceSoapBinding extends SOAPBinding {
    public CabinSearchWebServiceServiceSoapBinding(String endpoint) {
        super(CabinSearchWebServiceServiceSoapBinding.class.getPackage().getName(), endpoint);
    }

    @Override // com.common.szair.model.soap.SOAPBinding
    public Map<String, String> getNamespaces() {
        HashMap hashMap = new HashMap();
        hashMap.put("ns3", "http://impl.webservice.booking.shenzhenair.com/");
        hashMap.put("ns4", "http://schemas.xmlsoap.org/soap/http");
        hashMap.put("ns2", "http://com/shenzhenair/mobilewebservice/booking");
        hashMap.put("ns1", "http://www.w3.org/2001/XMLSchema");
        hashMap.put("ns0", "http://schemas.xmlsoap.org/wsdl/");
        hashMap.put("ns5", "http://schemas.xmlsoap.org/wsdl/soap/");
        return hashMap;
    }

    public searchCabinRightResponse searchCabinRight(searchCabinRight parameters) {
        HashMap hashMap = new HashMap();
        if (parameters != null) {
            hashMap.put("searchCabinRight", parameters);
        }
        searchCabinRightResponse searchcabinrightresponse = null;
        try {
            Iterator<Object> it = makeRequest(hashMap).bodyElements.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (next != null && (next instanceof searchCabinRightResponse)) {
                    searchcabinrightresponse = (searchCabinRightResponse) next;
                    break;
                }
                if (next != null && (next instanceof SOAPFault)) {
                    searchcabinrightresponse = new searchCabinRightResponse();
                    SOAPFault sOAPFault = (SOAPFault) next;
                    searchcabinrightresponse.setexception(new Exception(sOAPFault.getfaultcode(), new Throwable(sOAPFault.getfaultstring())));
                    break;
                }
            }
            if (searchcabinrightresponse != null) {
                return searchcabinrightresponse;
            }
            searchCabinRightResponse searchcabinrightresponse2 = new searchCabinRightResponse();
            searchcabinrightresponse2.setexception(new NullPointerException());
            return searchcabinrightresponse2;
        } catch (Exception e) {
            searchCabinRightResponse searchcabinrightresponse3 = new searchCabinRightResponse();
            searchcabinrightresponse3.setexception(e);
            return searchcabinrightresponse3;
        }
    }
}