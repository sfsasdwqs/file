package com.common.szair.model.cabinsearch;

import com.common.szair.model.soap.SOAPBinding;
import com.common.szair.model.soap.SOAPObject;
import com.common.szair.model.soap.UnknownSOAPObject;
import java.io.IOException;
import java.io.Serializable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public class cabinSearchVO extends baseDTOVO implements SOAPObject, Serializable {
    public String _AIRCRAFT_NUMBER = null;
    public String _ARR_BRIDGE = null;
    public String _CABIN = null;
    public String _CABIN_PIC = null;
    public String _DEP_BRIDGE = null;
    public String _ERROR = null;
    public String _ERROR_CODE = null;
    public String _FEATURE_SERVICES = null;
    public String _FLIGHT_ARR_CODE = null;
    public String _FLIGHT_DATE = null;
    public String _FLIGHT_DEP_CODE = null;
    public String _FLIGHT_NO = null;
    public String _FLIGHT_YEAR = null;
    public String _FOOD_NAME = null;
    public String _GENERIC = null;
    public String _LEVEL = null;
    public String _MEDIA = null;
    public String _POWER = null;
    public String _SEAT_PIC = null;
    public String _SEAT_SPACE = null;
    public String _SEAT_TILT = null;
    public String _SEAT_WIDTH = null;
    public String _SEAT_LAYOUT = null;
    public String _SOCKET = null;
    public String _VIDEO = null;
    public String _WIFI = null;
    public String _CABIN_LABEL = null;
    public String _CABIN_LABEL_TEXT = null;
    private Exception _exception = null;

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addAttributesToNode(XmlSerializer xml) throws IOException {
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public String getNamespace() {
        return "http://com/shenzhenair/mobilewebservice/booking";
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void setexception(Exception _exception) {
        this._exception = _exception;
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public Exception getexception() {
        return this._exception;
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void toXml(XmlSerializer xml, String name, String namespace) throws IOException {
        if (namespace == null || namespace.length() <= 0) {
            namespace = getNamespace();
        }
        xml.startTag(namespace, name);
        addAttributesToNode(xml);
        addElementsToNode(xml);
        xml.endTag(namespace, name);
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void addElementsToNode(XmlSerializer xml) throws IOException {
        if (this._AIRCRAFT_NUMBER != null) {
            xml.startTag(null, "AIRCRAFT_NUMBER");
            xml.text(this._AIRCRAFT_NUMBER);
            xml.endTag(null, "AIRCRAFT_NUMBER");
        }
        if (this._ARR_BRIDGE != null) {
            xml.startTag(null, "ARR_BRIDGE");
            xml.text(this._ARR_BRIDGE);
            xml.endTag(null, "ARR_BRIDGE");
        }
        if (this._CABIN != null) {
            xml.startTag(null, "CABIN");
            xml.text(this._CABIN);
            xml.endTag(null, "CABIN");
        }
        if (this._CABIN_PIC != null) {
            xml.startTag(null, "CABIN_PIC");
            xml.text(this._CABIN_PIC);
            xml.endTag(null, "CABIN_PIC");
        }
        if (this._DEP_BRIDGE != null) {
            xml.startTag(null, "DEP_BRIDGE");
            xml.text(this._DEP_BRIDGE);
            xml.endTag(null, "DEP_BRIDGE");
        }
        if (this._ERROR != null) {
            xml.startTag(null, "ERROR");
            xml.text(this._ERROR);
            xml.endTag(null, "ERROR");
        }
        if (this._ERROR_CODE != null) {
            xml.startTag(null, "ERROR_CODE");
            xml.text(this._ERROR_CODE);
            xml.endTag(null, "ERROR_CODE");
        }
        if (this._FEATURE_SERVICES != null) {
            xml.startTag(null, "FEATURE_SERVICES");
            xml.text(this._FEATURE_SERVICES);
            xml.endTag(null, "FEATURE_SERVICES");
        }
        if (this._FLIGHT_ARR_CODE != null) {
            xml.startTag(null, "FLIGHT_ARR_CODE");
            xml.text(this._FLIGHT_ARR_CODE);
            xml.endTag(null, "FLIGHT_ARR_CODE");
        }
        if (this._FLIGHT_DATE != null) {
            xml.startTag(null, "FLIGHT_DATE");
            xml.text(this._FLIGHT_DATE);
            xml.endTag(null, "FLIGHT_DATE");
        }
        if (this._FLIGHT_DEP_CODE != null) {
            xml.startTag(null, "FLIGHT_DEP_CODE");
            xml.text(this._FLIGHT_DEP_CODE);
            xml.endTag(null, "FLIGHT_DEP_CODE");
        }
        if (this._FLIGHT_NO != null) {
            xml.startTag(null, "FLIGHT_NO");
            xml.text(this._FLIGHT_NO);
            xml.endTag(null, "FLIGHT_NO");
        }
        if (this._FLIGHT_YEAR != null) {
            xml.startTag(null, "FLIGHT_YEAR");
            xml.text(this._FLIGHT_YEAR);
            xml.endTag(null, "FLIGHT_YEAR");
        }
        if (this._FOOD_NAME != null) {
            xml.startTag(null, "FOOD_NAME");
            xml.text(this._FOOD_NAME);
            xml.endTag(null, "FOOD_NAME");
        }
        if (this._GENERIC != null) {
            xml.startTag(null, "GENERIC");
            xml.text(this._GENERIC);
            xml.endTag(null, "GENERIC");
        }
        if (this._LEVEL != null) {
            xml.startTag(null, "LEVEL");
            xml.text(this._LEVEL);
            xml.endTag(null, "LEVEL");
        }
        if (this._MEDIA != null) {
            xml.startTag(null, "MEDIA");
            xml.text(this._MEDIA);
            xml.endTag(null, "MEDIA");
        }
        if (this._POWER != null) {
            xml.startTag(null, "POWER");
            xml.text(this._POWER);
            xml.endTag(null, "POWER");
        }
        if (this._SEAT_PIC != null) {
            xml.startTag(null, "SEAT_PIC");
            xml.text(this._SEAT_PIC);
            xml.endTag(null, "SEAT_PIC");
        }
        if (this._SEAT_SPACE != null) {
            xml.startTag(null, "SEAT_SPACE");
            xml.text(this._SEAT_SPACE);
            xml.endTag(null, "SEAT_SPACE");
        }
        if (this._SEAT_TILT != null) {
            xml.startTag(null, "SEAT_TILT");
            xml.text(this._SEAT_TILT);
            xml.endTag(null, "SEAT_TILT");
        }
        if (this._SEAT_WIDTH != null) {
            xml.startTag(null, "SEAT_WIDTH");
            xml.text(this._SEAT_WIDTH);
            xml.endTag(null, "SEAT_WIDTH");
        }
        if (this._SEAT_LAYOUT != null) {
            xml.startTag(null, "SEAT_LAYOUT");
            xml.text(this._SEAT_LAYOUT);
            xml.endTag(null, "SEAT_LAYOUT");
        }
        if (this._SOCKET != null) {
            xml.startTag(null, "SOCKET");
            xml.text(this._SOCKET);
            xml.endTag(null, "SOCKET");
        }
        if (this._VIDEO != null) {
            xml.startTag(null, "VIDEO");
            xml.text(this._VIDEO);
            xml.endTag(null, "VIDEO");
        }
        if (this._WIFI != null) {
            xml.startTag(null, "WIFI");
            xml.text(this._WIFI);
            xml.endTag(null, "WIFI");
        }
        if (this._CABIN_LABEL != null) {
            xml.startTag(null, "CABIN_LABEL");
            xml.text(this._CABIN_LABEL);
            xml.endTag(null, "CABIN_LABEL");
        }
        if (this._CABIN_LABEL_TEXT != null) {
            xml.startTag(null, "CABIN_LABEL_TEXT");
            xml.text(this._CABIN_LABEL_TEXT);
            xml.endTag(null, "CABIN_LABEL_TEXT");
        }
    }

    @Override // com.common.szair.model.cabinsearch.baseDTOVO, com.common.szair.model.soap.SOAPObject
    public void parse(SOAPBinding binding, XmlPullParser parser) {
        try {
            int next = parser.next();
            while (next != 3) {
                if (next == 2) {
                    if ("AIRCRAFT_NUMBER".equals(parser.getName())) {
                        this._AIRCRAFT_NUMBER = parser.nextText();
                    } else if ("ARR_BRIDGE".equals(parser.getName())) {
                        this._ARR_BRIDGE = parser.nextText();
                    } else if ("CABIN".equals(parser.getName())) {
                        this._CABIN = parser.nextText();
                    } else if ("CABIN_PIC".equals(parser.getName())) {
                        this._CABIN_PIC = parser.nextText();
                    } else if ("DEP_BRIDGE".equals(parser.getName())) {
                        this._DEP_BRIDGE = parser.nextText();
                    } else if ("ERROR".equals(parser.getName())) {
                        this._ERROR = parser.nextText();
                    } else if ("ERROR_CODE".equals(parser.getName())) {
                        this._ERROR_CODE = parser.nextText();
                    } else if ("FEATURE_SERVICES".equals(parser.getName())) {
                        this._FEATURE_SERVICES = parser.nextText();
                    } else if ("FLIGHT_ARR_CODE".equals(parser.getName())) {
                        this._FLIGHT_ARR_CODE = parser.nextText();
                    } else if ("FLIGHT_DATE".equals(parser.getName())) {
                        this._FLIGHT_DATE = parser.nextText();
                    } else if ("FLIGHT_DEP_CODE".equals(parser.getName())) {
                        this._FLIGHT_DEP_CODE = parser.nextText();
                    } else if ("FLIGHT_NO".equals(parser.getName())) {
                        this._FLIGHT_NO = parser.nextText();
                    } else if ("FLIGHT_YEAR".equals(parser.getName())) {
                        this._FLIGHT_YEAR = parser.nextText();
                    } else if ("FOOD_NAME".equals(parser.getName())) {
                        this._FOOD_NAME = parser.nextText();
                    } else if ("GENERIC".equals(parser.getName())) {
                        this._GENERIC = parser.nextText();
                    } else if ("LEVEL".equals(parser.getName())) {
                        this._LEVEL = parser.nextText();
                    } else if ("MEDIA".equals(parser.getName())) {
                        this._MEDIA = parser.nextText();
                    } else if ("POWER".equals(parser.getName())) {
                        this._POWER = parser.nextText();
                    } else if ("SEAT_PIC".equals(parser.getName())) {
                        this._SEAT_PIC = parser.nextText();
                    } else if ("SEAT_SPACE".equals(parser.getName())) {
                        this._SEAT_SPACE = parser.nextText();
                    } else if ("SEAT_TILT".equals(parser.getName())) {
                        this._SEAT_TILT = parser.nextText();
                    } else if ("SEAT_WIDTH".equals(parser.getName())) {
                        this._SEAT_WIDTH = parser.nextText();
                    } else if ("SEAT_LAYOUT".equals(parser.getName())) {
                        this._SEAT_LAYOUT = parser.nextText();
                    } else if ("SOCKET".equals(parser.getName())) {
                        this._SOCKET = parser.nextText();
                    } else if ("VIDEO".equals(parser.getName())) {
                        this._VIDEO = parser.nextText();
                    } else if ("WIFI".equals(parser.getName())) {
                        this._WIFI = parser.nextText();
                    } else if ("CABIN_LABEL".equals(parser.getName())) {
                        this._CABIN_LABEL = parser.nextText();
                    } else if ("CABIN_LABEL_TEXT".equals(parser.getName())) {
                        this._CABIN_LABEL_TEXT = parser.nextText();
                    } else {
                        new UnknownSOAPObject().parse(binding, parser);
                    }
                }
                next = parser.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        }
    }
}