package com.common.szair.asynctask;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public abstract class AbsAsyncCallback<E> implements AsyncCallback<E> {
    public void onNetworkError() {
    }
}