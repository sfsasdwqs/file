package com.common.szair.asynctask;

/* loaded from: C:\Users\桥\Desktop\python\xiuhao\classes3.dex */
public interface AsyncCallback<E> {
    void onProcess(E response, String fp);
}